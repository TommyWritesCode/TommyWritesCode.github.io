# Claude Code Rate-Limit Resumer

An unofficial macOS utility that detects Claude Code session rate limits,
parses the displayed reset time, waits one additional minute, and submits the
literal prompt `continue work` to the same Claude Code session.

It uses Claude Code's `StopFailure` hook with the `rate_limit` matcher. Claude
Code must run inside `tmux`, which gives the delayed worker an explicit terminal
pane to target without controlling whichever Terminal window happens to be in
focus.

This project is not affiliated with or endorsed by Anthropic.

## What it accesses

The utility:

- Receives Claude Code's `StopFailure` hook JSON through standard input.
- Reads only the rate-limit error fields and, as a fallback, the visible text
  in its own `tmux` pane.
- Writes private status and logs under
  `~/.local/state/claude-rate-limit-resumer/`.
- Sends only the literal text `continue work` followed by Enter.
- Makes no network requests and does not request, store, or transmit API keys.
- Does not read or modify project source files.

Claude Code command hooks run with your user permissions. Review `resumer.py`
and `install.py` before installing any hook downloaded from the internet.

## Requirements

- macOS
- Python 3.9 or newer
- A current Claude Code installation supporting `StopFailure`
- `tmux`

Install `tmux` with Homebrew if necessary:

```bash
brew install tmux
```

## Install

Extract the release, open Terminal in the extracted directory, and run:

```bash
python3 install.py
```

The installer:

1. Copies `resumer.py` to
   `~/.local/share/claude-rate-limit-resumer/resumer.py`.
2. Backs up an existing `~/.claude/settings.json`.
3. Preserves existing settings while adding a user-level
   `StopFailure` / `rate_limit` hook.

To move an existing conversation into `tmux`, exit Claude Code and run these
commands from the same project directory:

```bash
tmux new-session -A -s claude-work
claude --continue
```

Use `claude --resume` if you need to select a different saved conversation.
Inside Claude Code, run `/hooks` and confirm the following entry appears:

```text
StopFailure → rate_limit
```

## Normal use

Start or reconnect to the protected terminal:

```bash
tmux new-session -A -s claude-work
```

Detach without stopping Claude Code by pressing `Ctrl+B`, then `D`. Reattach
with the same command.

The Mac must remain awake for Claude Code to work. If macOS sleeps through the
reset time, the worker resumes after the Mac wakes, provided Claude Code still
owns the original pane.

## Status and logs

```bash
~/.local/share/claude-rate-limit-resumer/resumer.py status
tail -f ~/.local/state/claude-rate-limit-resumer/resumer.log
```

Status values:

- `waiting`: a restart is scheduled.
- `sent`: `continue work` was submitted.
- `not-sent`: the safety check failed, so no input was submitted.

The tool refuses to send text if the pane disappeared or Claude Code is no
longer its foreground program. Repeated hook events for the same session and
reset time are deduplicated.

Claude Code's native executable may identify itself to `tmux` by its version
number instead of the name `claude`. The utility records the foreground command
when the rate limit occurs and requires the same identity at restart time. If
Claude has exited back to a shell such as `zsh`, no text is sent.

## Test

```bash
python3 -m unittest -v
```

## Uninstall

From the extracted release directory:

```bash
python3 install.py uninstall
```

This removes only this utility's hook and installed script. It preserves local
status and logs for inspection.

## License

MIT. See `LICENSE`.
