#!/usr/bin/env python3

import json
import os
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

import install
import resumer


SAMPLE = """Agent \"T-007 Resistance logging\" failed: Agent terminated early due to an API error:
You've hit your session limit · resets 12:20am (America/New_York)
You've hit your session limit · resets 12:20am (America/New_York)"""


class ResetParsingTests(unittest.TestCase):
    def test_parses_user_example(self):
        now = datetime(2026, 8, 16, 23, 0, tzinfo=ZoneInfo("America/New_York"))
        actual = resumer.parse_reset_time(SAMPLE, now)
        self.assertEqual(actual, datetime(2026, 8, 17, 0, 20, tzinfo=ZoneInfo("America/New_York")))

    def test_rolls_past_time_to_tomorrow(self):
        now = datetime(2026, 8, 16, 12, 21, tzinfo=ZoneInfo("America/New_York"))
        actual = resumer.parse_reset_time("resets 12:20pm (America/New_York)", now)
        self.assertEqual(actual.day, 17)
        self.assertEqual((actual.hour, actual.minute), (12, 20))

    def test_handles_noon_and_midnight(self):
        now = datetime(2026, 8, 16, 10, 0, tzinfo=ZoneInfo("America/New_York"))
        noon = resumer.parse_reset_time("resets 12:00 PM (America/New_York)", now)
        midnight = resumer.parse_reset_time("resets 12:00am (America/New_York)", now)
        self.assertEqual(noon.hour, 12)
        self.assertEqual(midnight.hour, 0)
        self.assertEqual(midnight.day, 17)

    def test_accepts_dotted_meridiem(self):
        now = datetime(2026, 8, 16, 10, 0, tzinfo=ZoneInfo("America/New_York"))
        actual = resumer.parse_reset_time("resets 1:05 p.m. (America/New_York)", now)
        self.assertEqual((actual.hour, actual.minute), (13, 5))

    def test_rejects_missing_reset(self):
        with self.assertRaises(ValueError):
            resumer.parse_reset_time("API Error: Rate limit reached")


class PaneRecognitionTests(unittest.TestCase):
    def test_accepts_native_claude_name(self):
        self.assertTrue(resumer.command_looks_like_claude("claude", None, ""))

    def test_accepts_same_version_process_recorded_at_schedule(self):
        self.assertTrue(resumer.command_looks_like_claude("2.1.232", "2.1.232", ""))

    def test_rejects_unrecorded_version_process(self):
        self.assertFalse(resumer.command_looks_like_claude("2.1.232", None, ""))

    def test_rejects_shell_after_claude_exits(self):
        self.assertFalse(resumer.command_looks_like_claude("zsh", "2.1.232", ""))

    def test_accepts_node_only_with_claude_ui_evidence(self):
        self.assertFalse(resumer.command_looks_like_claude("node", "node", "ordinary node app"))
        self.assertTrue(resumer.command_looks_like_claude("node", "node", "Claude Code"))


class InstallerMergeTests(unittest.TestCase):
    def test_preserves_existing_hooks_and_deduplicates_ours(self):
        settings = {
            "model": "sonnet",
            "hooks": {
                "StopFailure": [
                    {"matcher": "overloaded", "hooks": [{"type": "command", "command": "/tmp/other"}]},
                    {
                        "matcher": "rate_limit",
                        "hooks": [{"type": "command", "command": "/old/claude-rate-limit-resumer/resumer.py"}],
                    },
                ]
            },
        }
        install.add_hook(settings)
        self.assertEqual(settings["model"], "sonnet")
        groups = settings["hooks"]["StopFailure"]
        self.assertEqual(len(groups), 2)
        self.assertEqual(groups[0]["matcher"], "overloaded")
        self.assertEqual(groups[1]["matcher"], "rate_limit")


if __name__ == "__main__":
    unittest.main()
