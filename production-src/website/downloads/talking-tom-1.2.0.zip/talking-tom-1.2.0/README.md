# Talking Tom

Turn a PDF, Word (.docx), or text file into a clean spoken-audio file you can
actually listen to.

Drop in a reading, and Talking Tom **cleans it** (strips citations, page numbers,
headers, and OCR noise so they are not read aloud), **voices it** with a free
Microsoft Edge neural voice, and **plays it back** with a waveform scrubber and
pitch-preserved speed control. macOS desktop app, single Python file, no build step.

**English and Spanish.** On first launch the app asks which language you want; the
whole interface is in that language (change it later in **Settings → Language /
Idioma** - the app relaunches to apply). The app name and cat icon stay the same
in both.

**Interface language and content language are independent.** Two ways to get
audio in the other language, regardless of what the buttons say:

- **Translate** button (next to *Clean Only*) - detects whether the text is
  English or Spanish, translates it to the other one in place, and sets **Read
  in** to match so *Generate Audio* voices it correctly. Needs a Claude key.
- **Read in** dropdown - `Auto (source)` / `English` / `Spanish`. On a specific
  language the cleaning pass translates as it cleans, and the voice list switches
  to that language's Edge voices. `Auto` keeps the document's own language.

Claude is natively multilingual, so translation works the same in both
directions. Language detection is a simple word-frequency heuristic
(`_guess_lang`).

> **Note:** "Talking Tom" is also the name of an Outfit7 game. This is an
> unofficial personal project, not affiliated with or endorsed by Outfit7. Ship
> it with the "unofficial / not affiliated" disclaimer the way the other tool on
> the site notes it is unaffiliated with Anthropic.

---

## Requirements

- **macOS** on Intel or Apple Silicon.
- Internet for the one-time setup, for the voices (a free Microsoft endpoint),
  and - only if you turn on AI cleaning/translation - for the Anthropic API.
- **No Python needed.** `setup.command` installs its own via
  [uv](https://astral.sh/uv) (a uv-managed CPython build that includes Tkinter).
- **No ffmpeg required.**

## Install

1. Unzip `talking-tom-1.2.0.zip`.
2. Read the macOS security notes below before opening `setup.command`. This is an unsigned source installer, not an Apple-notarized app.
3. It bootstraps `uv`, installs a private Python + the dependencies into
   `~/.talking_tom/`, and builds `~/Applications/Talking Tom.app` (with a Desktop
   alias). ~2 minutes. The downloaded folder can be deleted afterward.

Re-run `setup.command` any time to upgrade in place; it keeps `config.json`.

`run.command` is a fallback launcher (`./run.command ~/Desktop/paper.pdf` opens a
file on launch); normally you'd just open the app from Applications.

## Get an Anthropic API key (optional)

AI cleaning is the only part that costs money, and it is optional - without a key
the app falls back to a fast built-in rule-based cleaner that is completely free.

1. Sign in at **console.anthropic.com**.
2. Add a little credit under **Billing** (a few dollars lasts a long time - a
   typical paper cleaned with Claude Haiku is around 1-8 cents).
3. **API keys -> Create key**, copy the `sk-ant-...` value.
4. Launch the app, click **Settings**, paste the key, pick a model, **Save**.

The key is written to `~/.talking_tom/config.json` with `600` permissions and is
never sent anywhere except Anthropic. You can also set `ANTHROPIC_API_KEY` in your
environment instead.

## Use

```
./run.command                     # launch
./run.command ~/Desktop/paper.pdf # launch and start converting that file
```

- **Listen to a document** - pick a PDF, `.docx`, or text file; it is cleaned,
  voiced, and starts playing in one step. Or drag a file onto the window.
  (Old binary `.doc` isn't supported - save as `.docx` first.)
- **Paste text** into the box and hit **Generate Audio**.
- **Voice / Speed / Cleaning / Read in** dropdowns set the voice, the generated
  speaking rate, how hard it cleans (`AI (Claude)` / `Built-in` / `Off`), and the
  output language (see above). Interface language is in **Settings**.
- **Clean Only** transforms the text box without making audio; **Translate**
  swaps English<->Spanish in place.
- The line above the text box is a live **estimate**: word count, listen time,
  and - when AI cleaning is on - the approximate Claude cost for this run
  (`<1¢`, `~4¢`, ...). Audio generation is always free. Runs estimated over ~50¢
  ask for confirmation first.
- **Player** - click or drag on the waveform to scrub, `±10s` buttons, and a
  speed slider (0.5x-2x) that preserves pitch. The slider works from any speed
  and no matter what rate the clip was generated at. Native macOS playback changes tempo in place, preserving pitch and the current position.
- Output MP3s and their transcripts are saved to `~/Talking Tom/`.
  **Save Audio As...** (Cmd+S) exports a copy elsewhere.

## Where things live

| Path | What |
|---|---|
| `app/talking_tom.py` | the entire application |
| `app/header.png`, `app/icon.icns` | in-window badge + `.icns` app/launcher icon (the cat) |
| `app/make_icon.py` | rebuilds `icon.icns` + `header.png` from `logo_src.png` (not shipped - drop one in, or it draws a headphones mark): `python make_icon.py <out_dir> [source.png]` |
| `~/.talking_tom/app/`, `~/.talking_tom/venv/` | where `setup.command` installs the app + its private Python |
| `~/.talking_tom/config.json` | saved settings + API key (created on first run, `600` perms) |
| `~/Applications/Talking Tom.app` | the launcher `setup.command` builds (`osacompile` applet -> runs the venv python) |
| `~/Talking Tom/` | generated `.mp3` files and `.txt` transcripts |

## The stack

| Layer | Choice | Notes |
|---|---|---|
| Packaging | `setup.command` + **uv** | uv installs a private CPython (Tkinter included), builds the venv, and `osacompile`s the `.app`. No system Python. The locally built launcher has an ad hoc signature, not a Developer ID signature or Apple notarization |
| UI | **Tkinter / ttk** | stdlib; custom-drawn rounded buttons and waveform canvas because Tk ignores colors on macOS |
| i18n | `STRINGS` dict (`en`/`es`) + `t()` | interface only; code stays English. First-run prompt (`_first_run_language`); language change re-execs the process |
| Content language | `readin` setting (`auto`/`en`/`es`) + `_guess_lang()` | independent of the UI; drives translation + voice list |
| Drag & drop | **tkinterdnd2** | optional; window still works without it |
| Text extraction | **pypdf** + **python-docx** | PDF and `.docx` (paragraphs + table cells) -> text; `.txt` read directly. Both optional; missing one just disables that format |
| Cleaning (offline) | regex rules in `HeuristicCleaner` | English + Spanish abbreviation / punctuation maps (`lang` arg) |
| Cleaning + translation (AI) | **anthropic** SDK, Claude Haiku 4.5 or Sonnet 5 | chunked ~9k chars/request, lazy import; `TTS_CLEAN_SYSTEM` has `en`/`es` prompts, `TTS_CLEAN_TRANSLATE` adds clean-and-translate prompts |
| Text to speech | **edge-tts** | 8 English + 6 Spanish Edge neural voices, rate control, retry/split on failure; free |
| Playback | **macOS AVAudioPlayer** | Native file playback; 0.5x–2x speed changes preserve pitch and position without rebuilding the audio |
| Speed change | **AVAudioPlayer rate** | Applied directly on the main UI thread; no length cap or competing speed-conversion workers |
| Waveform | **AVAudioFile + NumPy** | Reads small samples from the file; no whole-recording decode |
| Duration | **AVAudioPlayer** | Native audio-file duration |

## Cost model

- **Text to speech: free.** edge-tts uses a public Microsoft endpoint, no key.
- **AI cleaning: paid, optional.** Estimated in-app before each run from a
  chars/4 token estimate against list prices (Haiku 4.5 $1/$5 per MTok,
  Sonnet 5 $2/$10 per MTok), counting the system prompt once per chunk and
  assuming output ~90% of input length. It reads slightly high on purpose.
  See `estimate_clean_cost()` in `app/talking_tom.py`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `setup.command` is blocked by macOS | Read the security notes below; do not disable Gatekeeper or remove quarantine flags |
| setup fails downloading uv / packages | no network, or a proxy - connect and re-run `setup.command` |
| "No Claude key yet - used the built-in cleaner" | expected without a key; add one in Settings for AI cleaning |
| Voices fail / time out | transient Edge outage or no network; it retries 3x per chunk |
| Speed changes | Works from 0.5x to 2x relative to the saved recording, regardless of the original generation rate; no one-hour limit |
| the `.app` won't open after setup | rare; run `~/.talking_tom/venv/bin/python ~/.talking_tom/app/talking_tom.py` or `run.command` and check `~/.talking_tom/last_run.log` |

## Version 1.0.1 — September 15, 2026

Packages the updated September 3 app: stop an active job, receive warnings about PDF pages without extractable text, and avoid duplicate running instances. Includes clearer file and connection errors and improvements to settings and background work.

Quit Talking Tom before running setup to upgrade. Existing settings, audio, and transcripts are preserved.

## Versión 1.0.1 — 15 de septiembre de 2026

Incluye la aplicación actualizada el 3 de septiembre: permite detener una tarea en curso, avisa cuando hay páginas PDF sin texto extraíble y evita abrir varias instancias. Mejora los mensajes de error, los ajustes y el trabajo en segundo plano.

Cierra Talking Tom antes de ejecutar setup.command para actualizar. Se conservan los ajustes, el audio y las transcripciones.

## macOS security and API keys

This source installer is **not signed with Developer ID or notarized by Apple**. Apple may therefore say it cannot verify the developer or check for malicious software. This package does not remove quarantine flags or disable Gatekeeper. See [Apple’s explanation](https://support.apple.com/102445). If macOS says the software “will damage your computer” or contains malware, stop and report the exact message; do not bypass that warning.

No API key is supplied. The example key is empty. Each user supplies their own Anthropic API key in Settings; the app stores it locally, outside this download. Personal settings, logs, documents, audio, and transcripts are excluded from the release.

## Seguridad de macOS y claves de API

Este instalador desde el código fuente **no está firmado con Developer ID ni notarizado por Apple**. Por eso, macOS puede indicar que no puede verificar al desarrollador o comprobar si contiene software malicioso. El paquete no elimina los indicadores de cuarentena ni desactiva Gatekeeper. Consulta [la explicación de Apple](https://support.apple.com/es-es/102445). Si macOS indica que el software dañará tu ordenador o contiene malware, detén la instalación y comunica el mensaje exacto; no omitas ese aviso.

No se incluye ninguna clave de API. La clave del archivo de ejemplo está vacía. Cada persona introduce su propia clave de Anthropic en Ajustes; se guarda localmente, fuera de esta descarga. La distribución no incluye ajustes personales, registros, documentos, audio ni transcripciones.

### Opening the unsigned installer

If Apple says it cannot verify `setup.command`, and you trust this download and choose to proceed: try opening `setup.command`, then go to **System Settings → Privacy & Security → Open Anyway** and confirm **Open**. This creates an exception for this installer. Do not use these steps if macOS reports actual malware or says the software will damage your computer.

### Abrir el instalador sin firma

Si Apple indica que no puede verificar `setup.command`, y confías en esta descarga y decides continuar: intenta abrir `setup.command`, ve a **Ajustes del Sistema → Privacidad y seguridad → Abrir igualmente** y confirma con **Abrir**. Así se crea una excepción para este instalador. No sigas estos pasos si macOS detecta malware o indica que el software dañará tu ordenador.

## Version 1.1.0 — Compact player

Shrink the window below 760 pixels wide or 650 pixels tall to show only the player. The minimum size is 380 × 270 pixels, with the track name, waveform, time, transport buttons, and playback speed. Enlarge the window or click **Full app** to return to the editor. Resizing keeps audio playing and preserves your text. The normal launch size is retained when you close the compact player. Quit and reopen Talking Tom after upgrading.

## Versión 1.1.0 — Reproductor compacto

Reduce la ventana a menos de 760 píxeles de ancho o 650 de alto para mostrar solo el reproductor. El tamaño mínimo es de 380 × 270 píxeles, con el nombre del audio, la onda, los tiempos, los controles de reproducción y la velocidad. Amplía la ventana o pulsa **Ampliar** para volver al editor. El audio sigue reproduciéndose y el texto se conserva. Al cerrar el reproductor compacto se mantiene el tamaño normal de inicio. Cierra y vuelve a abrir Talking Tom después de actualizar.

## Version 1.2.0 — Reliable playback speed

Native macOS playback replaces whole-file in-memory time stretching. Speed changes from 0.5x to 2x work on long recordings without the previous one-hour cap, including recordings generated at 1x or another speed. The multiplier is relative to the saved audio: 1x plays the file as generated. Rapid slider changes use the latest selection; paused playback stays paused and the source position is preserved. Waveforms are sampled in small chunks. Compact playback from version 1.1.0 remains available.

Run setup.command to install the new macOS audio dependency. Quit and reopen Talking Tom after upgrading.

## Versión 1.2.0 — Velocidad de reproducción fiable

La reproducción nativa de macOS sustituye el procesamiento del archivo completo en memoria. Los cambios de 0,5x a 2x funcionan con grabaciones largas sin el antiguo límite de una hora, tanto si se generaron a 1x como a otra velocidad. El multiplicador se aplica al audio guardado: 1x reproduce el archivo tal como se generó. Al mover rápidamente el control se aplica la última selección; se mantienen la pausa y la posición del audio. La onda se obtiene leyendo pequeños fragmentos. Se conserva el reproductor compacto de la versión 1.1.0.

Ejecuta setup.command para instalar la nueva dependencia de audio de macOS. Cierra y vuelve a abrir Talking Tom después de actualizar.
