#!/usr/bin/env python3
"""Install or remove claude-rate-limit-resumer for the current macOS user."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import stat
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


APP_NAME = "claude-rate-limit-resumer"
SOURCE = Path(__file__).with_name("resumer.py")
INSTALL_DIR = Path.home() / ".local/share" / APP_NAME
INSTALLED_SCRIPT = INSTALL_DIR / "resumer.py"
SETTINGS = Path.home() / ".claude/settings.json"


def read_settings() -> dict[str, Any]:
    if not SETTINGS.exists():
        return {}
    with SETTINGS.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"{SETTINGS} must contain a JSON object")
    return data


def atomic_write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f".tmp-{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)
        handle.write("\n")
    os.replace(temporary, path)


def is_our_handler(handler: Any) -> bool:
    if not isinstance(handler, dict):
        return False
    command = str(handler.get("command", ""))
    return APP_NAME in command and (command.endswith("resumer.py") or "resumer.py" in command)


def remove_hook(settings: dict[str, Any]) -> bool:
    hooks = settings.get("hooks")
    if not isinstance(hooks, dict):
        return False
    groups = hooks.get("StopFailure")
    if not isinstance(groups, list):
        return False

    changed = False
    kept_groups: list[Any] = []
    for group in groups:
        if not isinstance(group, dict) or not isinstance(group.get("hooks"), list):
            kept_groups.append(group)
            continue
        kept_handlers = [handler for handler in group["hooks"] if not is_our_handler(handler)]
        if len(kept_handlers) != len(group["hooks"]):
            changed = True
        if kept_handlers:
            updated = dict(group)
            updated["hooks"] = kept_handlers
            kept_groups.append(updated)

    if kept_groups:
        hooks["StopFailure"] = kept_groups
    else:
        hooks.pop("StopFailure", None)
    if not hooks:
        settings.pop("hooks", None)
    return changed


def add_hook(settings: dict[str, Any]) -> None:
    remove_hook(settings)
    hooks = settings.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        raise ValueError("The existing 'hooks' setting must be a JSON object")
    groups = hooks.setdefault("StopFailure", [])
    if not isinstance(groups, list):
        raise ValueError("The existing hooks.StopFailure setting must be a JSON array")
    groups.append(
        {
            "matcher": "rate_limit",
            "hooks": [
                {
                    "type": "command",
                    "command": str(INSTALLED_SCRIPT),
                    "args": ["hook"],
                    "timeout": 10,
                }
            ],
        }
    )


def backup_settings() -> Path | None:
    if not SETTINGS.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = SETTINGS.with_name(f"settings.json.backup-{APP_NAME}-{stamp}")
    shutil.copy2(SETTINGS, backup)
    return backup


def install() -> int:
    if sys.version_info < (3, 9):
        print("Python 3.9 or newer is required.", file=sys.stderr)
        return 1
    if shutil.which("tmux") is None:
        print("tmux is required. Install it with: brew install tmux", file=sys.stderr)
        return 1

    settings = read_settings()
    backup = backup_settings()
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, INSTALLED_SCRIPT)
    INSTALLED_SCRIPT.chmod(INSTALLED_SCRIPT.stat().st_mode | stat.S_IXUSR)
    add_hook(settings)
    atomic_write(SETTINGS, settings)

    print(f"Installed {INSTALLED_SCRIPT}")
    print(f"Updated {SETTINGS}")
    if backup:
        print(f"Backup: {backup}")
    print("\nRun Claude Code inside tmux, then resume your existing conversation:")
    print("  tmux new-session -A -s claude-work")
    print("  claude --continue")
    print("\nInside Claude Code, run /hooks and confirm StopFailure → rate_limit is listed.")
    return 0


def uninstall() -> int:
    settings = read_settings()
    changed = remove_hook(settings)
    if changed:
        backup = backup_settings()
        atomic_write(SETTINGS, settings)
        print(f"Removed hook from {SETTINGS}")
        if backup:
            print(f"Backup: {backup}")
    else:
        print("No installed hook was found.")
    if INSTALLED_SCRIPT.exists():
        INSTALLED_SCRIPT.unlink()
        print(f"Removed {INSTALLED_SCRIPT}")
    try:
        INSTALL_DIR.rmdir()
    except OSError:
        pass
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("install", "uninstall"), nargs="?", default="install")
    args = parser.parse_args()
    try:
        return install() if args.action == "install" else uninstall()
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"Installation failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
