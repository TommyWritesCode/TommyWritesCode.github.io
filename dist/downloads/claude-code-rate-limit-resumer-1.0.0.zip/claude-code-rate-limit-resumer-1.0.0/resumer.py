#!/usr/bin/env python3
"""Claude Code StopFailure hook that resumes a tmux-hosted session after reset."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


RESET_RE = re.compile(
    r"\bresets?\s+"
    r"(?P<hour>\d{1,2}):(?P<minute>\d{2})\s*"
    r"(?P<meridiem>a\.?m\.?|p\.?m\.?)\s*"
    r"\((?P<timezone>[A-Za-z0-9_+\-/]+)\)",
    re.IGNORECASE,
)

APP_NAME = "claude-rate-limit-resumer"
PROMPT = "continue work"
GRACE_SECONDS = 60


def state_root() -> Path:
    configured = os.environ.get("XDG_STATE_HOME")
    return Path(configured).expanduser() / APP_NAME if configured else Path.home() / ".local/state" / APP_NAME


def safe_session_key(session_id: str) -> str:
    return hashlib.sha256(session_id.encode("utf-8")).hexdigest()[:24]


def session_label(session_id: str) -> str:
    """Return a non-reversible identifier suitable for local logs."""
    return safe_session_key(session_id)[:12]


def session_paths(session_id: str) -> tuple[Path, Path, Path]:
    root = state_root()
    key = safe_session_key(session_id)
    return root / f"{key}.json", root / f"{key}.lock", root / "resumer.log"


def append_log(message: str) -> None:
    root = state_root()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    root.chmod(0o700)
    timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
    log_path = root / "resumer.log"
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(f"{timestamp} {message}\n")
    log_path.chmod(0o600)


def parse_reset_time(text: str, now: datetime | None = None) -> datetime:
    """Return the next reset instant mentioned in Claude's rate-limit text."""
    match = RESET_RE.search(text)
    if not match:
        raise ValueError("No reset time with an IANA timezone was found")

    hour = int(match.group("hour"))
    minute = int(match.group("minute"))
    if hour < 1 or hour > 12 or minute > 59:
        raise ValueError("Invalid reset clock time")

    meridiem = match.group("meridiem").replace(".", "").lower()
    hour_24 = hour % 12 + (12 if meridiem == "pm" else 0)
    timezone_name = match.group("timezone")
    try:
        timezone = ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"Unknown timezone: {timezone_name}") from exc

    current = (now or datetime.now(timezone)).astimezone(timezone)
    reset = current.replace(hour=hour_24, minute=minute, second=0, microsecond=0)
    if reset <= current:
        reset += timedelta(days=1)
    return reset


def combined_error_text(payload: dict[str, Any]) -> str:
    fields = (payload.get("last_assistant_message"), payload.get("error_details"))
    return "\n".join(value for value in fields if isinstance(value, str))


def visible_pane_text(pane: str) -> str:
    """Return a bounded pane snapshot for reset-time parsing only."""
    result = subprocess.run(
        ["tmux", "capture-pane", "-p", "-t", pane, "-S", "-300"],
        text=True,
        capture_output=True,
        check=False,
    )
    return result.stdout if result.returncode == 0 else ""


def read_json(path: Path) -> dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def write_json_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    path.parent.chmod(0o700)
    temporary = path.with_suffix(f".tmp-{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
        handle.write("\n")
    temporary.chmod(0o600)
    os.replace(temporary, path)


def pid_is_alive(pid: Any) -> bool:
    if not isinstance(pid, int) or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


def notify(title: str, body: str) -> None:
    if sys.platform != "darwin":
        return
    script = "display notification (item 2 of argv) with title (item 1 of argv)"
    subprocess.run(
        ["osascript", "-e", f"on run argv\n{script}\nend run", title, body],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )


def schedule(payload: dict[str, Any]) -> int:
    if payload.get("hook_event_name") != "StopFailure" or payload.get("error") != "rate_limit":
        return 0

    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        append_log("Ignored rate limit event without a session ID")
        return 0

    pane = os.environ.get("TMUX_PANE")
    label = session_label(session_id)
    if not pane:
        append_log(f"Could not schedule session {label}: Claude Code is not running in tmux")
        notify(APP_NAME, "Rate limit detected, but this Claude session is not running in tmux.")
        return 0

    error_text = combined_error_text(payload)
    try:
        reset_at = parse_reset_time(error_text)
    except ValueError:
        # Some Claude Code versions render the friendly reset time in the TUI
        # while StopFailure contains only a generic 429 message.
        try:
            reset_at = parse_reset_time(visible_pane_text(pane))
        except ValueError as exc:
            append_log(f"Could not schedule session {label}: {exc}")
            notify(APP_NAME, "Rate limit detected, but the reset time could not be parsed.")
            return 0

    send_at = reset_at + timedelta(seconds=GRACE_SECONDS)
    state_path, lock_path, log_path = session_paths(session_id)
    state_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    state_path.parent.chmod(0o700)

    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        lock_path.chmod(0o600)
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
        existing = read_json(state_path)
        if (
            existing.get("status") == "waiting"
            and existing.get("send_at") == send_at.isoformat()
            and pid_is_alive(existing.get("worker_pid"))
        ):
            append_log(f"Duplicate rate limit event ignored for session {label}")
            return 0

        token = uuid.uuid4().hex
        command = [
            sys.executable,
            str(Path(__file__).resolve()),
            "worker",
            "--session-id",
            session_id,
            "--pane",
            pane,
            "--send-at",
            send_at.isoformat(),
            "--token",
            token,
        ]
        log_handle = log_path.open("a", encoding="utf-8")
        try:
            worker = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=log_handle,
                stderr=log_handle,
                start_new_session=True,
                close_fds=True,
            )
        finally:
            log_handle.close()

        state = {
            "session_id": session_id,
            "pane": pane,
            "reset_at": reset_at.isoformat(),
            "send_at": send_at.isoformat(),
            "status": "waiting",
            "token": token,
            "worker_pid": worker.pid,
        }
        write_json_atomic(state_path, state)

    append_log(f"Scheduled session {label} for {send_at.isoformat()} in pane {pane}")
    notify(APP_NAME, f"Claude will resume at {send_at.strftime('%-I:%M %p %Z')}.")
    return 0


def worker_is_current(session_id: str, token: str) -> bool:
    state_path, _, _ = session_paths(session_id)
    state = read_json(state_path)
    return state.get("token") == token and state.get("status") == "waiting"


def pane_is_claude(pane: str) -> tuple[bool, str]:
    result = subprocess.run(
        ["tmux", "display-message", "-p", "-t", pane, "#{pane_dead}|#{pane_current_command}"],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        return False, "tmux pane no longer exists"

    raw = result.stdout.strip()
    dead, _, command = raw.partition("|")
    command_lower = Path(command).name.lower()
    if dead == "1":
        return False, "tmux pane is dead"
    if "claude" in command_lower:
        return True, command

    # Older npm-based Claude Code installs can appear as node or bun in tmux.
    if command_lower in {"node", "bun"}:
        visible = visible_pane_text(pane).lower()
        if "claude code" in visible or "you've hit your session limit" in visible:
            return True, command

    return False, f"foreground command is {command or 'unknown'}, not Claude Code"


def update_status(session_id: str, token: str, status: str, detail: str | None = None) -> None:
    state_path, lock_path, _ = session_paths(session_id)
    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        lock_path.chmod(0o600)
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
        state = read_json(state_path)
        if state.get("token") != token:
            return
        state["status"] = status
        state["completed_at"] = datetime.now().astimezone().isoformat()
        if detail:
            state["detail"] = detail
        write_json_atomic(state_path, state)


def run_worker(session_id: str, pane: str, send_at_text: str, token: str) -> int:
    label = session_label(session_id)
    try:
        send_at = datetime.fromisoformat(send_at_text)
    except ValueError:
        append_log(f"Worker received an invalid send time for session {label}")
        return 2

    while True:
        if not worker_is_current(session_id, token):
            append_log(f"Superseded worker exited for session {label}")
            return 0
        seconds_left = (send_at - datetime.now().astimezone()).total_seconds()
        if seconds_left <= 0:
            break
        time.sleep(min(seconds_left, 30))

    okay, reason = pane_is_claude(pane)
    if not okay:
        update_status(session_id, token, "not-sent", reason)
        append_log(f"Did not resume session {label}: {reason}")
        notify(APP_NAME, f"Claude was not resumed: {reason}.")
        return 1

    literal = subprocess.run(
        ["tmux", "send-keys", "-t", pane, "-l", PROMPT],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    enter = subprocess.run(
        ["tmux", "send-keys", "-t", pane, "Enter"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if literal.returncode != 0 or enter.returncode != 0:
        detail = (literal.stderr or enter.stderr or "tmux send-keys failed").strip()
        update_status(session_id, token, "not-sent", detail)
        append_log(f"Failed to resume session {label}: {detail}")
        notify(APP_NAME, "Claude could not be resumed; check the resumer log.")
        return 1

    update_status(session_id, token, "sent", f"Sent {PROMPT!r} to {pane}")
    append_log(f"Sent {PROMPT!r} to session {label} in pane {pane}")
    notify(APP_NAME, "Sent “continue work” to Claude Code.")
    return 0


def show_status() -> int:
    root = state_root()
    states = sorted(root.glob("*.json"), key=lambda path: path.stat().st_mtime, reverse=True)
    if not states:
        print("No rate-limit events recorded.")
        return 0
    state = read_json(states[0])
    for key in ("status", "reset_at", "send_at", "pane", "detail"):
        if key in state:
            print(f"{key}: {state[key]}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("hook", help="Read a Claude Code hook event from stdin")
    subparsers.add_parser("status", help="Show the most recent scheduled event")
    worker_parser = subparsers.add_parser("worker", help=argparse.SUPPRESS)
    worker_parser.add_argument("--session-id", required=True)
    worker_parser.add_argument("--pane", required=True)
    worker_parser.add_argument("--send-at", required=True)
    worker_parser.add_argument("--token", required=True)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command == "hook":
        try:
            payload = json.load(sys.stdin)
        except json.JSONDecodeError:
            append_log("Ignored malformed hook JSON")
            return 0
        return schedule(payload if isinstance(payload, dict) else {})
    if args.command == "worker":
        return run_worker(args.session_id, args.pane, args.send_at, args.token)
    return show_status()


if __name__ == "__main__":
    raise SystemExit(main())
