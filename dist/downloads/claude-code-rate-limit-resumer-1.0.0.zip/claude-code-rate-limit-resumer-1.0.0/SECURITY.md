# Security

## Scope

This utility installs a local Claude Code command hook. Command hooks execute
with the permissions of the logged-in user. Users should inspect the release
before installing it and download it only from a trusted source.

The utility is intentionally narrow: it parses rate-limit metadata, schedules
a local worker, validates that Claude Code still owns the recorded `tmux` pane,
and sends the fixed prompt `continue work`. It does not make network requests,
handle API credentials, or inspect repository contents.

## Reporting a vulnerability

Please report suspected vulnerabilities through the contact method published
on tommynicol.com. Do not include credentials, private source code, or other
sensitive data in the initial report.
