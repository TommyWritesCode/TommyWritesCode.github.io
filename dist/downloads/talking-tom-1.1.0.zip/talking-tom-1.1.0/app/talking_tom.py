#!/usr/bin/env python3
"""
Talking Tom - Free Text-to-Speech using Microsoft Edge TTS
Pitt Colors Edition - Navy & Gold

Workflow:  drop / open a PDF or TXT  ->  Clean (AI or built-in)  ->  Generate audio  ->  listen.

Optional AI cleaning uses the Anthropic (Claude) API.  Set an API key with any of:
  * the "Settings" button in the app
  * an ANTHROPIC_API_KEY environment variable
  * ~/.talking_tom/config.json  ->  {"anthropic_api_key": "sk-ant-..."}
Without a key the app falls back to the built-in rule-based cleaner (still free).
"""

import os
import sys
import json
import queue
import fcntl
import shutil
import asyncio
import threading
import subprocess
import re
import time
from pathlib import Path
from datetime import datetime

APP_NAME = "Talking Tom"
IS_FROZEN = getattr(sys, "frozen", False)

# ============ Config file ============
CONFIG_DIR = Path.home() / ".talking_tom"
CONFIG_FILE = CONFIG_DIR / "config.json"
STORAGE_DIR = Path.home() / "Talking Tom"
LOCK_FILE = CONFIG_DIR / "app.lock"
OPEN_REQUEST = CONFIG_DIR / "open_request"   # a 2nd launch hands its file to the 1st


class Cancelled(Exception):
    """Raised inside a worker when the user presses Stop."""


# ---- single instance -------------------------------------------------------
_LOCK_FH = None


def acquire_single_instance(wait_s: float = 0.0) -> bool:
    """Exclusive lock so only one Talking Tom runs at a time."""
    global _LOCK_FH
    deadline = time.time() + wait_s
    while True:
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            _LOCK_FH = open(LOCK_FILE, "a+")
            fcntl.flock(_LOCK_FH.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            _LOCK_FH.seek(0)
            _LOCK_FH.truncate()
            _LOCK_FH.write(str(os.getpid()))
            _LOCK_FH.flush()
            return True
        except OSError:
            if _LOCK_FH is not None:
                try:
                    _LOCK_FH.close()
                except OSError:
                    pass
                _LOCK_FH = None
            if time.time() >= deadline:
                return False
            time.sleep(0.2)


def release_single_instance():
    global _LOCK_FH
    if _LOCK_FH is None:
        return
    try:
        fcntl.flock(_LOCK_FH.fileno(), fcntl.LOCK_UN)
        _LOCK_FH.close()
    except OSError:
        pass
    _LOCK_FH = None


def _migrate_legacy():
    """Carry over settings + audio from the old 'Simple TTS' name."""
    old_cfg = Path.home() / ".simple_tts" / "config.json"
    if old_cfg.is_file() and not CONFIG_FILE.exists():
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            shutil.copy2(old_cfg, CONFIG_FILE)
        except Exception:
            pass
    old_out = Path.home() / "TTS_Output"
    if old_out.is_dir() and not STORAGE_DIR.exists():
        try:
            old_out.rename(STORAGE_DIR)
        except Exception:
            pass


_migrate_legacy()
STORAGE_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:
        return {}


def save_config(cfg: dict) -> None:
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
        try:
            os.chmod(CONFIG_FILE, 0o600)  # key lives here - keep it private
        except OSError:
            pass
    except Exception as e:
        print(f"Could not save config: {e}")


CONFIG = load_config()


_KEY_CACHE = {"mtime": None, "value": ""}


def get_api_key() -> str:
    """The Anthropic key, if there is one.

    Re-read from disk so an edit in Settings (or in the file) takes effect at
    once - but keyed on the file's mtime, because this is called on every
    keystroke by the live estimate and a stat() is far cheaper than parsing
    the config each time.
    """
    env = os.getenv("ANTHROPIC_API_KEY")
    if env:
        return env.strip()
    try:
        mtime = CONFIG_FILE.stat().st_mtime_ns
    except OSError:
        mtime = None
    if mtime is None or mtime != _KEY_CACHE["mtime"]:
        _KEY_CACHE["mtime"] = mtime
        _KEY_CACHE["value"] = (load_config().get("anthropic_api_key")
                               or CONFIG.get("anthropic_api_key") or "").strip()
    return _KEY_CACHE["value"]


# ============ Dependency check (dev runs only) ============
def check_and_install_deps():
    """Only used when running from source without the launcher. Never in a bundled app."""
    if IS_FROZEN:
        return
    required = {"edge_tts": "edge-tts", "pygame": "pygame"}
    missing = [pkg for mod, pkg in required.items() if not _module_available(mod)]
    if missing:
        print(f"Installing missing packages: {', '.join(missing)}")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet"] + missing)
            print("Dependencies installed - please restart the app.")
        except subprocess.CalledProcessError:
            print(f"Please run:  pip install {' '.join(missing)}")
        sys.exit(0)


def _module_available(name: str) -> bool:
    try:
        __import__(name)
        return True
    except ImportError:
        return False


check_and_install_deps()

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, font as tkfont

try:
    import numpy as np
    HAS_NUMPY = True
except Exception:
    HAS_NUMPY = False

import edge_tts
import pygame

# ---- optional bits ----
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    HAS_DND = True
except ImportError:
    HAS_DND = False

try:
    import pypdf
    HAS_PDF = True
except ImportError:
    try:
        import PyPDF2 as pypdf  # older name
        HAS_PDF = True
    except ImportError:
        HAS_PDF = False

try:
    import docx  # python-docx
    HAS_DOCX = True
except Exception:
    HAS_DOCX = False

try:
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter("ignore", SyntaxWarning)   # pydub 0.25 ships bad regex escapes
        from pydub import AudioSegment
    HAS_PYDUB = True
except Exception:
    HAS_PYDUB = False

try:
    from mutagen.mp3 import MP3
    HAS_MUTAGEN = True
except Exception:
    HAS_MUTAGEN = False


def find_ffmpeg() -> str:
    cand = shutil.which("ffmpeg")
    if cand:
        return cand
    for p in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/usr/bin/ffmpeg"):
        if os.path.exists(p):
            return p
    return ""


FFMPEG = find_ffmpeg()

# ============================================================================
#  Language / localization
# ============================================================================
# One build, two interface languages. English is the source; Spanish (es) is a
# faithful translation of the interface - the code stays in English. On first run
# the app asks which language to use; it can be changed later in Settings, and a
# language change relaunches the app.
#
# The interface language is separate from the *content* language: "Read in"
# (auto / English / Spanish) drives whether the cleaning pass also translates the
# text and which voice speaks it, no matter what language the buttons are in.
def _locale_guess() -> str:
    for src in (os.environ.get("LANGUAGE"), os.environ.get("LC_ALL"),
                os.environ.get("LC_MESSAGES"), os.environ.get("LANG")):
        if src and src.lower().lstrip("_").startswith("es"):
            return "es"
    try:
        import locale
        loc = (locale.getlocale()[0] or "") or (locale.getdefaultlocale()[0] or "")
        if loc.lower().startswith("es"):
            return "es"
    except Exception:
        pass
    return "en"


def _detect_lang():
    saved = (CONFIG.get("lang") or "").lower()
    if saved in ("en", "es"):
        return saved, True
    return _locale_guess(), False


LANG, LANG_SAVED = _detect_lang()
UI_LANG_LABELS = {"en": "English", "es": "Español"}

STRINGS = {
    "en": {
        "settings": "Settings",
        "hero_btn": "▶   Listen to a document",
        "hero_caption": "Pick a PDF or text file — cleaned for listening, voiced, "
                        "and playing in one step.",
        "lbl_voice": "Voice", "lbl_speed": "Speed", "lbl_cleaning": "Cleaning",
        "lbl_language": "Language", "lbl_readin": "Read in",
        "first_run_prompt": "Choose your language     ·     Elige tu idioma",
        "st_translate_needs_ai": "Translating needs a Claude key. Add one in Settings.",
        "st_translating": "Cleaning and translating {i}/{n}…",
        "lang_name_en": "English", "lang_name_es": "Spanish",
        "st_translate_to": "Translating to {lang}…",
        "st_translated": "Translated to {lang}.",
        "btn_open_file": "Open File", "btn_open_audio": "Open Audio",
        "btn_clean_only": "Clean Only", "btn_translate": "Translate",
        "btn_generate": "Generate Audio", "btn_stop_work": "Stop",
        "st_stopping": "Stopping…", "st_stopped": "Stopped.",
        "msg_pdf_partial": ("Heads up: {n} of {total} pages had no text to extract "
                            "(they are probably scanned images).\n\n"
                            "Those pages need OCR before Talking Tom can read them. "
                            "The rest of the document loaded fine."),
        "st_pdf_partial": "Loaded “{name}” · {n:,} characters · {skipped} of {total} pages had no text",
        "player": "PLAYER", "show_in_finder": "Show in Finder",
        "wave_placeholder": "the waveform shows up here once you make audio",
        "speed": "SPEED", "btn_play": "Play", "btn_pause": "Pause", "btn_stop": "Stop",
        "placeholder": ("Paste text here — or drag a PDF, Word, or text file onto this window,\n"
                        "or drop one on the Talking Tom icon and it just plays."),
        "m_file": "File", "m_listen_doc": "Listen to a Document…",
        "m_open_file": "Open File…", "m_open_audio": "Open Audio…",
        "m_save_audio": "Save Audio As…", "m_show_output": "Show Output Folder",
        "m_playback": "Playback", "m_play_pause": "Play / Pause",
        "m_back10": "Back 10 seconds", "m_fwd10": "Forward 10 seconds",
        "m_api_model": "Language, API Key & Model…",
        "dlg_select_doc": "Select a document", "dlg_select_audio": "Select audio",
        "dlg_pick_listen": "Pick something to listen to",
        "ft_text_pdf": "Text, PDF & Word", "ft_all": "All files", "ft_audio": "Audio", "ft_mp3": "MP3",
        "msg_need_text": "Load or paste some text first.",
        "msg_file_not_found": "File not found:\n{path}",
        "msg_cant_read": "Could not read that file:\n{err}",
        "msg_no_text": ("No text found in that file.\n"
                        "If it is a scanned PDF it needs OCR first."),
        "msg_cant_load_audio": "Could not load audio:\n{err}",
        "msg_need_audio": "Generate or open some audio first.",
        "err_old_doc": "Old .doc files aren’t supported — save it as .docx or .txt first.",
        "err_not_text": ("That “{ext}” file isn’t readable as text.\n"
                         "Talking Tom reads PDF, Word (.docx) and plain text files."),
        "err_offline": ("Couldn’t reach the voice service.\n"
                        "Check your internet connection and try again."),
        "st_busy_wait": "Still working — press Stop first.",
        "st_lang_busy": "Finish or stop the current job before switching language.",
        "msg_key_looks_wrong": ("That doesn’t look like an Anthropic key "
                                "(they start with “sk-ant-”).\n\nSave it anyway?"),
        "confirm_cost": ("Cleaning this text with {name} will cost roughly {cost} "
                         "in Claude API usage.\n\nContinue?"),
        "st_loaded": "Loaded “{name}” · {n:,} characters",
        "st_ready_play": "Ready to play “{name}”",
        "st_no_key_builtin": "No Claude key yet — used the built-in cleaner. Add one in Settings.",
        "st_claude_unavailable": "Claude cleaning unavailable ({err}). Used the built-in cleaner.",
        "st_ai_cleaning": "AI cleaning {i}/{n}…",
        "st_synth": "Synthesizing {i}/{n}…",
        "st_cleaned": "Cleaned — trimmed {n:,} characters ({pct:.0f}%)",
        "st_nothing_to_speak": "Nothing left to speak after cleaning.",
        "st_ready_done": "Ready · “{name}” · {dur} · transcript saved alongside",
        "st_didnt_work": "That didn’t work.",
        "st_saved_to": "Saved to {dest}",
        "st_clip_too_long": "That clip is too long to change speed smoothly.",
        "st_speed_unavailable": "Couldn't prepare this clip for speed change — playing at 1x.",
        "st_adjusting_speed": "Adjusting speed…", "st_normal_speed": "Normal speed",
        "st_no_audio": "No audio device available - the file was still saved to your Talking Tom folder.",
        "st_cant_change_speed": "Couldn’t change speed: {err}", "st_ready": "Ready",
        "st_settings_saved": "Settings saved.", "st_no_key_set": " (no key set)",
        "st_preparing": "Preparing…", "st_cleaning": "Cleaning…",
        "st_working": "Working…", "st_restarting": "Switching to {lang}… relaunching",
        "est_words": "{words:,} words", "est_audio": "~{t} audio",
        "est_free": "free", "est_clean": "clean", "est_with_key": "{tag} with a key",
        "set_title": "Settings", "set_language": "Language / Idioma",
        "set_language_help": "Applied when the app relaunches.",
        "set_api_key": "Anthropic (Claude) API key",
        "set_show": "Show", "set_hide": "Hide",
        "set_key_help": ("From console.anthropic.com → API Keys. Stored only on this Mac\n"
                         "in ~/.talking_tom/config.json (permissions 600)."),
        "set_model": "Cleaning model",
        "set_model_help": ("Only AI cleaning uses the API. The voices (Edge TTS) are free.\n"
                           "The main window shows an estimate before each run."),
        "set_save": "Save", "set_cancel": "Cancel",
    },
    "es": {
        "settings": "Ajustes",
        "hero_btn": "▶   Escuchar un documento",
        "hero_caption": "Elige un PDF o un archivo de texto: se limpia para escuchar, "
                        "se convierte en voz y empieza a reproducirse, todo en un paso.",
        "lbl_voice": "Voz", "lbl_speed": "Velocidad", "lbl_cleaning": "Limpieza",
        "lbl_language": "Idioma", "lbl_readin": "Leer en",
        "first_run_prompt": "Choose your language     ·     Elige tu idioma",
        "st_translate_needs_ai": "Traducir necesita una clave de Claude. Añade una en Ajustes.",
        "st_translating": "Limpiando y traduciendo {i}/{n}…",
        "lang_name_en": "inglés", "lang_name_es": "español",
        "st_translate_to": "Traduciendo a {lang}…",
        "st_translated": "Traducido a {lang}.",
        "btn_open_file": "Abrir archivo", "btn_open_audio": "Abrir audio",
        "btn_clean_only": "Solo limpiar", "btn_translate": "Traducir",
        "btn_generate": "Generar audio", "btn_stop_work": "Detener",
        "st_stopping": "Deteniendo…", "st_stopped": "Detenido.",
        "msg_pdf_partial": ("Aviso: {n} de {total} páginas no tenían texto que extraer "
                            "(seguramente son imágenes escaneadas).\n\n"
                            "Esas páginas necesitan OCR antes de que Talking Tom pueda "
                            "leerlas. El resto del documento se cargó bien."),
        "st_pdf_partial": "Cargado «{name}» · {n:,} caracteres · {skipped} de {total} páginas sin texto",
        "player": "REPRODUCTOR", "show_in_finder": "Mostrar en Finder",
        "wave_placeholder": "la onda de sonido aparece aquí cuando generas audio",
        "speed": "VELOCIDAD", "btn_play": "Reproducir", "btn_pause": "Pausar",
        "btn_stop": "Detener",
        "placeholder": ("Pega texto aquí, o arrastra un archivo PDF, Word o de texto a esta ventana,\n"
                        "o suéltalo sobre el icono de Talking Tom y se reproduce solo."),
        "m_file": "Archivo", "m_listen_doc": "Escuchar un documento…",
        "m_open_file": "Abrir archivo…", "m_open_audio": "Abrir audio…",
        "m_save_audio": "Guardar audio como…", "m_show_output": "Mostrar carpeta de salida",
        "m_playback": "Reproducción", "m_play_pause": "Reproducir / Pausar",
        "m_back10": "Retroceder 10 segundos", "m_fwd10": "Avanzar 10 segundos",
        "m_api_model": "Idioma, clave de API y modelo…",
        "dlg_select_doc": "Selecciona un documento", "dlg_select_audio": "Selecciona un audio",
        "dlg_pick_listen": "Elige algo para escuchar",
        "ft_text_pdf": "Texto, PDF y Word", "ft_all": "Todos los archivos",
        "ft_audio": "Audio", "ft_mp3": "MP3",
        "msg_need_text": "Primero carga o pega algo de texto.",
        "msg_file_not_found": "Archivo no encontrado:\n{path}",
        "msg_cant_read": "No se pudo leer ese archivo:\n{err}",
        "msg_no_text": ("No se encontró texto en ese archivo.\n"
                        "Si es un PDF escaneado, primero necesita OCR."),
        "msg_cant_load_audio": "No se pudo cargar el audio:\n{err}",
        "msg_need_audio": "Primero genera o abre un audio.",
        "err_old_doc": ("Los archivos .doc antiguos no son compatibles: "
                        "guárdalo como .docx o .txt primero."),
        "err_not_text": ("Ese archivo «{ext}» no se puede leer como texto.\n"
                         "Talking Tom lee PDF, Word (.docx) y archivos de texto."),
        "err_offline": ("No se pudo conectar con el servicio de voces.\n"
                        "Comprueba tu conexión a internet e inténtalo de nuevo."),
        "st_busy_wait": "Todavía trabajando: pulsa Detener primero.",
        "st_lang_busy": "Termina o detén el trabajo actual antes de cambiar de idioma.",
        "msg_key_looks_wrong": ("Eso no parece una clave de Anthropic "
                                "(empiezan por «sk-ant-»).\n\n¿Guardarla igualmente?"),
        "confirm_cost": ("Limpiar este texto con {name} costará aproximadamente {cost} "
                         "de uso de la API de Claude.\n\n¿Continuar?"),
        "st_loaded": "Cargado «{name}» · {n:,} caracteres",
        "st_ready_play": "Listo para reproducir «{name}»",
        "st_no_key_builtin": ("Aún no hay clave de Claude: se usó la limpieza integrada. "
                              "Añade una en Ajustes."),
        "st_claude_unavailable": ("Limpieza con Claude no disponible ({err}). "
                                  "Se usó la limpieza integrada."),
        "st_ai_cleaning": "Limpiando con IA {i}/{n}…",
        "st_synth": "Sintetizando voz {i}/{n}…",
        "st_cleaned": "Limpieza lista: se quitaron {n:,} caracteres ({pct:.0f}%)",
        "st_nothing_to_speak": "No queda nada que leer después de la limpieza.",
        "st_ready_done": ("Listo · «{name}» · {dur} · "
                          "transcripción guardada junto al audio"),
        "st_didnt_work": "Eso no funcionó.",
        "st_saved_to": "Guardado en {dest}",
        "st_clip_too_long": "Ese audio es demasiado largo para cambiar la velocidad con fluidez.",
        "st_speed_unavailable": "No se pudo preparar este audio para cambiar la velocidad; se reproduce a 1x.",
        "st_adjusting_speed": "Ajustando la velocidad…", "st_normal_speed": "Velocidad normal",
        "st_no_audio": "No hay dispositivo de audio disponible; el archivo se guardó igualmente en tu carpeta Talking Tom.",
        "st_cant_change_speed": "No se pudo cambiar la velocidad: {err}", "st_ready": "Listo",
        "st_settings_saved": "Ajustes guardados.", "st_no_key_set": " (sin clave)",
        "st_preparing": "Preparando…", "st_cleaning": "Limpiando…",
        "st_working": "Trabajando…", "st_restarting": "Cambiando a {lang}… reiniciando",
        "est_words": "{words:,} palabras", "est_audio": "~{t} de audio",
        "est_free": "gratis", "est_clean": "limpieza", "est_with_key": "{tag} con una clave",
        "set_title": "Ajustes", "set_language": "Idioma / Language",
        "set_language_help": "Se aplica al reiniciar la aplicación.",
        "set_api_key": "Clave de API de Anthropic (Claude)",
        "set_show": "Mostrar", "set_hide": "Ocultar",
        "set_key_help": ("De console.anthropic.com → API Keys. Se guarda solo en este Mac\n"
                         "en ~/.talking_tom/config.json (permisos 600)."),
        "set_model": "Modelo de limpieza",
        "set_model_help": ("Solo la limpieza con IA usa la API. Las voces (Edge TTS) son gratis.\n"
                           "La ventana principal muestra una estimación antes de cada uso."),
        "set_save": "Guardar", "set_cancel": "Cancelar",
    },
}
T = STRINGS[LANG]


def t(key: str, **kw) -> str:
    s = T.get(key) or STRINGS["en"].get(key, key)
    return s.format(**kw) if kw else s


# ============ Voices ============
VOICES = {
    "en": {
        "Jenny (US Female)": "en-US-JennyNeural",
        "Aria (US Female)": "en-US-AriaNeural",
        "Michelle (US Female)": "en-US-MichelleNeural",
        "Guy (US Male)": "en-US-GuyNeural",
        "Christopher (US Male)": "en-US-ChristopherNeural",
        "Eric (US Male)": "en-US-EricNeural",
        "Sonia (UK Female)": "en-GB-SoniaNeural",
        "Ryan (UK Male)": "en-GB-RyanNeural",
    },
    "es": {
        "Elvira (España, F)": "es-ES-ElviraNeural",
        "Álvaro (España, M)": "es-ES-AlvaroNeural",
        "Dalia (México, F)": "es-MX-DaliaNeural",
        "Jorge (México, M)": "es-MX-JorgeNeural",
        "Elena (Argentina, F)": "es-AR-ElenaNeural",
        "Gonzalo (Colombia, M)": "es-CO-GonzaloNeural",
    },
}
ALL_VOICES = {**VOICES["en"], **VOICES["es"]}
EDGE_VOICES = VOICES[LANG]
DEFAULT_VOICE_FOR = {"en": "Jenny (US Female)", "es": "Elvira (España, F)"}
DEFAULT_VOICE = DEFAULT_VOICE_FOR[LANG]

# label -> edge-tts rate string (language-neutral)
SPEECH_RATES = {
    "0.9x": "-10%", "1.0x": "+0%", "1.1x": "+10%", "1.25x": "+25%",
    "1.5x": "+50%", "1.75x": "+75%", "2.0x": "+100%",
}
DEFAULT_RATE = "1.0x"

MODEL_IDS = ("claude-haiku-4-5", "claude-sonnet-5")
MODEL_LABELS = {
    "en": {"claude-haiku-4-5": "Claude Haiku 4.5  (fast, ~1¢/paper)",
           "claude-sonnet-5": "Claude Sonnet 5  (best quality)"},
    "es": {"claude-haiku-4-5": "Claude Haiku 4.5  (rápido, ~1¢/artículo)",
           "claude-sonnet-5": "Claude Sonnet 5  (mejor calidad)"},
}
CLEAN_TOKENS = ("ai", "builtin", "none")
CLEAN_LABELS = {
    "en": {"ai": "AI (Claude)", "builtin": "Built-in", "none": "Off"},
    "es": {"ai": "IA (Claude)", "builtin": "Integrada", "none": "Ninguna"},
}

# "Read in" - the language the audio comes out in, independent of the interface.
READIN_TOKENS = ("auto", "en", "es")
READIN_LABELS = {
    "en": {"auto": "Auto (source)", "en": "English", "es": "Spanish"},
    "es": {"auto": "Auto (original)", "en": "Inglés", "es": "Español"},
}


def _migrate_clean_tok(v) -> str:
    m = {"AI (Claude)": "ai", "Built-in (offline)": "builtin", "Built-in": "builtin",
         "None": "none", "Off": "none"}
    return v if v in CLEAN_TOKENS else m.get(v, "ai")


def _migrate_model_id(v) -> str:
    if v in MODEL_IDS:
        return v
    return "claude-sonnet-5" if (v and "Sonnet" in v) else "claude-haiku-4-5"

COLORS = {
    "navy": "#00327f", "navy_dark": "#001a4d", "navy_light": "#1c4fa3",
    "gold": "#FFB81C", "gold_light": "#ffcb55", "gold_deep": "#e3a200",
    "white": "#ffffff", "text": "#eaf0fb", "text_dim": "#8ea6d4",
    "bg": "#001f5c", "panel": "#00184a", "panel_soft": "#062a6b",
    "border": "#123a86", "highlight": "#2a5aa8",
    "wave_bg": "#001334", "wave_dim": "#274d94",
    "success": "#4ade80", "error": "#f87171",
}


# ============================================================================
#  Text cleaning
# ============================================================================
class HeuristicCleaner:
    """Fast, offline cleanup. Conservative - never rewrites sentences."""

    JUNK_PATTERNS = [
        r'https?://[^\s<>"{}|\\^`\[\]]+',
        r'www\.[^\s<>"{}|\\^`\[\]]+',
        r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
        r'\bdoi:\s*\S+', r'\bISBN[:\s]*[\d\-Xx]+', r'\bISSN[:\s]*[\d\-Xx]+',
        r'OUP CORRECTED PROOF[^\n]*', r'UNCORRECTED PROOF[^\n]*',
        r'©\s*\d{4}[^\n]*', r'\bAll rights reserved\b[^\n]*',
        r'Downloaded from[^\n]*', r'This content downloaded[^\n]*',
        r'^\s*Page\s+\d+\s*(of\s+\d+)?\s*$',
        r'<[^>]{1,80}>',                       # stray tags
        r'[\uf000-\uf0ff]',                  # PDF ligature glyphs in the PUA block
        r'[�￾￿]',
    ]
    COMPILED = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in JUNK_PATTERNS]

    # safe, unambiguous fixes only
    LIGATURES = {
        'ﬁ': 'fi', 'ﬂ': 'fl', 'ﬀ': 'ff', 'ﬃ': 'ffi', 'ﬄ': 'ffl',
        '­': '',           # soft hyphen
    }
    CHAR_MAP = {
        '“': '"', '”': '"', '‘': "'", '’': "'", '…': '...',
        '—': ', ', '–': '-', ' ': ' ',
        '≤': ' less than or equal to ', '≥': ' greater than or equal to ',
        '≈': ' approximately ', '→': ' to ', '×': ' times ',
    }
    ABBREV = [
        (r'\bDr\.\s+', 'Doctor '), (r'\bMr\.\s+', 'Mister '),
        (r'\bMrs\.\s+', 'Missus '), (r'\bMs\.\s+', 'Miss '),
        (r'\bProf\.\s+', 'Professor '), (r'\bSt\.\s+', 'Saint '),
        (r'\be\.g\.\s*', 'for example, '), (r'\bi\.e\.\s*', 'that is, '),
        (r'\bcf\.\s*', 'compare, '), (r'\bviz\.\s*', 'namely, '),
        (r'\bet\s+al\.', 'and colleagues'),
        (r'\bNo\.\s*(\d+)', r'number \1'), (r'\bpp?\.\s*\d+(?:[-–]\d+)?', ''),
        (r'(\d)\s*%', r'\1 percent'),
    ]
    CHAR_MAP_ES = {
        '“': '"', '”': '"', '‘': "'", '’': "'", '…': '...',
        '«': '"', '»': '"', '—': ', ', '–': '-', ' ': ' ',
        '≤': ' menor o igual que ', '≥': ' mayor o igual que ',
        '≈': ' aproximadamente ', '→': ' a ', '×': ' por ',
    }
    ABBREV_ES = [
        (r'\bDr\.\s+', 'Doctor '), (r'\bDra\.\s+', 'Doctora '),
        (r'\bSr\.\s+', 'Señor '), (r'\bSra\.\s+', 'Señora '),
        (r'\bSrta\.\s+', 'Señorita '), (r'\bProf\.\s+', 'Profesor '),
        (r'\bp\.\s*ej\.,?\s*', 'por ejemplo, '), (r'\bp\.\s*e\.,?\s*', 'por ejemplo, '),
        (r'\bcf\.\s*', 'compárese, '), (r'\bvid\.\s*', 'véase, '),
        (r'\bibíd\.\s*', ''), (r'\bib\.\s*', ''), (r'\bop\.\s*cit\.\s*', ''),
        (r'\bet\s+al\.', 'y colaboradores'),
        (r'\bn\.[ºo°]\s*(\d+)', r'número \1'), (r'\bnúm\.\s*(\d+)', r'número \1'),
        (r'\bp[áa]gs?\.\s*\d+(?:[-–]\d+)?', ''), (r'\bpp\.\s*\d+(?:[-–]\d+)?', ''),
        (r'\bvol\.\s*(\d+)', r'volumen \1'), (r'\bcap\.\s*(\d+)', r'capítulo \1'),
        (r'\betc\.', 'etcétera'),
        (r'(\d)\s*%', r'\1 por ciento'),
    ]

    @classmethod
    def clean(cls, text: str, lang: str = "en") -> str:
        char_map = cls.CHAR_MAP_ES if lang == "es" else cls.CHAR_MAP
        abbrev = cls.ABBREV_ES if lang == "es" else cls.ABBREV
        for k, v in cls.LIGATURES.items():
            text = text.replace(k, v)
        for k, v in char_map.items():
            text = text.replace(k, v)

        # join words split across line breaks:  "under-\nstand" -> "understand"
        text = re.sub(r'(\w)[-‐]\n\s*(\w)', r'\1\2', text)

        for pat, rep in abbrev:
            text = re.sub(pat, rep, text, flags=re.IGNORECASE)
        for pat in cls.COMPILED:
            text = pat.sub('', text)

        # inline citations & footnote markers
        text = re.sub(r'\((?:[A-Z][A-Za-z\-]+(?:,?\s(?:and|&|et al\.?)\s?)?)+,?\s*\d{4}[a-z]?(?:,\s*p{1,2}\.?\s*\d+)?\)', '', text)
        text = re.sub(r'\[\d+(?:[-–,]\s*\d+)*\]', '', text)      # [12], [3-5]
        text = re.sub(r'(?<=[a-z.,;:!?"\'])\d{1,3}(?=\s|$)', '', text)  # trailing footnote digits

        # drop obvious page-furniture lines (short, mostly non-alpha, or bare numerals)
        out = []
        for line in text.split('\n'):
            s = line.strip()
            if not s:
                out.append('')
                continue
            if re.fullmatch(r'[\divxlcdmIVXLCDM.\s\-]+', s) and len(s) < 12:
                continue
            alpha = sum(c.isalpha() for c in s)
            if len(s) < 4 and alpha == 0:
                continue
            out.append(line)
        text = '\n'.join(out)

        # tidy leftovers from citation removal
        text = re.sub(r'\s+([,.;:!?])', r'\1', text)
        text = re.sub(r'[,;:]\s*(?=[.)\]])', '', text)   # "Press,." -> "Press."  "1990, )" -> "1990)"
        text = re.sub(r'\(\s*[,;.]?\s*\)', '', text)     # empty parens
        text = re.sub(r'([,;:])\1+', r'\1', text)

        text = re.sub(r'[ \t]{2,}', ' ', text)
        text = re.sub(r' +\n', '\n', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()


TTS_CLEAN_SYSTEM = """You prepare written documents to be listened to as audio (text-to-speech).
You are given a chunk of raw text extracted from a book, paper, or lecture. Return a cleaned version that sounds natural read aloud, with the author's words and argument fully intact.

REMOVE completely:
- page numbers, running headers/footers, publisher / copyright / proof boilerplate
- URLs, DOIs, ISBNs, "downloaded from ..." lines, "for personal use only" notices
- in-text citations and reference markers: "(Smith 2004)", "(see Jones 1999; Lee 2003)", "[12]", superscript footnote/endnote numbers
- reference lists, bibliographies, "Works Cited" / "Notes" / "Endnotes" sections
- figure and table captions, "see Figure 3", "(Table 2)", page cross-references
- OCR garbage, stray markup, lone letters or symbols on their own line

FIX:
- words broken across a line break ("inter- pretation" -> "interpretation") and OCR word-splits ("bene ts" -> "benefits", "di culty" -> "difficulty")
- broken ligatures, smart quotes -> plain quotes (or drop quote marks around short quoted phrases so they don't get spelled out)
- replace dashes used as a parenthetical break with commas; expand "&" to "and"
- expand abbreviations that sound wrong spoken: e.g. -> "for example", i.e. -> "that is", cf. -> "compare", et al. -> "and colleagues", ibid. -> drop, vs. -> "versus", § -> "section", "ff." -> drop
- write out symbols and bare numerals when a listener would otherwise be lost (percentages, math relations)

KEEP:
- every substantive sentence, argument, example, and quotation - verbatim in meaning, do not condense
- the abstract or summary paragraph if present (drop only the word "Abstract")
- paragraph breaks
- EVERY section heading, on its own line, ending with a period. Numbered headings become "Section 2. The argument from disagreement." Unnumbered headings stay as "The argument from disagreement."
- footnote/endnote text ONLY where it carries real argument or an example - fold it into the nearest sentence as a brief parenthetical; drop pure-citation notes

Do NOT summarize, paraphrase, editorialize, add headings that were not there, or add markdown. Output only the cleaned text, nothing before or after it."""

TTS_CLEAN_SYSTEM_ES = """Preparas documentos escritos para escucharlos como audio (texto a voz).
Recibes un fragmento de texto sin procesar extraído de un libro, un artículo o una clase. Devuelve una versión limpia que suene natural leída en voz alta, conservando íntegras las palabras y el razonamiento del autor. Escribe siempre en español.

ELIMINA por completo:
- números de página, encabezados y pies de página repetidos, texto de editorial, copyright o pruebas de imprenta
- URLs, DOIs, ISBNs, líneas de "descargado de ...", avisos de "solo para uso personal"
- citas y llamadas de referencia dentro del texto: "(García 2004)", "(véase Jones 1999; Lee 2003)", "[12]", números de nota al pie o al final en superíndice
- listas de referencias, bibliografías, secciones de "Bibliografía" / "Notas"
- pies de figuras y tablas, "véase la Figura 3", "(Tabla 2)", referencias cruzadas de página
- basura de OCR, marcado suelto, letras o símbolos sueltos en su propia línea

CORRIGE:
- palabras partidas por un salto de línea ("inter- pretación" -> "interpretación") y separaciones de OCR
- ligaduras rotas, comillas tipográficas y angulares -> comillas simples (o quita las comillas de frases cortas citadas para que no se deletreen)
- sustituye las rayas usadas como inciso por comas; desarrolla "&" a "y"
- desarrolla las abreviaturas que suenan mal leídas: p. ej. -> "por ejemplo", es decir -> "es decir", cf. -> "compárese", et al. -> "y colaboradores", ibíd. -> quítalo, vs. -> "frente a", § -> "sección"
- escribe con palabras los símbolos y las cifras sueltas cuando el oyente se perdería (porcentajes, relaciones matemáticas)

CONSERVA:
- cada oración, argumento, ejemplo y cita relevante, con el mismo significado, sin resumir
- el párrafo de resumen o abstract si lo hay (quita solo la palabra "Resumen" o "Abstract")
- los saltos de párrafo
- CADA título de sección, en su propia línea, terminado en punto. Los títulos numerados quedan como "Sección 2. El argumento del desacuerdo." Los no numerados quedan como "El argumento del desacuerdo."
- el texto de las notas SOLO cuando aporta un argumento o un ejemplo real: intégralo en la oración más cercana como un inciso breve; descarta las notas que son solo citas

NO resumas, parafrasees, opines, añadas títulos que no estaban ni añadas markdown. Devuelve solo el texto limpio, sin nada antes ni después."""

TTS_CLEAN_SYSTEM = {"en": TTS_CLEAN_SYSTEM, "es": TTS_CLEAN_SYSTEM_ES}

# Clean AND translate. Same cleanup rules, plus a faithful translation into the
# target language. Used when "Read in" is set to a specific language.
TTS_CLEAN_TO_EN = TTS_CLEAN_SYSTEM["en"].replace(
    "Return a cleaned version that sounds natural read aloud, with the author's words and argument fully intact.",
    "The text may be in any language. Return a faithful English translation that "
    "sounds natural read aloud, cleaned the same way, with the author's argument, "
    "examples, and quotations fully intact. Translate meaning, not word for word; "
    "do not summarize or drop content. Output only the English text.")
TTS_CLEAN_TO_ES = TTS_CLEAN_SYSTEM["es"].replace(
    "Devuelve una versión limpia que suene natural leída en voz alta, conservando íntegras las palabras y el razonamiento del autor. Escribe siempre en español.",
    "El texto puede estar en cualquier idioma. Devuelve una traducción fiel al "
    "español que suene natural leída en voz alta, limpiada igual, conservando "
    "íntegros el razonamiento, los ejemplos y las citas del autor. Traduce el "
    "sentido, no palabra por palabra; no resumas ni elimines contenido. Escribe "
    "solo el texto en español.")
TTS_CLEAN_TRANSLATE = {"en": TTS_CLEAN_TO_EN, "es": TTS_CLEAN_TO_ES}


def _guess_lang(text: str) -> str:
    s = " " + text.lower()[:4000] + " "
    es = sum(s.count(w) for w in (" el ", " la ", " los ", " las ", " de ", " que ",
                                  " y ", " en ", " para ", " con ", " una ", " por ",
                                  "ción ", "ñ", "¿", "¡"))
    en = sum(s.count(w) for w in (" the ", " of ", " and ", " to ", " in ", " is ",
                                  " that ", " for ", " with ", " a ", " it ", " on "))
    return "es" if es > en else "en"


def _split_into_chunks(text: str, max_chars: int = 9000):
    """Split on blank lines, then sentences, keeping chunks under max_chars."""
    paras = re.split(r'\n\s*\n', text)
    chunks, cur = [], ""
    for p in paras:
        if len(cur) + len(p) + 2 <= max_chars:
            cur += (("\n\n" + p) if cur else p)
            continue
        if cur:
            chunks.append(cur)
            cur = ""
        if len(p) <= max_chars:
            cur = p
        else:
            for sent in re.split(r'(?<=[.!?])\s+', p):
                if len(cur) + len(sent) + 1 > max_chars and cur:
                    chunks.append(cur)
                    cur = ""
                cur += ((" " + sent) if cur else sent)
    if cur:
        chunks.append(cur)
    return chunks or [text]


# ============================================================================
#  Cost estimates
# ============================================================================
# Anthropic API list prices, USD per 1M tokens: (input, output).
CLAUDE_PRICING = {
    "claude-haiku-4-5": (1.00, 5.00),
    "claude-sonnet-5": (2.00, 10.00),
}
_CHARS_PER_TOKEN = 4                                     # rough English ratio
_CLEAN_SYS_TOKENS = len(TTS_CLEAN_SYSTEM["en"]) / _CHARS_PER_TOKEN   # resent per chunk
_CLEAN_OUTPUT_RATIO = 0.9                                # cleaned text ~= 90% of input
_CHUNK_CHARS = 9000                                      # matches _split_into_chunks


def estimate_clean_cost(text: str, model: str) -> float:
    """Ballpark USD for one AI cleaning pass over `text`.

    chars/4 token estimate; the system prompt is counted once per ~9k-char
    chunk; output is assumed ~90% of input length. Reads slightly high so the
    figure shown in the UI behaves as a ceiling, not a floor.
    """
    rates = CLAUDE_PRICING.get(model)
    if not rates or not text.strip():
        return 0.0
    in_rate, out_rate = rates
    body_tokens = len(text) / _CHARS_PER_TOKEN
    n_chunks = max(1, -(-len(text) // _CHUNK_CHARS))     # ceil division
    input_tokens = body_tokens + _CLEAN_SYS_TOKENS * n_chunks
    output_tokens = body_tokens * _CLEAN_OUTPUT_RATIO
    return (input_tokens * in_rate + output_tokens * out_rate) / 1_000_000


def fmt_cost(usd: float) -> str:
    if usd <= 0:
        return "free"
    if usd < 0.005:
        return "<1¢"
    if usd < 1:
        return f"~{round(usd * 100)}¢"
    return f"~${usd:,.2f}"


def ai_clean(text: str, api_key: str, model: str, progress=None,
             target_lang=None, src_lang="en", should_stop=None) -> str:
    """Clean text with Claude, optionally translating to `target_lang` ("en"/"es").
    Raises on hard failure so the caller can fall back; raises Cancelled on Stop."""
    import anthropic

    if target_lang in ("en", "es"):
        system = TTS_CLEAN_TRANSLATE[target_lang]
        msg_key = "st_translating"
    else:
        system = TTS_CLEAN_SYSTEM.get(src_lang, TTS_CLEAN_SYSTEM["en"])
        msg_key = "st_ai_cleaning"

    client = anthropic.Anthropic(api_key=api_key)
    chunks = _split_into_chunks(text)
    cleaned = []
    for i, chunk in enumerate(chunks, 1):
        if should_stop and should_stop():
            raise Cancelled()
        if progress:
            progress(t(msg_key, i=i, n=len(chunks)))
        resp = client.messages.create(
            model=model,
            max_tokens=8000,
            system=system,
            messages=[{"role": "user", "content": chunk}],
        )
        part = "".join(b.text for b in resp.content if b.type == "text").strip()
        if part:
            cleaned.append(part)
    return "\n\n".join(cleaned).strip()


# ============================================================================
#  Text extraction
# ============================================================================
def extract_text(path: Path):
    """Return (text, pages_without_text, total_pages). The page counts are 0 for
    non-PDF inputs; for PDFs they let the caller warn instead of silently losing
    pages that need OCR."""
    ext = path.suffix.lower()
    if ext == ".pdf":
        if not HAS_PDF:
            raise RuntimeError("PDF support not installed (pip install pypdf).")
        parts, empty = [], 0
        reader = pypdf.PdfReader(str(path))
        total = len(reader.pages)
        for page in reader.pages:
            txt = ""
            # default extraction first; "layout" mode rescues pages whose text
            # the default pass returns empty for
            for mode in (None, "layout"):
                try:
                    txt = (page.extract_text() if mode is None
                           else page.extract_text(extraction_mode=mode)) or ""
                except Exception:
                    txt = ""
                if txt.strip():
                    break
            if txt.strip():
                parts.append(txt)
            else:
                empty += 1
        return "\n\n".join(parts), empty, total

    if ext == ".docx":
        if not HAS_DOCX:
            raise RuntimeError("Word support not installed (pip install python-docx).")
        d = docx.Document(str(path))
        blocks = [p.text for p in d.paragraphs]
        for table in d.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells if c.text.strip()]
                if cells:
                    blocks.append(" — ".join(cells))
        return "\n\n".join(b for b in blocks if b.strip()), 0, 0

    if ext == ".doc":
        raise RuntimeError(t("err_old_doc"))

    # Anything else is treated as plain text - but the file dialog offers an
    # "All files" filter, so check it really is text before dumping bytes into
    # the editor (a binary file used to paste mojibake and then get spoken).
    raw = path.read_bytes()
    if b"\x00" in raw[:8192]:
        raise RuntimeError(t("err_not_text", ext=ext or "?"))
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            txt = raw.decode(enc)
        except (UnicodeDecodeError, UnicodeError):
            continue
        sample = txt[:8192]
        if sample:
            printable = sum(c.isprintable() or c in "\r\n\t" for c in sample)
            if printable / len(sample) < 0.85:
                continue
        return txt, 0, 0
    raise RuntimeError(t("err_not_text", ext=ext or "?"))


# ============================================================================
#  TTS generation
# ============================================================================
async def _save_piece(piece, voice, rate, tmp, should_stop):
    """Synthesise one chunk, polling for Stop so a long piece stays cancellable."""
    comm = edge_tts.Communicate(piece, voice, rate=rate)
    task = asyncio.ensure_future(comm.save(str(tmp)))
    while not task.done():
        if should_stop and should_stop():
            task.cancel()
            try:
                await task
            except BaseException:
                pass
            raise Cancelled()
        await asyncio.sleep(0.15)
    await task                      # re-raise any synthesis error


async def _edge_generate(text: str, voice: str, rate: str, out_path: str, progress=None,
                         should_stop=None):
    """Edge TTS. Chunk very long text so a single failure doesn't lose everything."""
    pieces = _split_into_chunks(text, max_chars=7000)
    tmp_files = []
    try:
        for i, piece in enumerate(pieces):
            if should_stop and should_stop():
                raise Cancelled()
            if progress:
                progress(t("st_synth", i=i + 1, n=len(pieces)))
            tmp = STORAGE_DIR / f"_part_{i:03d}.mp3"
            last_err = None
            for attempt in range(3):
                try:
                    await _save_piece(piece, voice, rate, tmp, should_stop)
                    break
                except Cancelled:
                    raise
                except Exception as e:  # transient network / service hiccup
                    last_err = e
                    for _ in range(int(1.5 * (attempt + 1) / 0.15)):
                        if should_stop and should_stop():
                            raise Cancelled()
                        await asyncio.sleep(0.15)
            else:
                msg = str(last_err).lower()
                if any(w in msg for w in ("resolve", "connect", "network", "timeout",
                                          "unreachable", "ssl", "getaddrinfo", "closed")):
                    raise RuntimeError(t("err_offline"))       # almost always no wifi
                raise RuntimeError(f"Edge TTS failed: {last_err}")
            tmp_files.append(tmp)

        if len(tmp_files) == 1:
            shutil.move(str(tmp_files[0]), out_path)
        else:
            with open(out_path, "wb") as fout:      # mp3 frames concatenate fine
                for tf in tmp_files:
                    fout.write(Path(tf).read_bytes())
    finally:
        # sweep every part file, not just the completed ones - a piece cancelled
        # mid-save never made it into tmp_files (and this also clears leftovers
        # from an earlier crash)
        for tf in list(tmp_files) + list(STORAGE_DIR.glob("_part_*.mp3")):
            try:
                Path(tf).unlink()
            except OSError:
                pass


# ============================================================================
#  Audio player
# ============================================================================
def _ensure_mixer() -> bool:
    """Open the audio device. Returns False if it can't be opened - CoreAudio
    refuses (error -66681) when the device is busy or exhausted, and that must
    never take the whole app down: cleaning, translating and writing MP3s all
    still work without playback."""
    if pygame.mixer.get_init() is not None:
        return True
    for kwargs in ({"frequency": 44100}, {}):
        try:
            pygame.mixer.init(**kwargs)
            return True
        except Exception as e:
            print("audio init failed:", e)
    return False


def decode_int16(path, duration_hint=0.0):
    """Decode an audio file to an (N, 2) int16 array *at the mixer's sample rate*.

    Some SDL2_mixer builds hand back MP3 samples at the file's own rate instead of
    resampling to the open device - and edge-tts files are 24 kHz while the mixer
    runs at 44.1 kHz, which is exactly why changing speed on a generated clip used
    to come out fast and high-pitched. When a duration is known we detect that
    mismatch and resample. Returns (None, sr) if the decode is clearly truncated
    (e.g. a concatenated multi-part MP3 the loader only read part of)."""
    if not _ensure_mixer():
        return None, 44100
    sr = (pygame.mixer.get_init() or (44100,))[0] or 44100
    try:
        snd = pygame.mixer.Sound(str(path))
        arr = pygame.sndarray.array(snd)
        del snd
    except Exception:
        return None, sr
    if arr.ndim == 1:
        arr = np.column_stack([arr, arr])
    elif arr.shape[1] == 1:
        arr = np.repeat(arr, 2, axis=1)
    arr = arr.astype(np.int16, copy=False)

    if duration_hint and duration_hint > 0.5:
        got = arr.shape[0]
        native = got / duration_hint
        if native < sr * 0.55:                       # loader stopped early
            return None, sr
        if abs(native - sr) / sr > 0.06:             # not resampled to device rate
            new_n = max(2, int(round(got * sr / native)))
            idx = np.linspace(0.0, got - 1.0, new_n, dtype=np.float64)
            lo = np.floor(idx).astype(np.int64)
            hi = np.minimum(lo + 1, got - 1)
            frac = (idx - lo).astype(np.float32)[:, None]
            arr = ((1.0 - frac) * arr[lo] + frac * arr[hi]).astype(np.int16)
    return np.ascontiguousarray(arr), sr


def time_stretch(samples, speed, sr):
    """WSOLA time-stretch: change tempo, keep pitch. speed>1 = faster / shorter."""
    if abs(speed - 1.0) < 0.02 or samples.shape[0] < sr:
        return samples
    x = samples                                 # keep the big array as int16
    n, ch = x.shape
    frame = 2048
    hop_out = frame // 2                         # 50% overlap -> Hann is COLA, no re-norm
    hop_in = hop_out * speed
    win = np.hanning(frame).astype(np.float32).reshape(-1, 1)
    tol = int(sr * 0.010)                        # +-10 ms similarity search
    ref_len = hop_out
    xmono = x.mean(axis=1, dtype=np.float32)
    out_n = int(np.ceil(n / speed)) + frame
    y = np.zeros((out_n, ch), np.float32)

    ana = 0.0
    syn = 0
    natural = -1
    while syn + frame <= out_n and int(ana) + frame <= n:
        i = int(ana)
        if natural >= 0:
            lo, hi = max(0, i - tol), min(n - frame, i + tol)
            if hi > lo and natural + ref_len <= n:
                cc = np.correlate(xmono[lo:hi + ref_len],
                                  xmono[natural:natural + ref_len], mode="valid")
                i = lo + int(np.argmax(cc))
        y[syn:syn + frame] += x[i:i + frame].astype(np.float32) * win
        natural = i + hop_out
        ana += hop_in
        syn += hop_out

    del xmono
    y = y[:min(len(y), syn + hop_out)]          # drop the unfilled tail (silence)
    return np.ascontiguousarray(np.clip(y, -32768, 32767).astype(np.int16))


class AudioPlayer:
    """1.0x plays via streaming music; other speeds play a pitch-preserved in-memory copy."""

    MAX_STRETCH_SECONDS = 60 * 60

    def __init__(self):
        # never fatal - the app is still useful without a working audio device
        self.audio_ok = _ensure_mixer()
        self.current_file = None
        self.duration = 0.0
        self.is_playing = False
        self.is_paused = False
        self.speed = 1.0
        self._start = 0.0
        self._offset = 0.0
        self._backend = "music"          # "music" | "stretch"
        self._chan = None
        self._raw = None                 # cached decoded (N,2) int16
        self._raw_failed = False         # decode came back unusable - don't retry
        self._sr = 44100
        self._stretched = None
        self._cache = {}                 # speed -> stretched array
        self._swapping = False           # true briefly while switching backends

    # ---- loading ----
    def load(self, path: str):
        self.stop()
        self.current_file = Path(path)
        if not self.current_file.exists():
            raise FileNotFoundError(path)
        self.duration = self._probe_duration(self.current_file)
        self.speed = 1.0
        self._backend = "music"
        self._raw = None
        self._raw_failed = False
        self._stretched = None
        self._cache = {}
        self._swapping = False
        if not self.audio_ok:
            self.audio_ok = _ensure_mixer()       # the device may be free now
        if self.audio_ok:
            pygame.mixer.music.load(str(self.current_file))

    def _probe_duration(self, path: Path) -> float:
        if HAS_MUTAGEN and path.suffix.lower() == ".mp3":
            try:
                return float(MP3(str(path)).info.length)
            except Exception:
                pass
        if HAS_PYDUB:
            try:
                return len(AudioSegment.from_file(str(path))) / 1000.0
            except Exception:
                pass
        if FFMPEG:
            try:
                out = subprocess.run([FFMPEG, "-i", str(path)],
                                     capture_output=True, text=True).stderr
                m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.\d+)", out)
                if m:
                    h, mnt, s = m.groups()
                    return int(h) * 3600 + int(mnt) * 60 + float(s)
            except Exception:
                pass
        return 0.0

    def speed_available(self) -> bool:
        if not self.audio_ok or not HAS_NUMPY or self.duration > self.MAX_STRETCH_SECONDS:
            return False
        return not self._raw_failed

    # ---- speed: pitch-preserving, pure Python ----
    def set_speed(self, speed: float):
        """Switch playback speed. Works from any starting speed and regardless of
        the rate the clip was generated at. The costly decode + time-stretch runs
        *before* the current audio is stopped, so the swap itself is instant."""
        speed = round(max(0.5, min(2.0, speed)), 2)
        if abs(speed - self.speed) < 0.01 or not self.current_file:
            return

        use_music = abs(speed - 1.0) < 0.02 or not self.speed_available()

        stretched = None
        if not use_music:
            stretched = self._cache.get(speed)
            if stretched is None:
                if self._raw is None and not self._raw_failed:
                    self._raw, self._sr = decode_int16(self.current_file, self.duration)
                    self._raw_failed = self._raw is None
                if self._raw is None:
                    use_music = True                 # can't stretch this clip
                else:
                    stretched = time_stretch(self._raw, speed, self._sr)
                    # a stretched copy of a long clip is hundreds of MB - keep
                    # only the two most recent so the slider can't eat all RAM
                    while len(self._cache) >= 2:
                        self._cache.pop(next(iter(self._cache)))
                    self._cache[speed] = stretched

        dur = self.get_duration()
        frac = (self.get_position() / dur) if dur else 0.0
        was_playing = self.is_playing

        self._swapping = True
        try:
            self._halt()
            if use_music:
                self.speed = 1.0
                self._backend = "music"
                self._stretched = None
                try:
                    pygame.mixer.music.load(str(self.current_file))
                except Exception as e:
                    print("speed reload error:", e)
            else:
                self.speed = speed
                self._stretched = stretched
                self._backend = "stretch"

            new_pos = frac * self.get_duration()
            if was_playing:
                self.seek(new_pos)
            else:
                self._offset = new_pos
        finally:
            self._swapping = False

    # ---- transport ----
    def _halt(self):
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass
        if self._chan is not None:
            try:
                self._chan.stop()
            except Exception:
                pass
            self._chan = None

    def play(self):
        if not self.audio_ok:
            return
        try:
            if self.is_paused:
                if self._backend == "music":
                    pygame.mixer.music.unpause()
                elif self._chan is not None:
                    self._chan.unpause()
                self._start = time.time() - self._offset
            else:
                if self._backend == "music":
                    pygame.mixer.music.play()
                else:
                    self._chan = pygame.sndarray.make_sound(self._stretched).play()
                self._start = time.time()
                self._offset = 0.0
        except Exception as e:
            print("playback error:", e)
            self.audio_ok = False
            return
        self.is_playing, self.is_paused = True, False

    def pause(self):
        if self.is_playing:
            try:
                if self._backend == "music":
                    pygame.mixer.music.pause()
                elif self._chan is not None:
                    self._chan.pause()
            except Exception:
                pass
            self._offset = time.time() - self._start
            self.is_playing, self.is_paused = False, True

    def stop(self):
        self._halt()
        self.is_playing = self.is_paused = False
        self._offset = 0.0

    def seek(self, position: float):
        """Jump to `position`. Scrubbing does not change whether we're playing:
        seeking while paused leaves the clip paused at the new spot."""
        if not self.current_file or not self.audio_ok:
            return
        position = max(0.0, min(position, self.get_duration()))
        stay_paused = self.is_paused or not self.is_playing
        try:
            if self._backend == "music":
                try:
                    pygame.mixer.music.play(start=position / self.speed)
                except Exception:
                    pygame.mixer.music.play()
                if stay_paused:
                    pygame.mixer.music.pause()
            else:
                start = max(0, int(position * self._sr))
                seg = self._stretched[start:]
                if len(seg) < 2:
                    seg = self._stretched[-2:]
                if self._chan is not None:
                    self._chan.stop()
                self._chan = pygame.sndarray.make_sound(np.ascontiguousarray(seg)).play()
                if stay_paused:
                    self._chan.pause()
        except Exception as e:
            print("seek error:", e)
            return
        self._start = time.time() - position
        self._offset = position
        if stay_paused:
            self.is_playing, self.is_paused = False, True
        else:
            self.is_playing, self.is_paused = True, False

    def get_position(self) -> float:
        if self.is_playing:
            return min((time.time() - self._start), self.get_duration())
        return self._offset

    def get_duration(self) -> float:
        return self.duration / self.speed if self.speed else self.duration

    def is_finished(self) -> bool:
        if not self.is_playing or self.is_paused or self._swapping:
            return False
        if not self.audio_ok:
            return True
        try:
            if self._backend == "music":
                return not pygame.mixer.music.get_busy()
            return self._chan is None or not self._chan.get_busy()
        except Exception:
            return True

    def cleanup(self):
        self._cache = {}
        for f in STORAGE_DIR.glob("_speed_*.mp3"):
            try:
                f.unlink()
            except OSError:
                pass


# ============================================================================
#  Waveform
# ============================================================================
def compute_peaks(path, n_buckets: int = 1600):
    """Decode an audio file to a normalised amplitude envelope (0..1), no ffmpeg."""
    if not HAS_NUMPY:
        return None
    try:
        if Path(path).stat().st_size > 120 * 1024 * 1024:  # ~2h mp3 - skip, too big
            return None
        if not _ensure_mixer():
            return None
        snd = pygame.mixer.Sound(str(path))
        raw = snd.get_raw()
        del snd
        data = np.frombuffer(raw, dtype=np.int16)
        ch = (pygame.mixer.get_init() or (0, 0, 2))[2] or 2
        frames = len(data) // ch
        if frames < n_buckets * 4:
            return None
        per = frames // n_buckets
        peaks = np.empty(n_buckets, dtype=np.float32)
        for i in range(n_buckets):
            seg = data[i * per * ch:(i + 1) * per * ch]
            peaks[i] = np.abs(seg).max() if seg.size else 0.0
        m = float(peaks.max())
        if m <= 0:
            return None
        peaks = (peaks / m) ** 0.65          # perceptual lift for quiet passages
        return np.clip(peaks, 0.03, 1.0)
    except Exception as e:
        print("waveform decode failed:", e)
        return None


# ============================================================================
#  GUI
# ============================================================================
PLACEHOLDER = t("placeholder")
FONT = "Helvetica Neue"
WORDS_PER_MIN = 165  # Edge neural voices, natural pace


def _round_pts(x1, y1, x2, y2, r):
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    return [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
            x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]


class RoundButton(tk.Canvas):
    """A rounded, fully colour-controlled button (tk.Button ignores colours on macOS)."""

    def __init__(self, parent, text, command, *, fill, fg, hover, outer,
                 font, height=46, radius=13, min_pad=22, grow=False):
        super().__init__(parent, height=height, bd=0, highlightthickness=0, bg=outer)
        self._text, self._cmd = text, command
        self._fill, self._fg, self._hover = fill, fg, hover
        self._font, self._r, self._pad, self._grow = font, radius, min_pad, grow
        self._enabled = True
        self._cur = fill
        if not grow:
            self.configure(width=self._text_w() + self._pad * 2)
        self.bind("<Configure>", lambda e: self._render())
        self.bind("<Enter>", lambda e: self._enabled and self._paint(self._hover))
        self.bind("<Leave>", lambda e: self._paint(self._cur))
        self.bind("<ButtonPress-1>", lambda e: self._enabled and self._paint(self._fg2()))
        self.bind("<ButtonRelease-1>", self._release)

    def _text_w(self):
        return tkfont.Font(font=self._font).measure(self._text)

    def _fg2(self):
        return self._hover

    def _release(self, e):
        self._paint(self._hover if self._enabled else self._cur)
        if self._enabled and 0 <= e.x <= self.winfo_width() and 0 <= e.y <= self.winfo_height():
            self._cmd()

    def _paint(self, fill):
        self.itemconfigure("bg", fill=fill)

    def _render(self):
        self.delete("all")
        w = self.winfo_width() if self._grow else self._text_w() + self._pad * 2
        h = self.winfo_height()
        col = self._cur if self._enabled else COLORS["border"]
        self.create_polygon(_round_pts(1, 1, w - 1, h - 1, self._r), smooth=True,
                            splinesteps=24, fill=col, outline="", tags="bg")
        self.create_text(w / 2, h / 2 + 1, text=self._text, font=self._font,
                         fill=self._fg if self._enabled else COLORS["text_dim"])

    def set_text(self, t):
        self._text = t
        if not self._grow:
            self.configure(width=self._text_w() + self._pad * 2)
        self._render()

    def enable(self, on):
        self._enabled = on
        self._cur = self._fill
        self.configure(cursor="hand2" if on else "arrow")
        self._render()


class WaveformView(tk.Canvas):
    """Amplitude envelope with a gold 'played' fill, white playhead, click / drag to seek."""

    def __init__(self, parent, on_seek, height=70):
        super().__init__(parent, height=height, bd=0, highlightthickness=0,
                         bg=COLORS["wave_bg"], cursor="hand2")
        self._on_seek = on_seek
        self._peaks = None
        self._frac = 0.0
        self._last_head = -1
        self._redraw_job = None
        self.bind("<Configure>", self._on_configure)
        self.bind("<Button-1>", self._seek_evt)
        self.bind("<B1-Motion>", self._seek_evt)

    def _on_configure(self, _=None):
        # Coalesce the burst of events during a window drag into one repaint.
        if self._redraw_job:
            self.after_cancel(self._redraw_job)
        self._redraw_job = self.after(45, self._full_redraw)

    def set_waveform(self, peaks):
        self._peaks = peaks
        self._frac = 0.0
        self._full_redraw()

    def clear(self):
        self._peaks = None
        self._frac = 0.0
        self._full_redraw()

    def set_progress(self, frac):
        self._frac = max(0.0, min(1.0, frac))
        w = self.winfo_width()
        head = int(self._frac * w)
        if abs(head - self._last_head) >= 1:
            self._draw_played()

    def _seek_evt(self, e):
        w = self.winfo_width()
        if self._peaks is not None and w > 1:
            self._on_seek(max(0.0, min(1.0, e.x / w)))

    def _bars(self, x0, x1, color, tag):
        w, h = self.winfo_width(), self.winfo_height()
        mid = h / 2
        n = len(self._peaks)
        for x in range(int(x0), int(x1), 2):
            amp = self._peaks[min(int(x / max(w, 1) * n), n - 1)]
            bar = max(1.0, amp * (mid - 4))
            self.create_line(x, mid - bar, x, mid + bar, fill=color, width=1.6, tags=tag)

    def _full_redraw(self):
        self._redraw_job = None
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 4 or h < 4:
            return
        if self._peaks is None:
            self.create_text(w / 2, h / 2, text=t("wave_placeholder"),
                             fill=COLORS["text_dim"], font=(FONT, 10))
            return
        self._bars(0, w, COLORS["wave_dim"], "base")
        self._draw_played()

    def _draw_played(self):
        self.delete("played", "head")
        if self._peaks is None:
            return
        w, h = self.winfo_width(), self.winfo_height()
        head = int(self._frac * w)
        self._last_head = head
        if head > 0:
            self._bars(0, head, COLORS["gold"], "played")
        self.create_line(head, 3, head, h - 3, fill=COLORS["white"], width=2, tags="head")


def _rate_mult(label: str) -> float:
    m = re.search(r"([\d.]+)x", label)
    return float(m.group(1)) if m else 1.0


def _slugify(s: str, maxlen: int = 70) -> str:
    s = re.sub(r"\s+", " ", re.sub(r'[^\w\s.-]', "", s)).strip(" .-")
    return s[:maxlen].strip() or "audio"


def _unique(path: Path) -> Path:
    if not path.exists():
        return path
    for n in range(2, 999):
        cand = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not cand.exists():
            return cand
    return path.with_name(f"{path.stem} {int(time.time())}{path.suffix}")


def reveal(path):
    try:
        subprocess.run(["open", "-R", str(path)], check=False)
    except Exception:
        pass


def open_folder(path):
    try:
        subprocess.run(["open", str(path)], check=False)
    except Exception:
        pass





class TalkingTom:
    # MIN_* allow a playback-only window; FULL_MIN_* select the editor layout.
    # The full launch size is preserved separately; MAX_CONTENT_W caps line length on wide monitors
    # (typography: an unbounded editor on a 34" display is unreadable).
    # The width floor is set by the four setting dropdowns fitting on one row and
    # the height floor by the editor keeping a readable number of lines.
    # _init_geometry adapts both down on a small display, and the options row
    # falls to a 2x2 grid if it still doesn't fit.
    MIN_W, MIN_H = 380, 270
    FULL_MIN_W, FULL_MIN_H = 760, 650
    MAX_CONTENT_W = 1120
    _BASE_PAD = 24
    _OPT_CARD_PAD = 18       # inner padding of the settings card
    _OPT_GAP = 14            # gap between the setting dropdowns

    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.configure(bg=COLORS["bg"])
        if not LANG_SAVED:
            self._first_run_language()      # may save + relaunch
        self._init_geometry()

        self.player = AudioPlayer()
        self.busy = False
        self.update_job = None
        self.source_path = None
        self.last_output = None
        self._shut = False
        self._cancel = threading.Event()
        # Worker threads hand UI work back through this queue and a main-thread
        # pump. Tk.after() is NOT usable cross-thread on every Tcl build - the
        # one bundled with uv-managed CPython silently drops such calls, which
        # made cleaning/generation/playback appear to do nothing.
        self._ui_q = queue.Queue()
        self._pump_job = None

        # localized-label <-> stable-value maps for the current language
        self._clean_l2t = {CLEAN_LABELS[LANG][k]: k for k in CLEAN_TOKENS}
        self._clean_t2l = CLEAN_LABELS[LANG]
        self._model_l2i = {MODEL_LABELS[LANG][m]: m for m in MODEL_IDS}
        self._model_i2l = MODEL_LABELS[LANG]
        self._readin_l2t = {READIN_LABELS[LANG][k]: k for k in READIN_TOKENS}
        self._readin_t2l = READIN_LABELS[LANG]

        _readin = CONFIG.get("readin", "auto")
        if _readin not in READIN_TOKENS:
            _readin = "auto"
        _voice = CONFIG.get("voice", "")
        if _voice not in ALL_VOICES:
            _voice = DEFAULT_VOICE
        _rate = CONFIG.get("rate", "")
        if _rate not in SPEECH_RATES:
            _rate = DEFAULT_RATE
        # Default to the free built-in cleaner: text-to-speech costs nothing, and a
        # brand-new user has no Claude key, so defaulting to AI only produced a
        # "no key - used the built-in cleaner" notice on their very first run.
        _tok = _migrate_clean_tok(CONFIG.get("clean_mode", "builtin"))
        _mid = _migrate_model_id(CONFIG.get("model") or CONFIG.get("model_label"))

        self.voice_var = tk.StringVar(value=_voice)
        self.rate_var = tk.StringVar(value=_rate)
        self.model_var = tk.StringVar(value=self._model_i2l[_mid])
        self.clean_mode = tk.StringVar(value=self._clean_t2l[_tok])
        self.readin_var = tk.StringVar(value=self._readin_t2l[_readin])
        self.lang_var = tk.StringVar(value=UI_LANG_LABELS[LANG])
        self.status_var = tk.StringVar(value="")
        self.estimate_var = tk.StringVar(value="")
        self.cost_var = tk.StringVar(value="")
        self.time_cur = tk.StringVar(value="0:00")
        self.time_tot = tk.StringVar(value="0:00")
        self.speed_var = tk.DoubleVar(value=1.0)
        self._speed_job = None
        self._pending_speed = 1.0
        self._est_job = None
        self._programmatic_edit = False   # True while the app itself rewrites the box
        self._loaded_text = ""            # what the app last put in the box
        self._settings_win = None

        self._style()
        self._build_menu()
        self._build_ui()
        self._bind_keys()
        self._setup_dnd()
        for _v in (self.rate_var, self.clean_mode, self.model_var):
            _v.trace_add("write", lambda *_: self._update_estimate())
        self.readin_var.trace_add("write", lambda *_: self._on_readin_change())
        self.lang_var.trace_add("write", lambda *_: self._on_lang_change())
        self._pump()
        # fit the options row once the widgets know their real sizes; a <Configure>
        # is not guaranteed at startup (Tk emits none when the size doesn't change)
        self.root.after_idle(lambda: self._fit_options(self._side_pad()))
        self.root.after(150, self._front)

    # ---------------- main-thread dispatch ----------------
    def _post(self, fn, *args):
        """Run fn(*args) on the main thread. Safe to call from any thread."""
        self._ui_q.put((fn, args))

    def _pump(self):
        while True:
            try:
                fn, args = self._ui_q.get_nowait()
            except queue.Empty:
                break
            try:
                fn(*args)
            except Exception as e:                     # never let one callback
                print("ui callback error:", e)         # kill the pump
        self._check_open_request()
        self._pump_job = self.root.after(40, self._pump)

    def _check_open_request(self):
        """A second launch drops a path here instead of opening its own window."""
        try:
            if not OPEN_REQUEST.exists():
                return
            path = OPEN_REQUEST.read_text(encoding="utf-8").strip()
            OPEN_REQUEST.unlink()
        except Exception:
            return
        self._front()
        try:
            self.root.focus_force()
        except tk.TclError:
            pass
        if path and not self.busy:
            self._ingest(path, auto=True)

    # ---------------- first-run language ----------------
    def _first_run_language(self):
        win = tk.Toplevel(self.root)
        win.title(APP_NAME)
        win.configure(bg=COLORS["bg"])
        win.resizable(False, False)
        self.root.update_idletasks()
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        win.geometry(f"420x220+{(sw - 420) // 2}+{max(40, (sh - 220) // 3)}")
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text=APP_NAME, font=(FONT, 19, "bold"),
                 fg=COLORS["gold"], bg=COLORS["bg"]).pack(pady=(28, 6))
        tk.Label(win, text=t("first_run_prompt"), font=(FONT, 11),
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(pady=(0, 22))

        picked = {"v": LANG}

        def choose(code):
            picked["v"] = code
            win.destroy()

        bar = tk.Frame(win, bg=COLORS["bg"])
        bar.pack()
        # RoundButton, not tk.Button: macOS renders a tk.Button grey whatever
        # colours it is given, and this dialog is the first thing anyone sees
        for code, label in (("en", "English"), ("es", "Español")):
            RoundButton(bar, label, lambda c=code: choose(c),
                        fill=COLORS["gold"], fg=COLORS["navy"],
                        hover=COLORS["gold_light"], outer=COLORS["bg"],
                        font=(FONT, 13, "bold"), height=44, radius=12,
                        min_pad=30).pack(side=tk.LEFT, padx=8)
        win.protocol("WM_DELETE_WINDOW", lambda: choose(LANG))
        # make sure this can't hide behind other apps - it blocks startup
        win.lift()
        try:
            win.attributes("-topmost", True)
            win.after(600, lambda: win.winfo_exists() and win.attributes("-topmost", False))
        except tk.TclError:
            pass
        win.focus_force()
        self.root.wait_window(win)

        CONFIG["lang"] = picked["v"]
        save_config(CONFIG)
        if picked["v"] != LANG:
            self._reexec()

    # ---------------- language ----------------
    def _clean_tok(self):
        return self._clean_l2t.get(self.clean_mode.get(), "ai")

    def _model_id(self):
        return self._model_l2i.get(self.model_var.get(), "claude-haiku-4-5")

    def _readin(self):
        return self._readin_l2t.get(self.readin_var.get(), "auto")

    def _voice_list(self):
        r = self._readin()
        if r in ("en", "es"):
            return list(VOICES[r])
        return list(VOICES["en"]) + list(VOICES["es"])

    def _on_readin_change(self):
        r = self._readin()
        vl = self._voice_list()
        if hasattr(self, "_voice_dd"):
            self._set_dd(self._voice_dd, vl)
        if self.voice_var.get() not in vl:
            self.voice_var.set(DEFAULT_VOICE_FOR.get(r, vl[0]))
        # translating is an AI-cleaning job; nudge the mode so it actually happens
        if r != "auto" and self._clean_tok() != "ai":
            self.clean_mode.set(self._clean_t2l["ai"])
            if not get_api_key():
                self._status(t("st_translate_needs_ai"))
        self._update_estimate()

    def _on_lang_change(self):
        new = {v: k for k, v in UI_LANG_LABELS.items()}.get(self.lang_var.get())
        if not new or new == LANG:
            return
        if self.busy:
            # a relaunch here would throw away a running clean/translate/generate
            self._status(t("st_lang_busy"))
            self.root.after_idle(lambda: self.lang_var.set(UI_LANG_LABELS[LANG]))
            return
        self._persist()
        CONFIG["lang"] = new          # after _persist, which would rewrite LANG
        save_config(CONFIG)
        self._status(t("st_restarting", lang=self.lang_var.get()))
        self.root.after(450, self._reexec)

    def _reexec(self):
        """Relaunch in a fresh process. Spawning a detached child and exiting is
        far more reliable than execv() once SDL/audio has been initialised."""
        try:
            self.player.stop()
            self.player.cleanup()
            pygame.mixer.quit()
        except Exception:
            pass
        script = str(Path(__file__).resolve())
        argv = [sys.executable, script] + [a for a in sys.argv[1:] if a != script]
        env = dict(os.environ, TT_RELAUNCH="1")   # child waits for the lock anyway
        # drop the single-instance lock *first* so the child never contends for it
        release_single_instance()
        spawned = False
        for _ in range(3):
            try:
                subprocess.Popen(argv, env=env, start_new_session=True,
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
                spawned = True
                break
            except Exception as e:
                print("relaunch attempt failed:", e)
                time.sleep(0.3)
        if not spawned:                # last resort: replace this process
            try:
                os.execv(sys.executable, argv)
            except Exception:
                pass
        os._exit(0)

    def _init_geometry(self):
        self.root.update_idletasks()
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()

        # Minimum size adapts down on small displays so the window still fits.
        min_w, min_h = min(self.MIN_W, sw - 40), min(self.MIN_H, sh - 60)
        self.root.minsize(min_w, min_h)

        w, h = min(960, sw - 120), min(840, sh - 120)
        x = y = None
        m = re.match(r"(\d+)x(\d+)(?:\+(-?\d+)\+(-?\d+))?", CONFIG.get("geometry", ""))
        if m and int(m.group(1)) >= self.FULL_MIN_W and int(m.group(2)) >= self.FULL_MIN_H:
            w = min(int(m.group(1)), sw - 40)
            h = min(int(m.group(2)), sh - 60)
            if m.group(3) is not None:
                x, y = int(m.group(3)), int(m.group(4))

        w, h = max(w, min_w), max(h, min_h)
        if x is None or not self._pos_visible(x, y, w, sw, sh):
            x, y = (sw - w) // 2, max(24, (sh - h) // 3)
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self._full_geometry = f"{w}x{h}+{x}+{y}"

    @staticmethod
    def _pos_visible(x, y, w, sw, sh, margin=140):
        """True if a decent slice of the title bar would land on the screen."""
        return (0 <= y < sh - 60) and (x + w > margin) and (x < sw - margin)

    def _front(self):
        self.root.lift()
        try:
            self.root.attributes("-topmost", True)
            self.root.after(500, lambda: self.root.attributes("-topmost", False))
        except tk.TclError:
            pass

    # ---------------- style ----------------
    def _style(self):
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass

        def cfg(name, **kw):
            try:
                st.configure(name, **kw)
            except tk.TclError:
                pass

        # clam draws the scale's handle with `background` - keep it gold so the
        # speed control reads as a control, not a dark smudge on a dark trough
        cfg("TT.Horizontal.TScale", background=COLORS["gold"], borderwidth=0,
            troughcolor=COLORS["wave_bg"], bordercolor=COLORS["wave_bg"],
            darkcolor=COLORS["gold_deep"], lightcolor=COLORS["gold_light"],
            sliderthickness=16, sliderlength=17)
        try:
            st.map("TT.Horizontal.TScale",
                   background=[("active", COLORS["gold_light"])])
        except tk.TclError:
            pass
        cfg("Gold.Horizontal.TProgressbar", background=COLORS["gold"], borderwidth=0,
            troughcolor=COLORS["wave_bg"], lightcolor=COLORS["gold"],
            darkcolor=COLORS["gold"])
        # dropdowns in the Settings dialog - the default macOS rendering is a
        # light grey aqua widget that clashes badly with the navy panel
        cfg("TT.TCombobox", fieldbackground=COLORS["navy"], background=COLORS["navy"],
            foreground=COLORS["text"], arrowcolor=COLORS["gold"],
            bordercolor=COLORS["border"], lightcolor=COLORS["navy"],
            darkcolor=COLORS["navy"], borderwidth=0, padding=6)
        try:
            st.map("TT.TCombobox",
                   fieldbackground=[("readonly", COLORS["navy"])],
                   background=[("readonly", COLORS["navy"])],
                   foreground=[("readonly", COLORS["text"])],
                   selectbackground=[("readonly", COLORS["navy"])],
                   selectforeground=[("readonly", COLORS["text"])],
                   arrowcolor=[("active", COLORS["gold_light"])])
        except tk.TclError:
            pass
        # the popup list is a classic Tk listbox, reachable only via the options db
        for opt, val in (("background", COLORS["navy"]), ("foreground", COLORS["text"]),
                         ("selectBackground", COLORS["gold"]),
                         ("selectForeground", COLORS["navy"]),
                         ("borderWidth", "0")):
            try:
                self.root.option_add(f"*TCombobox*Listbox.{opt}", val)
            except tk.TclError:
                pass

        # the editor's scrollbar: macOS renders a plain tk.Scrollbar as a white
        # bar that ignores colours, so use a themed one that doesn't
        cfg("TT.Vertical.TScrollbar", background=COLORS["highlight"], borderwidth=0,
            troughcolor=COLORS["navy_dark"], bordercolor=COLORS["navy_dark"],
            arrowcolor=COLORS["navy_dark"], darkcolor=COLORS["navy_dark"],
            lightcolor=COLORS["navy_dark"], arrowsize=11, relief=tk.FLAT)
        try:
            st.map("TT.Vertical.TScrollbar",
                   background=[("active", COLORS["gold_deep"])])
            # trough + thumb only; clam's stepper arrows look like leftover chrome
            st.layout("TT.Vertical.TScrollbar", [
                ("Vertical.Scrollbar.trough", {"sticky": "ns", "children": [
                    ("Vertical.Scrollbar.thumb",
                     {"expand": "1", "sticky": "nswe"})]})])
        except tk.TclError:
            pass

    # ---------------- menu ----------------
    def _build_menu(self):
        bar = tk.Menu(self.root)
        m_file = tk.Menu(bar, tearoff=0)
        m_file.add_command(label=t("m_listen_doc"), accelerator="Cmd+L",
                           command=self.one_click)
        m_file.add_command(label=t("m_open_file"), accelerator="Cmd+O", command=self.load_file)
        m_file.add_command(label=t("m_open_audio"), command=self.load_mp3)
        m_file.add_separator()
        m_file.add_command(label=t("m_save_audio"), accelerator="Cmd+S", command=self.save_audio)
        m_file.add_command(label=t("m_show_output"), command=lambda: open_folder(STORAGE_DIR))
        bar.add_cascade(label=t("m_file"), menu=m_file)

        m_play = tk.Menu(bar, tearoff=0)
        m_play.add_command(label=t("m_play_pause"), accelerator="Space", command=self._toggle)
        m_play.add_command(label=t("m_back10"), accelerator="Left", command=lambda: self._nudge(-10))
        m_play.add_command(label=t("m_fwd10"), accelerator="Right", command=lambda: self._nudge(10))
        bar.add_cascade(label=t("m_playback"), menu=m_play)

        m_set = tk.Menu(bar, tearoff=0)
        m_set.add_command(label=t("m_api_model"), accelerator="Cmd+,",
                          command=self.open_settings)
        bar.add_cascade(label=t("settings"), menu=m_set)
        self.root.config(menu=bar)

    # ---------------- widget helpers ----------------
    def _rbtn(self, parent, text, cmd, kind="primary", size="md", grow=False):
        pal = {
            "primary": (COLORS["gold"], COLORS["navy"], COLORS["gold_light"]),
            "ghost": (COLORS["panel_soft"], COLORS["gold"], COLORS["highlight"]),
        }[kind]
        fnt = {"lg": (FONT, 15, "bold"), "md": (FONT, 12, "bold"),
               "sm": (FONT, 11, "bold")}[size]
        return RoundButton(parent, text, cmd, fill=pal[0], fg=pal[1], hover=pal[2],
                           outer=parent["bg"], font=fnt,
                           height={"lg": 52, "md": 42, "sm": 34}[size],
                           radius={"lg": 16, "md": 12, "sm": 10}[size],
                           min_pad={"lg": 26, "md": 18, "sm": 13}[size], grow=grow)

    def _hairline(self, parent, pady=(0, 0)):
        tk.Frame(parent, bg=COLORS["border"], height=1).pack(fill=tk.X, pady=pady)

    def _load_logo(self):
        try:
            p = Path(__file__).resolve().parent / "header.png"
            if not p.exists():
                return None
            img = tk.PhotoImage(file=str(p))
            f = max(1, round(img.width() / 40))
            return img.subsample(f, f)
        except Exception:
            return None

    def _dropdown(self, parent, label, var, values, width=16):
        box = tk.Frame(parent, bg=parent["bg"])
        tk.Label(box, text=label.upper(), font=(FONT, 9, "bold"),
                 fg=COLORS["text_dim"], bg=parent["bg"]).pack(anchor="w")
        field = tk.Frame(box, bg=COLORS["navy"], cursor="hand2")
        field.pack(anchor="w", pady=(4, 0))
        val = tk.Label(field, textvariable=var, font=(FONT, 12), fg=COLORS["text"],
                       bg=COLORS["navy"], anchor="w", width=width, cursor="hand2")
        val.pack(side=tk.LEFT, padx=(12, 6), pady=8)
        chev = tk.Label(field, text="▾", font=(FONT, 11), fg=COLORS["gold"],
                        bg=COLORS["navy"], cursor="hand2")
        chev.pack(side=tk.RIGHT, padx=(0, 11))
        menu = tk.Menu(field, tearoff=0, bg=COLORS["navy"], fg=COLORS["text"],
                       activebackground=COLORS["gold"], activeforeground=COLORS["navy"],
                       bd=0, relief=tk.FLAT, font=(FONT, 11))
        box._menu, box._var = menu, var
        self._set_dd(box, values)

        def popup(_):
            menu.tk_popup(field.winfo_rootx(), field.winfo_rooty() + field.winfo_height() + 2)

        for w in (field, val, chev):
            w.bind("<Button-1>", popup)
            w.bind("<Enter>", lambda e: [x.config(bg=COLORS["navy_light"]) for x in (field, val, chev)])
            w.bind("<Leave>", lambda e: [x.config(bg=COLORS["navy"]) for x in (field, val, chev)])
        return box

    @staticmethod
    def _set_dd(box, values):
        """(Re)populate a dropdown built by _dropdown."""
        box._menu.delete(0, "end")
        for v in values:
            box._menu.add_command(label=v, command=lambda vv=v: box._var.set(vv))

    def _side_pad(self):
        """Horizontal window padding: a fixed gutter, plus half of any width past
        MAX_CONTENT_W so the content stays centred and never over-stretches."""
        w = self.root.winfo_width()
        slack = max(0, w - self.MAX_CONTENT_W) // 2 if w > 1 else 0
        return self._BASE_PAD + slack

    def _restore_full_window(self):
        self.root.geometry(self._full_geometry)

    def _reflow(self, event):
        if event.widget is not self.root or not hasattr(self, "_full_packing"):
            return
        compact = event.width < self.FULL_MIN_W or event.height < self.FULL_MIN_H
        if compact != self._compact:
            self._compact = compact
            # Keep the same widgets and player: resizing never loses editor text,
            # playback position, loaded audio, or an in-flight generation job.
            for widget, _ in self._full_packing:
                widget.pack_forget()
            self._speed_frame.pack_forget()
            if compact:
                self._player_frame.pack(side=tk.TOP, fill=tk.X)
                self._speed_frame.pack(in_=self._player_pad, fill=tk.X, pady=(8, 0))
                self.reveal_btn.pack_forget()
                self._expand_btn.pack(side=tk.RIGHT, before=self.track_lbl)
                self.wave.configure(height=48)
                if self._typing():
                    self.root.focus_set()
            else:
                for widget, options in self._full_packing:
                    widget.pack(**options)
                self._speed_frame.pack(in_=self._transport, side=tk.RIGHT)
                self._expand_btn.pack_forget()
                self.reveal_btn.pack(side=tk.RIGHT)
                self.wave.configure(height=70)
        if not compact:
            self._full_geometry = self.root.winfo_geometry()
        pad = 10 if compact else self._side_pad()
        self._main.pack_configure(padx=pad, pady=10 if compact else 16)
        if not compact:
            self._fit_options(pad)

    def _opt_needed_width(self):
        """Width one row of dropdowns needs, measured once and cached.

        Their labels have fixed character widths, so the figure never changes -
        but Tk propagates geometry requests lazily, so a measurement taken too
        early reads far too small. Return 0 until it has settled.
        """
        if getattr(self, "_opt_need", 0):
            return self._opt_need
        self._opt_row.update_idletasks()
        widths = [b.winfo_reqwidth() for b in self._opt_boxes]
        if min(widths) < 60:                 # not settled yet - ask again later
            return 0
        self._opt_need = sum(widths) + self._OPT_GAP * (len(self._opt_boxes) - 1)
        return self._opt_need

    def _fit_options(self, pad):
        """The four setting dropdowns sit on one row when there is room and fall
        to a 2x2 grid when there isn't - on a narrow window the last one used to
        be clipped at the card's edge."""
        if not getattr(self, "_opt_boxes", None):
            return
        need = self._opt_needed_width()
        if not need:
            self.root.after(120, lambda: self._fit_options(self._side_pad()))
            return
        avail = self.root.winfo_width() - 2 * pad - 2 * self._OPT_CARD_PAD
        self._layout_options(4 if avail >= need else 2)

    def _layout_options(self, cols):
        if cols == getattr(self, "_opt_cols", None):
            return
        self._opt_cols = cols
        boxes = self._opt_boxes
        last_row = (len(boxes) - 1) // cols
        for b in boxes:
            b.grid_forget()
        for i, b in enumerate(boxes):
            r, c = divmod(i, cols)
            b.grid(row=r, column=c, sticky="w",
                   padx=(0, self._OPT_GAP if c < cols - 1 else 0),
                   pady=(0, 0 if r == last_row else 12))

    # ---------------- UI ----------------
    def _build_ui(self):
        main = tk.Frame(self.root, bg=COLORS["bg"])
        main.pack(fill=tk.BOTH, expand=True, padx=self._side_pad(), pady=16)
        self._main = main
        self.root.bind("<Configure>", self._reflow)

        # ---- bottom-pinned: status, player, generate ----
        status = tk.Frame(main, bg=COLORS["bg"])
        status.pack(side=tk.BOTTOM, fill=tk.X, pady=(10, 0))
        tk.Label(status, textvariable=self.status_var, font=(FONT, 10),
                 fg=COLORS["text_dim"], bg=COLORS["bg"], anchor="w").pack(side=tk.LEFT)

        self._build_player(main)

        genrow = tk.Frame(main, bg=COLORS["bg"])
        genrow.pack(side=tk.BOTTOM, fill=tk.X, pady=(11, 0))
        self.generate_btn = self._rbtn(genrow, t("btn_generate"),
                                       self._generate_or_stop, size="md")
        self.generate_btn.pack()
        self.progress = ttk.Progressbar(genrow, mode="indeterminate",
                                        style="Gold.Horizontal.TProgressbar")

        # ---- header ----
        head = tk.Frame(main, bg=COLORS["bg"])
        head.pack(side=tk.TOP, fill=tk.X)
        self._logo_img = self._load_logo()
        if self._logo_img is not None:
            tk.Label(head, image=self._logo_img, bg=COLORS["bg"]).pack(
                side=tk.LEFT, padx=(0, 10))
        tk.Label(head, text=APP_NAME, font=(FONT, 21, "bold"),
                 fg=COLORS["gold"], bg=COLORS["bg"]).pack(side=tk.LEFT)
        self._rbtn(head, t("settings"), self.open_settings, kind="ghost", size="sm").pack(side=tk.RIGHT)
        self._hairline(main, pady=(12, 12))

        # ---- hero ----
        self.oneclick_btn = self._rbtn(main, t("hero_btn"),
                                       self.one_click, size="lg", grow=True)
        self.oneclick_btn.pack(side=tk.TOP, fill=tk.X)
        tk.Label(main, text=t("hero_caption"),
                 font=(FONT, 10), fg=COLORS["text_dim"], wraplength=640,
                 justify="center", bg=COLORS["bg"]).pack(side=tk.TOP, pady=(7, 13))

        # ---- options card ----
        opt = tk.Frame(main, bg=COLORS["panel_soft"])
        opt.pack(side=tk.TOP, fill=tk.X)
        row = tk.Frame(opt, bg=COLORS["panel_soft"])
        row.pack(fill=tk.X, padx=self._OPT_CARD_PAD, pady=13)
        self._opt_row = row
        self._voice_dd = self._dropdown(row, t("lbl_voice"), self.voice_var,
                                        self._voice_list(), width=15)
        self._opt_boxes = [
            self._voice_dd,
            self._dropdown(row, t("lbl_speed"), self.rate_var, list(SPEECH_RATES),
                           width=6),
            self._dropdown(row, t("lbl_cleaning"), self.clean_mode,
                           [CLEAN_LABELS[LANG][k] for k in CLEAN_TOKENS], width=12),
            self._dropdown(row, t("lbl_readin"), self.readin_var,
                           [READIN_LABELS[LANG][k] for k in READIN_TOKENS], width=13),
        ]
        self._opt_cols = None
        self._layout_options(4)

        # ---- secondary actions ----
        act = tk.Frame(main, bg=COLORS["bg"])
        act.pack(side=tk.TOP, fill=tk.X, pady=(11, 8))
        self._job_btns = []
        for label, cmd in ((t("btn_open_file"), self.load_file),
                           (t("btn_open_audio"), self.load_mp3),
                           (t("btn_clean_only"), self.clean_only),
                           (t("btn_translate"), self.translate_text)):
            b = self._rbtn(act, label, cmd, kind="ghost", size="sm")
            b.pack(side=tk.LEFT, padx=(0, 8))
            self._job_btns.append(b)
        est = tk.Frame(act, bg=COLORS["bg"])
        est.pack(side=tk.RIGHT)
        tk.Label(est, textvariable=self.cost_var, font=(FONT, 10, "bold"),
                 fg=COLORS["gold"], bg=COLORS["bg"]).pack(side=tk.RIGHT)
        tk.Label(est, textvariable=self.estimate_var, font=(FONT, 10),
                 fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(side=tk.RIGHT, padx=(0, 7))

        # ---- text ----
        wrap = tk.Frame(main, bg=COLORS["border"])
        wrap.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        inner = tk.Frame(wrap, bg=COLORS["navy_dark"])
        inner.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)
        self.text = tk.Text(inner, font=(FONT, 13), fg=COLORS["text"],
                            bg=COLORS["navy_dark"], insertbackground=COLORS["gold"],
                            relief=tk.FLAT, bd=0, highlightthickness=0, wrap=tk.WORD,
                            padx=18, pady=16, selectbackground=COLORS["highlight"],
                            undo=True, height=7)
        vbar = ttk.Scrollbar(inner, orient=tk.VERTICAL, command=self.text.yview,
                             style="TT.Vertical.TScrollbar")
        self.text.configure(yscrollcommand=vbar.set)
        self.text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vbar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 2), pady=2)
        self.text.insert("1.0", PLACEHOLDER)
        self.text.configure(fg=COLORS["text_dim"])
        self.text.bind("<FocusIn>", self._clear_placeholder)
        self.text.bind("<FocusOut>", self._restore_placeholder)
        self.text.bind("<<Modified>>", self._on_text_modified)

        self._compact = False
        self._full_packing = [(w, w.pack_info()) for w in main.pack_slaves()]

    def _build_player(self, main):
        pf = tk.Frame(main, bg=COLORS["panel"])
        pf.pack(side=tk.BOTTOM, fill=tk.X, pady=(12, 0))
        self._player_frame = pf
        pad = tk.Frame(pf, bg=COLORS["panel"])
        pad.pack(fill=tk.X, padx=18, pady=13)
        self._player_pad = pad

        top = tk.Frame(pad, bg=COLORS["panel"])
        top.pack(fill=tk.X)
        self.track_lbl = tk.Label(top, text=t("player"), font=(FONT, 9, "bold"),
                                  fg=COLORS["text_dim"], bg=COLORS["panel"], anchor="w")
        self.track_lbl.configure(width=1)
        self.track_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.reveal_btn = tk.Label(top, text=t("show_in_finder"), font=(FONT, 10),
                                   fg=COLORS["text_dim"], bg=COLORS["panel"], cursor="hand2")
        self.reveal_btn.pack(side=tk.RIGHT)
        self._expand_btn = self._rbtn(top, "Full app" if LANG == "en" else "Ampliar",
                                      self._restore_full_window, kind="ghost", size="sm")
        self.reveal_btn.bind("<Button-1>",
                             lambda e: self.last_output and reveal(self.last_output))

        self.wave = WaveformView(pad, self._on_wave_seek)
        self.wave.pack(fill=tk.X, pady=(8, 4))

        trow = tk.Frame(pad, bg=COLORS["panel"])
        trow.pack(fill=tk.X)
        tk.Label(trow, textvariable=self.time_cur, font=(FONT, 10),
                 fg=COLORS["text_dim"], bg=COLORS["panel"]).pack(side=tk.LEFT)
        tk.Label(trow, textvariable=self.time_tot, font=(FONT, 10),
                 fg=COLORS["text_dim"], bg=COLORS["panel"]).pack(side=tk.RIGHT)

        ctl = tk.Frame(pad, bg=COLORS["panel"])
        ctl.pack(fill=tk.X, pady=(8, 0))
        self._transport = ctl
        self._rbtn(ctl, "↺ 10", lambda: self._nudge(-10), kind="ghost", size="sm").pack(side=tk.LEFT, padx=(0, 6))
        self.play_btn = self._rbtn(ctl, t("btn_play"), self._toggle, size="md")
        self.play_btn.pack(side=tk.LEFT, padx=(0, 6))
        self._rbtn(ctl, t("btn_stop"), self._stop, kind="ghost", size="sm").pack(side=tk.LEFT, padx=(0, 6))
        self._rbtn(ctl, "10 ↻", lambda: self._nudge(10), kind="ghost", size="sm").pack(side=tk.LEFT)

        sf = tk.Frame(pad, bg=COLORS["panel"])
        self._speed_frame = sf
        sf.pack(in_=ctl, side=tk.RIGHT)
        tk.Label(sf, text=t("speed"), font=(FONT, 9, "bold"), fg=COLORS["text_dim"],
                 bg=COLORS["panel"]).pack(side=tk.LEFT, padx=(0, 10))
        self.speed_lbl = tk.Label(sf, text=self._speed_text(1.0), font=(FONT, 10, "bold"),
                                  fg=COLORS["gold"], bg=COLORS["panel"], width=5)
        self.speed_scale = ttk.Scale(sf, from_=0.5, to=2.0, variable=self.speed_var,
                                     orient=tk.HORIZONTAL, length=120,
                                     style="TT.Horizontal.TScale", command=self._on_speed)
        self.speed_scale.pack(side=tk.LEFT)
        self.speed_lbl.pack(side=tk.LEFT)
        self.speed_var.set(1.0)

    def _on_wave_seek(self, frac):
        if self.player.current_file and self.player.get_duration() > 0:
            self.player.seek(frac * self.player.get_duration())
            self.wave.set_progress(frac)
            self._update_time()
            self._sync_transport()

    def _sync_transport(self):
        """Keep the play/pause button and the progress loop honest about what the
        player is actually doing (scrubbing used to leave them out of step)."""
        self.play_btn.set_text(t("btn_pause") if self.player.is_playing else t("btn_play"))
        if self.player.is_playing:
            self._tick()

    def _bind_keys(self):
        r = self.root
        r.bind_all("<Command-o>", lambda e: self.load_file())
        r.bind_all("<Command-l>", lambda e: self.one_click())
        r.bind_all("<Command-s>", lambda e: self.save_audio())
        r.bind_all("<Command-comma>", lambda e: self.open_settings())
        r.bind_all("<Command-Return>", lambda e: self.generate())
        r.bind_all("<Escape>", lambda e: self.cancel_work())
        r.bind("<space>", self._key_space)
        r.bind("<Left>", lambda e: self._key_seek(e, -10))
        r.bind("<Right>", lambda e: self._key_seek(e, 10))

    def _typing(self):
        return self.root.focus_get() in (self.text,)

    def _key_space(self, e):
        if self._typing():
            return
        self._toggle()
        return "break"

    def _key_seek(self, e, d):
        if self._typing():
            return
        self._nudge(d)
        return "break"

    def _setup_dnd(self):
        if HAS_DND:
            self.text.drop_target_register(DND_FILES)
            self.text.dnd_bind("<<Drop>>", self._on_drop)

    # ---------------- text helpers ----------------
    def _clear_placeholder(self, _=None):
        if self.text.get("1.0", "end-1c").strip() == PLACEHOLDER.strip():
            self._programmatic_edit = True
            try:
                self.text.delete("1.0", tk.END)
                self.text.configure(fg=COLORS["white"])
            finally:
                self._programmatic_edit = False

    def _on_text_modified(self, _=None):
        if getattr(self, "_in_mod", False):
            return
        self._in_mod = True
        try:
            self.text.edit_modified(False)
        finally:
            self._in_mod = False
        # If the box no longer holds what the app itself last put there, the user
        # has typed or pasted, so it is no longer the loaded document - otherwise
        # the next export gets named after a file it isn't. Compared by content
        # rather than by a flag: Tk delivers <<Modified>> asynchronously, so any
        # "we are editing right now" window has already closed by the time we run.
        if self.source_path is not None and \
                self.text.get("1.0", "end-1c") != self._loaded_text:
            self.source_path = None
        self._queue_estimate()

    def _restore_placeholder(self, _=None):
        if not self.text.get("1.0", "end-1c").strip():
            self._programmatic_edit = True
            try:
                self.text.insert("1.0", PLACEHOLDER)
                self.text.configure(fg=COLORS["text_dim"])
            finally:
                self._programmatic_edit = False

    def _get_text(self):
        t = self.text.get("1.0", "end-1c").strip()
        return "" if t == PLACEHOLDER.strip() else t

    def _set_text(self, s):
        self._programmatic_edit = True
        try:
            self.text.delete("1.0", tk.END)
            self.text.insert("1.0", s)
            self.text.configure(fg=COLORS["white"])
        finally:
            self._programmatic_edit = False
        self._loaded_text = self.text.get("1.0", "end-1c")
        self._update_estimate()

    def _queue_estimate(self):
        """Debounce the live estimate. It walks the whole text, so recomputing it
        on every keystroke made typing in a long paper feel sticky."""
        if self._est_job:
            try:
                self.root.after_cancel(self._est_job)
            except tk.TclError:
                pass
        self._est_job = self.root.after(250, self._update_estimate)

    def _update_estimate(self):
        self._est_job = None
        text = self._get_text()
        words = len(text.split())
        if words < 20:
            self.estimate_var.set("")
            self.cost_var.set("")
            return
        secs = words / (WORDS_PER_MIN * _rate_mult(self.rate_var.get())) * 60
        base = (t("est_words", words=words) + "  ·  "
                + t("est_audio", t=self._fmt(secs)))

        # Audio (Edge TTS) is always free — the only paid step is AI cleaning.
        if self._clean_tok() != "ai":
            self.estimate_var.set(base + "  ·  " + t("est_free"))
            self.cost_var.set("")
            return

        tag = fmt_cost(estimate_clean_cost(text, self._model_id()))
        self.estimate_var.set(base + "  ·  " + t("est_clean"))
        self.cost_var.set(tag if get_api_key() else t("est_with_key", tag=tag))

    def _ai_clean_active(self):
        return self._clean_tok() == "ai" and bool(get_api_key())

    def _confirm_cost(self, text, threshold=0.50, force=False):
        """Ask before a Claude pass that would cost more than `threshold`."""
        if not force and not self._ai_clean_active():
            return True
        usd = estimate_clean_cost(text, self._model_id())
        if usd < threshold:
            return True
        name = self.model_var.get().split("  ")[0]
        return messagebox.askokcancel(
            APP_NAME, t("confirm_cost", name=name, cost=fmt_cost(usd)))

    def _status(self, msg):
        # clamp: the status strip sits on one line, and a long path (or a long
        # error) would otherwise push the window wider than the user sized it
        msg = str(msg).replace("\n", " ")
        if len(msg) > 116:
            msg = msg[:60] + " … " + msg[-53:]
        self._post(self.status_var.set, msg)

    def _persist(self):
        CONFIG.update(lang=LANG, voice=self.voice_var.get(), rate=self.rate_var.get(),
                      model=self._model_id(), clean_mode=self._clean_tok(),
                      readin=self._readin(), geometry=self._full_geometry)
        CONFIG.pop("model_label", None)
        save_config(CONFIG)

    def _lock(self, locked, label=None):
        """Lock the UI during a background job. The Generate button stays live
        and becomes Stop, so long jobs can always be cancelled."""
        self.busy = locked
        self.oneclick_btn.enable(not locked)
        for b in getattr(self, "_job_btns", ()):      # open / clean / translate
            b.enable(not locked)
        self.generate_btn.set_text(t("btn_stop_work") if locked else t("btn_generate"))
        self.generate_btn.enable(True)
        if locked:
            self._cancel.clear()
            self.progress.pack(fill=tk.X, pady=(10, 0))
            self.progress.start(14)
            self._status(label or t("st_working"))
        else:
            self._cancel.clear()
            self.progress.stop()
            self.progress.pack_forget()

    # ---------------- stop / cancel ----------------
    def _generate_or_stop(self):
        if self.busy:
            self.cancel_work()
        else:
            self.generate()

    def cancel_work(self):
        if not self.busy or self._cancel.is_set():
            return
        self._cancel.set()
        self._status(t("st_stopping"))

    def _stopping(self):
        return self._cancel.is_set()

    def _finish_cancelled(self):
        self._lock(False)
        self._status(t("st_stopped"))

    # ---------------- load ----------------
    def _dialog_dir(self):
        d = CONFIG.get("last_dir", "")
        return d if d and os.path.isdir(d) else str(Path.home())

    def _remember_dir(self, path):
        CONFIG["last_dir"] = str(Path(path).parent)

    def _on_drop(self, event):
        if self.busy:                       # don't swap the text out from under a job
            self._status(t("st_busy_wait"))
            return
        raw = event.data.strip()
        path = raw[1:-1] if raw.startswith("{") and raw.endswith("}") else raw.split(" ")[0]
        self._ingest(path, auto=True)

    def load_file(self):
        if self.busy:
            self._status(t("st_busy_wait"))
            return
        p = filedialog.askopenfilename(
            title=t("dlg_select_doc"), initialdir=self._dialog_dir(),
            filetypes=[(t("ft_text_pdf"), "*.txt *.pdf *.docx"), (t("ft_all"), "*.*")])
        if p:
            self._ingest(p)

    def load_mp3(self):
        if self.busy:
            self._status(t("st_busy_wait"))
            return
        p = filedialog.askopenfilename(
            title=t("dlg_select_audio"), initialdir=self._dialog_dir(),
            filetypes=[(t("ft_audio"), "*.mp3 *.wav *.ogg")])
        if p:
            self._remember_dir(p)
            self._load_audio(p)

    def _ingest(self, path, auto=False):
        p = Path(path)
        if not p.exists():
            messagebox.showerror(APP_NAME, t("msg_file_not_found", path=path))
            return False
        self._remember_dir(p)
        if p.suffix.lower() in (".mp3", ".wav", ".ogg"):
            self._load_audio(str(p))
            return False
        try:
            txt, skipped, total = extract_text(p)
        except Exception as e:
            messagebox.showerror(APP_NAME, t("msg_cant_read", err=e))
            return False
        if not txt.strip():
            messagebox.showwarning(APP_NAME, t("msg_no_text"))
            return False
        self.source_path = p
        self._set_text(txt)
        if skipped:
            # never silently lose pages - say exactly how many had no text
            self._status(t("st_pdf_partial", name=p.name, n=len(txt),
                           skipped=skipped, total=total))
            messagebox.showwarning(APP_NAME, t("msg_pdf_partial", n=skipped, total=total))
        else:
            self._status(t("st_loaded", name=p.name, n=len(txt)))
        if auto and not self.busy:
            self.generate(auto_clean=True)
        return True

    def _load_audio(self, path):
        try:
            self.player.load(path)
        except Exception as e:
            messagebox.showerror(APP_NAME, t("msg_cant_load_audio", err=e))
            return
        self.last_output = Path(path)
        self.speed_var.set(1.0)
        self.speed_lbl.config(text=self._speed_text(1.0))
        self.wave.clear()
        self.track_lbl.config(text=Path(path).stem.upper()[:60])
        self._update_time()
        self._status(t("st_ready_play", name=Path(path).name))
        threading.Thread(target=self._load_waveform, args=(str(path),), daemon=True).start()

    def _load_waveform(self, path):
        peaks = compute_peaks(path)
        if peaks is not None and str(self.player.current_file) == path:
            self._post(self.wave.set_waveform, peaks)

    # ---------------- clean ----------------
    def _clean_params(self):
        """Snapshot the cleaning settings on the main thread - tk vars are not
        safe to read from the worker threads that call _clean_text()."""
        return (self._clean_tok(), self._readin(), self._model_id(), get_api_key())

    def _clean_text(self, raw, tok, target, model, key):
        if tok == "none" or not raw:
            return raw
        # source-language guess: opposite of the translation target, else detect
        src = "en" if target == "es" else ("es" if target == "en" else _guess_lang(raw))
        base = HeuristicCleaner.clean(raw, src)
        if tok == "builtin":
            if target != "auto":
                self._status(t("st_translate_needs_ai"))
            return base
        if not key:
            self._status(t("st_no_key_builtin"))
            return base
        try:
            return ai_clean(base, key, model, self._status,
                            target_lang=None if target == "auto" else target,
                            src_lang=src, should_stop=self._stopping)
        except Cancelled:
            raise
        except Exception as e:
            self._status(t("st_claude_unavailable", err=e))
            return base

    def clean_only(self):
        raw = self._get_text()
        if not raw:
            messagebox.showwarning(APP_NAME, t("msg_need_text"))
            return
        if self.busy:
            self._status(t("st_busy_wait"))
            return
        if not self._confirm_cost(raw):
            return
        params = self._clean_params()
        self._lock(True, t("st_cleaning"))
        threading.Thread(target=self._clean_only_worker,
                         args=(raw, params), daemon=True).start()

    def _clean_only_worker(self, raw, params):
        try:
            cleaned = self._clean_text(raw, *params)
        except Cancelled:
            self._post(self._finish_cancelled)
            return
        except Exception as e:
            self._post(self._lock, False)
            self._status(t("st_claude_unavailable", err=e))
            return
        before = len(raw)
        self._post(self._set_text, cleaned)
        self._post(self._lock, False)
        pct = (before - len(cleaned)) / before * 100 if before else 0
        self._status(t("st_cleaned", n=before - len(cleaned), pct=pct))

    # ---------------- translate ----------------
    def translate_text(self):
        """Detect the text's language and translate it to the other one (en<->es)."""
        raw = self._get_text()
        if not raw:
            messagebox.showwarning(APP_NAME, t("msg_need_text"))
            return
        if self.busy:
            self._status(t("st_busy_wait"))
            return
        if not get_api_key():
            messagebox.showwarning(APP_NAME, t("st_translate_needs_ai"))
            return
        src = _guess_lang(raw)
        dst = "en" if src == "es" else "es"
        if not self._confirm_cost(raw, force=True):
            return
        model, key = self._model_id(), get_api_key()
        self._lock(True, t("st_translate_to", lang=t("lang_name_" + dst)))
        threading.Thread(target=self._translate_worker,
                         args=(raw, src, dst, key, model), daemon=True).start()

    def _translate_worker(self, raw, src, dst, key, model):
        try:
            base = HeuristicCleaner.clean(raw, src)
            out = ai_clean(base, key, model, self._status,
                           target_lang=dst, src_lang=src, should_stop=self._stopping)
        except Cancelled:
            self._post(self._finish_cancelled)
            return
        except Exception as e:
            self._post(self._lock, False)
            self._status(t("st_claude_unavailable", err=e))
            return
        if not (out or "").strip():
            # nothing came back - leave the text and the language alone
            self._post(self._lock, False)
            self._status(t("st_claude_unavailable", err="empty response"))
            return
        self._post(self._set_text, out)
        self._post(self._lock, False)
        # send the audio out in the new language too (switches the voice list)
        self._post(self.readin_var.set, self._readin_t2l[dst])
        self._status(t("st_translated", lang=t("lang_name_" + dst)))

    # ---------------- generate ----------------
    def generate(self, auto_clean=False):
        raw = self._get_text()
        if not raw:
            messagebox.showwarning(APP_NAME, t("msg_need_text"))
            return
        if self.busy:
            self._status(t("st_busy_wait"))
            return
        if auto_clean and not self._confirm_cost(raw):
            return
        self._persist()
        params = self._clean_params()
        voice = ALL_VOICES.get(self.voice_var.get()) or ALL_VOICES[DEFAULT_VOICE]
        rate = SPEECH_RATES.get(self.rate_var.get(), "+0%")
        self._lock(True, t("st_preparing"))
        threading.Thread(target=self._generate_worker,
                         args=(raw, auto_clean, params, voice, rate), daemon=True).start()

    def _derive_name(self, text):
        if self.source_path:
            return _slugify(self.source_path.stem)
        first = next((ln.strip(" .#") for ln in text.splitlines() if ln.strip()), "")
        if 3 <= len(first) <= 90:
            return _slugify(first)
        return _slugify(f"audio {datetime.now():%Y-%m-%d %H%M}")

    def _generate_worker(self, raw, auto_clean, params, voice, rate):
        out = None
        try:
            text = self._clean_text(raw, *params) if auto_clean else raw
            if auto_clean:
                self._post(self._set_text, text)
            if not text.strip():
                raise RuntimeError(t("st_nothing_to_speak"))

            name = self._derive_name(text)
            out = _unique(STORAGE_DIR / f"{name}.mp3")
            asyncio.run(_edge_generate(text, voice, rate, str(out), self._status,
                                       should_stop=self._stopping))
            try:
                out.with_suffix(".txt").write_text(text, encoding="utf-8")
            except OSError:
                pass
            self._post(self._generation_done, str(out))
        except Cancelled:
            for leftover in (out, out.with_suffix(".txt") if out else None):
                try:
                    if leftover and Path(leftover).exists():
                        Path(leftover).unlink()
                except OSError:
                    pass
            self._post(self._finish_cancelled)
        except Exception as e:
            self._post(self._generation_fail, str(e))

    def _generation_done(self, path):
        self._lock(False)
        self._load_audio(path)
        self.reveal_btn.config(fg=COLORS["gold"])
        mins = self._fmt(self.player.get_duration())
        self._status(t("st_ready_done", name=Path(path).name, dur=mins))
        self._toggle()

    def _generation_fail(self, err):
        self._lock(False)
        self._status(t("st_didnt_work"))
        messagebox.showerror(APP_NAME, err)

    def one_click(self):
        if self.busy:
            return
        p = filedialog.askopenfilename(
            title=t("dlg_pick_listen"), initialdir=self._dialog_dir(),
            filetypes=[(t("ft_text_pdf"), "*.txt *.pdf *.docx"), (t("ft_all"), "*.*")])
        if p:
            self._ingest(p, auto=True)

    # ---------------- player ----------------
    def _toggle(self):
        if not self.player.current_file:
            return
        if not self.player.audio_ok:
            self._status(t("st_no_audio"))
            return
        if self.player.is_playing:
            self.player.pause()
            self.play_btn.set_text(t("btn_play"))
        else:
            self.player.play()
            self.play_btn.set_text(t("btn_pause"))
            self._tick()

    def _stop(self):
        if self.update_job:
            try:
                self.root.after_cancel(self.update_job)
            except tk.TclError:
                pass
            self.update_job = None
        self.player.stop()
        self.play_btn.set_text(t("btn_play"))
        self.wave.set_progress(0)
        self._update_time()

    def _nudge(self, delta):
        if self.player.current_file:
            self.player.seek(self.player.get_position() + delta)
            self._tick_once()
            self._sync_transport()

    @staticmethod
    def _speed_text(s):
        """One formatter for the speed readout so it never flips between 1x and
        1.0x - it matches the Speed dropdown's labels (0.9x, 1.0x, 1.25x)."""
        out = f"{s:.2f}".rstrip("0")
        return (out + "0" if out.endswith(".") else out) + "x"

    def _on_speed(self, value):
        if not hasattr(self, "speed_lbl"):
            return
        speed = round(float(value) * 20) / 20   # snap to 0.05
        self.speed_lbl.config(text=self._speed_text(speed))
        self._pending_speed = speed
        if self._speed_job:
            self.root.after_cancel(self._speed_job)
        self._speed_job = self.root.after(320, self._commit_speed)

    def _commit_speed(self):
        self._speed_job = None
        speed = self._pending_speed
        if self.busy or not self.player.current_file:
            # nothing to apply it to - snap the slider and the label back to the
            # speed we're really at rather than leaving a number that lies
            self._sync_speed_ui()
            if self.busy:
                self._status(t("st_busy_wait"))
            return
        if abs(speed - self.player.speed) < 0.01:
            self._sync_speed_ui()
            return
        self._status(t("st_adjusting_speed") if speed != 1.0 else t("st_normal_speed"))
        threading.Thread(target=self._apply_speed, args=(speed,), daemon=True).start()

    def _apply_speed(self, speed):
        try:
            self.player.set_speed(speed)
        except Exception as e:
            self._status(t("st_cant_change_speed", err=e))
            self._post(self._sync_speed_ui)
            return
        self._post(self._after_speed, speed)

    def _sync_speed_ui(self):
        s = round(self.player.speed, 2)
        if abs(self.speed_var.get() - s) > 0.001:
            self.speed_var.set(s)
        self.speed_lbl.config(text=self._speed_text(s))

    def _after_speed(self, requested):
        self._sync_speed_ui()
        if requested != 1.0 and abs(self.player.speed - requested) > 0.01:
            self._status(t("st_clip_too_long")
                         if self.player.duration > self.player.MAX_STRETCH_SECONDS
                         else t("st_speed_unavailable"))
        else:
            self._status(t("st_ready"))
        self._update_time()
        dur = self.player.get_duration()
        self.wave.set_progress(self.player.get_position() / dur if dur else 0)
        if self.player.is_playing:
            self._tick()          # restart the progress loop after the backend swap

    def _tick(self):
        if self.update_job:
            self.root.after_cancel(self.update_job)
        self._tick_once()

    def _tick_once(self):
        if self.player.is_playing:
            dur = self.player.get_duration()
            if dur > 0:
                self.wave.set_progress(self.player.get_position() / dur)
            self._update_time()
            if self.player.is_finished():
                self.play_btn.set_text(t("btn_play"))
                self.player.is_playing = False
                self.wave.set_progress(0)
                return
            self.update_job = self.root.after(120, self._tick_once)

    def _update_time(self):
        self.time_cur.set(self._fmt(self.player.get_position()))
        self.time_tot.set(self._fmt(self.player.get_duration()))

    @staticmethod
    def _fmt(sec):
        sec = max(0, int(round(sec)))
        return f"{sec // 60}:{sec % 60:02d}"

    def save_audio(self):
        if not self.player.current_file:
            messagebox.showwarning(APP_NAME, t("msg_need_audio"))
            return
        dest = filedialog.asksaveasfilename(
            defaultextension=".mp3", initialdir=self._dialog_dir(),
            initialfile=self.player.current_file.name, filetypes=[(t("ft_mp3"), "*.mp3")])
        if dest:
            try:
                shutil.copy(self.player.current_file, dest)
            except OSError as e:
                messagebox.showerror(APP_NAME, t("msg_cant_read", err=e))
                return
            self._remember_dir(dest)
            self._status(t("st_saved_to", dest=dest))

    # ---------------- settings ----------------
    def open_settings(self):
        if self._settings_win is not None and self._settings_win.winfo_exists():
            self._settings_win.lift()          # one settings window, not a stack
            self._settings_win.focus_force()
            return
        win = tk.Toplevel(self.root)
        self._settings_win = win
        win.title(t("set_title"))
        win.configure(bg=COLORS["bg"])
        w, h = 580, 412
        self.root.update_idletasks()
        x = self.root.winfo_rootx() + max(0, (self.root.winfo_width() - w) // 2)
        y = self.root.winfo_rooty() + 80
        win.geometry(f"{w}x{h}+{x}+{y}")       # centred on the app, not the screen
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        win.bind("<Escape>", lambda e: win.destroy())

        # --- language ---
        tk.Label(win, text=t("set_language"), font=(FONT, 12, "bold"),
                 fg=COLORS["gold"], bg=COLORS["bg"]).pack(anchor="w", padx=22, pady=(20, 4))
        lang_row = tk.Frame(win, bg=COLORS["bg"])
        lang_row.pack(anchor="w", padx=22)
        pick = tk.StringVar(value=UI_LANG_LABELS[LANG])
        ttk.Combobox(lang_row, textvariable=pick, values=list(UI_LANG_LABELS.values()),
                     state="readonly", width=18,
                     style="TT.TCombobox").pack(side=tk.LEFT)
        tk.Label(lang_row, text=t("set_language_help"), font=(FONT, 9),
                 fg=COLORS["text_dim"], bg=COLORS["bg"]).pack(side=tk.LEFT, padx=10)

        # --- api key ---
        tk.Label(win, text=t("set_api_key"), font=(FONT, 12, "bold"),
                 fg=COLORS["gold"], bg=COLORS["bg"]).pack(anchor="w", padx=22, pady=(16, 4))
        key_var = tk.StringVar(value=CONFIG.get("anthropic_api_key", ""))
        row = tk.Frame(win, bg=COLORS["bg"])
        row.pack(fill=tk.X, padx=22)
        entry = tk.Entry(row, textvariable=key_var, show="•", font=(FONT, 11),
                         bg=COLORS["navy_dark"], fg=COLORS["white"],
                         insertbackground=COLORS["gold"], relief=tk.FLAT,
                         highlightthickness=1, highlightbackground=COLORS["border"],
                         highlightcolor=COLORS["gold"])
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=4)
        # a tk.Checkbutton draws a white native box here; a ghost button reads better
        shown = {"v": False}

        def toggle_show():
            shown["v"] = not shown["v"]
            entry.config(show="" if shown["v"] else "•")
            show_btn.set_text(t("set_hide") if shown["v"] else t("set_show"))

        show_btn = self._rbtn(row, t("set_show"), toggle_show, kind="ghost", size="sm")
        show_btn.pack(side=tk.LEFT, padx=8)
        tk.Label(win, text=t("set_key_help"),
                 font=(FONT, 9), fg=COLORS["text_dim"], bg=COLORS["bg"],
                 justify="left").pack(anchor="w", padx=22, pady=(6, 14))

        tk.Label(win, text=t("set_model"), font=(FONT, 12, "bold"),
                 fg=COLORS["gold"], bg=COLORS["bg"]).pack(anchor="w", padx=22)
        ttk.Combobox(win, textvariable=self.model_var,
                     values=[self._model_i2l[m] for m in MODEL_IDS],
                     state="readonly", width=42,
                     style="TT.TCombobox").pack(anchor="w", padx=22, pady=(4, 4))
        tk.Label(win, text=t("set_model_help"),
                 font=(FONT, 9), fg=COLORS["text_dim"], bg=COLORS["bg"],
                 justify="left").pack(anchor="w", padx=22, pady=(0, 14))

        def do_save():
            key = key_var.get().strip()
            if key and not key.startswith("sk-ant-"):
                if not messagebox.askokcancel(APP_NAME, t("msg_key_looks_wrong"),
                                              parent=win):
                    return
            CONFIG["anthropic_api_key"] = key
            CONFIG["model"] = self._model_id()
            save_config(CONFIG)
            self._status(t("st_settings_saved")
                         + ("" if get_api_key() else t("st_no_key_set")))
            self._update_estimate()         # the cost line depends on having a key
            win.destroy()
            self.lang_var.set(pick.get())   # fires re-exec only if it changed

        bar = tk.Frame(win, bg=COLORS["bg"])
        bar.pack(fill=tk.X, padx=22, pady=(4, 0))
        self._rbtn(bar, t("set_save"), do_save, size="md").pack(side=tk.RIGHT)
        self._rbtn(bar, t("set_cancel"), win.destroy,
                   kind="ghost", size="md").pack(side=tk.RIGHT, padx=(0, 8))
        win.bind("<Return>", lambda e: do_save())
        entry.focus_set()

    # ---------------- shutdown ----------------
    def shutdown(self):
        if self._shut:
            return
        self._shut = True
        self._cancel.set()                 # let any worker unwind
        try:
            if self._pump_job:
                self.root.after_cancel(self._pump_job)
        except Exception:
            pass
        try:
            self._persist()
        except Exception:
            pass
        try:
            self.player.stop()
            self.player.cleanup()
            pygame.mixer.quit()
        except Exception:
            pass
        release_single_instance()


def _hand_off_to_running_instance(files):
    """Another copy is already up: leave it a note and get out of the way.

    Deliberately does NOT `osascript ... activate` - the launcher is an
    AppleScript applet, so activating it re-runs its handler and spawns yet
    another copy, which would loop. The running instance sees this file in its
    pump and raises its own window.
    """
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        OPEN_REQUEST.write_text(str(Path(files[0]).resolve()) if files else "",
                                encoding="utf-8")
    except Exception:
        pass
    print(f"{APP_NAME} is already running.")


def main():
    files = [a for a in sys.argv[1:] if not a.startswith("-") and Path(a).exists()]

    # Only one instance. Always allow a grace period so quitting and immediately
    # reopening isn't refused while the old process is still releasing its lock;
    # a language-switch relaunch waits longer for the outgoing copy to exit.
    wait = 8.0 if os.environ.get("TT_RELAUNCH") else 2.0
    if not acquire_single_instance(wait):
        _hand_off_to_running_instance(files)
        return

    root = TkinterDnD.Tk() if HAS_DND else tk.Tk()
    app = TalkingTom(root)
    root.protocol("WM_DELETE_WINDOW", lambda: (app.shutdown(), root.destroy()))

    if files:
        root.after(500, lambda: app._ingest(files[0], auto=True))

    try:
        root.mainloop()
    finally:
        app.shutdown()


if __name__ == "__main__":
    main()
