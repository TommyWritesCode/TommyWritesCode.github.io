"""Shared bounded streaming transport for text, routing, and visual analysis."""
import time
import anthropic
try:
    import httpx2 as httpx
except ImportError:
    import httpx

class InterruptedStream(Exception):
    pass

def client(api_key):
    return anthropic.Anthropic(api_key=api_key, timeout=httpx.Timeout(120.0, connect=15.0), max_retries=0)

def message(client, *, model, system, content, max_tokens=8000, effort='low', check_stop=lambda: None, progress=None):
    options = {}
    if model == 'claude-haiku-5-5':
        # Allow for the newer tokenizer and adaptive thinking as well as the answer.
        max_tokens = max(2048, int(max_tokens * 1.3) + 2048)
        options = {'thinking': {'type': 'adaptive'}, 'output_config': {'effort': effort}}
    for attempt in range(3):
        check_stop()
        try:
            completed = False
            with client.messages.stream(model=model, max_tokens=max_tokens, system=system,
                                        messages=[{'role':'user','content':content}], **options) as stream:
                for event in stream:
                    check_stop()
                    if event.type == 'message_stop': completed = True
                if not completed: raise InterruptedStream('Claude’s response ended before completion.')
                response = stream.get_final_message()
            check_stop()
            return response
        except (anthropic.APIError, httpx.TransportError, InterruptedStream) as ex:
            check_stop()
            status = getattr(ex, 'status_code', None)
            body = getattr(ex, 'body', None)
            error = body.get('error', body) if isinstance(body, dict) else {}
            kind = error.get('type') if isinstance(error, dict) else None
            transient = (isinstance(ex, (anthropic.APIConnectionError, httpx.TransportError, InterruptedStream))
                         or status in (408, 409, 429) or (status is not None and status >= 500)
                         or kind in ('overloaded_error','api_error','timeout_error'))
            if not transient or attempt == 2: raise
            if progress: progress('Connection interrupted; retrying this section…')
            delay = 2 ** attempt
            retry_after = getattr(getattr(ex, 'response', None), 'headers', {}).get('retry-after')
            if retry_after:
                try: delay = min(60, max(delay, float(retry_after)))
                except ValueError: pass
            for _ in range(int(delay * 10)):
                check_stop(); time.sleep(.1)

def text(response):
    return ''.join(b.text for b in response.content if b.type == 'text').strip()

def json_result(response):
    import json
    if response.stop_reason != 'end_turn':
        raise ValueError('Incomplete analysis: ' + str(response.stop_reason))
    raw = text(response)
    if raw.startswith('```'):
        raw = raw.split('\n', 1)[1].rsplit('```', 1)[0]
    return json.loads(raw)
