"""Local, geometry-based reading order for left-to-right research PDFs.

No AI calls, summarization, or deletion of captions/footnotes. Each word is
emitted once. Full-width lines separate column regions. See PDF_LAYOUT.md.
"""
from pathlib import Path
from statistics import median
import sys

# Keep the new reader self-contained in the app, without changing the user's venv.
_vendor = Path(__file__).with_name('pdf_vendor')
if not _vendor.is_dir():
    # The public source folder shares the installer's bundled PDF dependencies.
    _vendor = Path(__file__).resolve().parents[2] / 'Talking Tom.app/Contents/Resources/pdf_vendor'
    if _vendor.is_dir():
        # Source checks must not add bytecode files to the signed adjacent app.
        sys.dont_write_bytecode = True
if _vendor.is_dir():
    sys.path.insert(0, str(_vendor))
import pdfplumber


def _rows(words):
    rows = []
    for word in sorted(words, key=lambda w: (w['top'], w['x0'])):
        # Relative tolerance keeps superscripts with their surrounding line.
        height = word['bottom'] - word['top']
        if rows and abs(word['top'] - median(w['top'] for w in rows[-1])) <= max(3, height * .35):
            rows[-1].append(word)
        else:
            rows.append([word])
    return [sorted(row, key=lambda w: w['x0']) for row in rows]


def _render(words):
    result, previous = [], None
    for row in _rows(words):
        top = min(w['top'] for w in row)
        if previous is not None and top - previous > 5:
            result.append('')
        result.append(' '.join(w['text'] for w in row))
        previous = max(w['bottom'] for w in row)
    return '\n'.join(result)


def _gutter(rows):
    """Require repeated, wide interior gaps and substantial prose on both sides."""
    words = [w for row in rows for w in row]
    if not words:
        return None
    left, right = min(w['x0'] for w in words), max(w['x1'] for w in words)
    width = right - left
    gap = max(10, median(w['bottom'] - w['top'] for w in words))
    candidates = set()
    for row in rows:
        for a, b in zip(row, row[1:]):
            if b['x0'] - a['x1'] >= gap:
                x = (a['x1'] + b['x0']) / 2
                if left + .25 * width < x < left + .75 * width:
                    candidates.add(round(x))
    best, best_score = None, 0
    for x in candidates:
        supporting = []
        for row in rows:
            l = [w for w in row if w['x1'] <= x]
            r = [w for w in row if w['x0'] >= x]
            if len(l) + len(r) != len(row) or not l or not r or max(len(l), len(r)) < 3:
                continue
            if r[0]['x0'] - l[-1]['x1'] >= gap and l[-1]['x1'] <= x - gap / 3 and r[0]['x0'] >= x + gap / 3:
                supporting.append((l, r))
        if len(supporting) < max(5, len(rows) * .18):
            continue
        # Stable right-column starts distinguish a gutter from justified spaces.
        starts = [r[0]['x0'] for _, r in supporting]
        origin = median(starts)
        aligned = sum(abs(s - origin) <= gap for s in starts)
        if aligned < len(starts) * .8:
            continue
        score = aligned - abs(x - (left + right) / 2) / max(width, 1)
        if score > best_score:
            best, best_score = x, score
    return best


def order_words(words, page_height, table_boxes=()):
    """Return text and a diagnostic layout label; never discard input words."""
    rows = _rows(words)
    if not rows:
        return '', 'empty'
    prefix, suffix = [], []
    # Isolated running headers/footers belong outside the column flow.
    if len(rows) > 1:
        first, second = rows[:2]
        h = median(w['bottom'] - w['top'] for w in first)
        if max(w['bottom'] for w in first) < page_height * .09 and min(w['top'] for w in second) - max(w['bottom'] for w in first) > h:
            prefix = rows.pop(0)
    if len(rows) > 1:
        previous, last = rows[-2:]
        h = median(w['bottom'] - w['top'] for w in last)
        if min(w['top'] for w in last) > page_height * .9 and min(w['top'] for w in last) - max(w['bottom'] for w in previous) > h:
            suffix = rows.pop()
    cut = _gutter(rows)
    if cut is None:
        return _render(words), 'single-column-or-undetermined'
    chunks, region, spanning_words = [], [], []
    if prefix:
        chunks.append(_render(prefix))

    def flush():
        if region:
            l = [w for w in region if (w['x0'] + w['x1']) / 2 < cut]
            r = [w for w in region if (w['x0'] + w['x1']) / 2 >= cut]
            chunks.extend(_render(part) for part in (l, r) if part)
            region.clear()

    for row in rows:
        l = [w for w in row if w['x1'] <= cut]
        r = [w for w in row if w['x0'] >= cut]
        spanning = len(l) + len(r) != len(row)
        # Ruled tables spanning the gutter must retain row order.
        if any(x0 < cut < x1 and any(top <= (w['top'] + w['bottom']) / 2 <= bottom for w in row)
               for x0, top, x1, bottom in table_boxes):
            spanning = True
        if l and r and r[0]['x0'] - l[-1]['x1'] < 10:
            spanning = True
        if spanning:
            flush()
            spanning_words.extend(row)
        else:
            if spanning_words:
                chunks.append(_render(spanning_words))
                spanning_words.clear()
            region.extend(row)
    flush()
    if spanning_words:
        chunks.append(_render(spanning_words))
    if suffix:
        chunks.append(_render(suffix))
    return '\n\n'.join(chunks), 'two-column'


def extract_pdf(path):
    parts, skipped, layouts = [], 0, []
    with pdfplumber.open(path) as document:
        total = len(document.pages)
        for page in document.pages:
            words = page.extract_words(x_tolerance=2, y_tolerance=3, use_text_flow=False)
            tables = [table.bbox for table in page.find_tables()]
            text, layout = order_words(words, page.height, tables)
            layouts.append(layout)
            if text.strip():
                parts.append(text)
            else:
                skipped += 1
            page.close()  # Release cached glyphs on long papers.
    return '\n\n'.join(parts), skipped, total, layouts
