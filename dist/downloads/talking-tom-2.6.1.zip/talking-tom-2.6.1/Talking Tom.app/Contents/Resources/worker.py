"""Private local worker for the native Talking Tom UI. One request per process."""
import json,sys,signal,threading,asyncio,os
from pathlib import Path
# Signed app resources must stay immutable when importing bundled dependencies.
sys.dont_write_bytecode = True
import engine as e
stop=threading.Event()
signal.signal(signal.SIGTERM, lambda *_:stop.set())
signal.signal(signal.SIGINT, lambda *_:stop.set())
def send(kind,**values):print(json.dumps(dict(type=kind,**values)),flush=True)
def progress(message):send('progress',message=message)
def main(q):
 e.LANG=q.get('lang','en');e.T=e.STRINGS.get(e.LANG,e.STRINGS['en'])
 op=q['operation']
 if op=='extract':
  text,skipped,total=e.extract_text(Path(q['path']))
  source=''
  if Path(q['path']).suffix.lower()=='.pdf':
   from pdf_narration import attach_pdf
   source=attach_pdf(q['path'],e.CONFIG_DIR)
  send('result',text=text,skipped=skipped,total=total,source_pdf=source,visuals_prepared=False);return
 if op=='waveform':
  peaks=e.compute_peaks(q['path'],n_buckets=320);send('result',peaks=peaks.tolist() if peaks is not None else []);return
 text=q.get('text','').strip()
 if not text:raise ValueError('Add some text first.' if e.LANG=='en' else 'Añade texto primero.')
 src=e._guess_lang(text);target=q.get('readin','auto');mode=q.get('clean','builtin')
 if op=='translate':target='es' if src=='en' else 'en'
 needs_translation=target in ['en','es'] and target!=src
 visuals=bool(q.get('translate_visuals',False))
 prepared=bool(q.get('visuals_prepared',False))
 if visuals and not prepared and (not q.get('source_pdf') or not Path(q['source_pdf']).is_file()):
  raise ValueError('Reopen the original PDF to translate its visuals, or turn off Translate visuals.')
 use_ai=mode=='ai' or needs_translation or op=='translate' or visuals
 if op in ['generate','clean','translate']:
  protected={}
  if use_ai:
   key=e.get_api_key()
   if not key:raise ValueError('Add your Anthropic API key in Settings for AI cleanup, translation, or visual explanations.')
   from model_routing import choose_models,SONNET,HAIKU
   def check_stop():
    if stop.is_set():raise e.Cancelled()
   preference=q.get('model','auto')
   route=choose_models(text,key,preference,visuals=visuals and not prepared,
                       cache_dir=e.CONFIG_DIR/'model_assessments',check_stop=check_stop,progress=progress)
   progress('Using '+('Sonnet' if route['prose']==SONNET else 'Haiku')+' for prose'+
            (', '+('Sonnet' if route['visuals']==SONNET else 'Haiku')+' for visuals' if visuals and not prepared else '')+'…')
   if visuals and not prepared:
    from pdf_narration import prepare
    text,protected=prepare(text,q.get('source_pdf'),key,route['visuals'],target if target in ('en','es') else src,
                           e.CONFIG_DIR/'visual_analysis',auto=preference=='auto',check_stop=check_stop,progress=progress)
   if mode!='none' or op=='translate' or visuals:text=e.HeuristicCleaner.clean(text,src)
   try:
    text=e.ai_clean(text,key,route['prose'],progress,target_lang=target if needs_translation or op=='translate' else None,
                    src_lang=src,should_stop=stop.is_set,protected=protected,preserve_visuals=prepared)
   except RuntimeError as ex:
    # One explicit escalation in Auto mode; never retry billing/auth errors here.
    if preference!='auto' or route['prose']!=HAIKU or not ('visual explanation' in str(ex) or '(refusal)' in str(ex)):raise
    progress('Using Sonnet to preserve the document’s visual explanations…')
    text=e.ai_clean(text,key,SONNET,progress,target_lang=target if needs_translation or op=='translate' else None,
                    src_lang=src,should_stop=stop.is_set,protected=protected,preserve_visuals=prepared)
   if visuals:prepared=True
  elif mode!='none':text=e.HeuristicCleaner.clean(text,src)
 if stop.is_set():raise e.Cancelled()
 if op in ['clean','translate']:send('result',text=text,language=target if op=='translate' else q.get('readin','auto'),visuals_prepared=prepared);return
 voice=q.get('voice',e.DEFAULT_VOICE)
 if needs_translation:
  if voice not in e.VOICES[target]:voice=e.DEFAULT_VOICE_FOR[target]
 name=e._slugify(q.get('title') or text.splitlines()[0][:75] or 'Recording')
 # Reserve the filename atomically so simultaneous tabs cannot overwrite each other.
 e.STORAGE_DIR.mkdir(parents=True,exist_ok=True)
 suffix=0
 while True:
  out=e.STORAGE_DIR/(name+(f' ({suffix})' if suffix else '')+'.mp3')
  try:
   fd=os.open(out,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
   os.close(fd)
   break
  except FileExistsError:suffix+=1
 try:
  asyncio.run(e._edge_generate(text,e.ALL_VOICES.get(voice,e.ALL_VOICES[e.DEFAULT_VOICE]),e.SPEECH_RATES.get(q.get('rate'),'+0%'),str(out),progress,stop.is_set))
  if stop.is_set():raise e.Cancelled()
  out.with_suffix('.txt').write_text(text)
  send('result',text=text,path=str(out),visuals_prepared=prepared)
 except BaseException:
  out.unlink(missing_ok=True)
  raise
try:main(json.loads(sys.stdin.readline()))
except e.Cancelled:send('cancelled')
except Exception as ex:
 message=str(ex)
 key=e.get_api_key()
 if key:message=message.replace(key,'[private key]')
 send('error',message=message)
