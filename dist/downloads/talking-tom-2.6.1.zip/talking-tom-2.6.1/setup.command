#!/bin/bash
# Installs the bundled native app and its private Python runtime.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
STATE="$HOME/.talking_tom"
VENV="$STATE/venv"
APP="$HOME/Applications/Talking Tom.app"
BACKUP=""
VENV_CHANGED=0
APP_CHANGED=0
HAD_APP=0
HAD_VENV=0

fail() { printf '\n%s\n' "$1" >&2; exit 1; }
rollback() {
  result=$?
  trap - EXIT
  if [ "$result" -ne 0 ]; then
    printf '\nInstallation failed; restoring the previous app and runtime.\n' >&2
    if [ "$APP_CHANGED" -eq 1 ]; then
      rm -rf "$APP/Contents"
      if [ "$HAD_APP" -eq 1 ]; then
        ditto "$BACKUP/Talking Tom.app/Contents" "$APP/Contents"
      else
        rmdir "$APP" 2>/dev/null || true
      fi
    fi
    if [ "$VENV_CHANGED" -eq 1 ]; then
      rm -rf "$VENV"
      if [ "$HAD_VENV" -eq 1 ]; then mv "$BACKUP/venv" "$VENV"; fi
    fi
  fi
  exit "$result"
}

[ "$(uname -s)" = Darwin ] || fail "Talking Tom requires macOS."
[ "$(uname -m)" = arm64 ] || fail "This release requires an Apple Silicon Mac (M1 or newer)."
MACOS_VERSION="$(sw_vers -productVersion)"
[ "${MACOS_VERSION%%.*}" -ge 26 ] || fail "Talking Tom requires macOS 26 or newer."
if pgrep -x TalkingTom >/dev/null 2>&1 || pgrep -f "$STATE/app/talking_tom.py" >/dev/null 2>&1; then
  fail "Quit Talking Tom before installing this update."
fi
codesign --verify --deep --strict "$HERE/Talking Tom.app" || fail "The bundled app failed its integrity check. Download a fresh copy."

export UV_PYTHON_PREFERENCE=only-managed
UV="$(command -v uv || true)"
if [ -z "$UV" ] && [ -x "$HOME/.local/bin/uv" ]; then UV="$HOME/.local/bin/uv"; fi
if [ -z "$UV" ]; then
  printf 'Installing uv to manage the app’s private Python runtime...\n'
  curl --connect-timeout 15 --max-time 120 -LsSf https://astral.sh/uv/install.sh \
    | env INSTALLER_NO_MODIFY_PATH=1 sh
  UV="$HOME/.local/bin/uv"
fi
[ -x "$UV" ] || fail "uv was not installed. See https://docs.astral.sh/uv/"
"$UV" python install 3.12

mkdir -p "$STATE/backups" "$HOME/Applications"
BACKUP="$(mktemp -d "$STATE/backups/before-2.6.1.XXXXXX")"
if [ -d "$APP" ]; then
  ditto "$APP" "$BACKUP/Talking Tom.app"
  HAD_APP=1
fi
trap rollback EXIT
if [ -d "$VENV" ]; then
  mv "$VENV" "$BACKUP/venv"
  HAD_VENV=1
fi
VENV_CHANGED=1
printf 'Installing Python dependencies, including the updated speech client...\n'
"$UV" venv --python 3.12 "$VENV"
"$UV" pip install --python "$VENV/bin/python" -r "$HERE/requirements.txt"
"$VENV/bin/python" - <<'PY'
import tkinter
import edge_tts
from AVFoundation import AVAudioPlayer, AVAudioFile
assert tuple(map(int, edge_tts.__version__.split('.'))) >= (7, 3, 0)
PY

# Keep the .app directory itself so existing Finder aliases retain their target.
APP_CHANGED=1
mkdir -p "$APP"
rm -rf "$APP/Contents"
ditto "$HERE/Talking Tom.app/Contents" "$APP/Contents"
codesign --verify --deep --strict "$APP"
trap - EXIT
printf '\nTalking Tom 2.6.1 is installed.\nOpen it from Applications.\n'
printf 'Your settings, drafts, recordings and transcripts were preserved.\nBackup: %s\n' "$BACKUP"
open "$APP"
