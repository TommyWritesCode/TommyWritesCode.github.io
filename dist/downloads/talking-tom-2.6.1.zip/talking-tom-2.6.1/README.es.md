# Talking Tom 2.6.1

Una aplicación nativa para macOS que convierte PDF, Word (.docx) y texto en audio.
Necesitas **un Mac con Apple Silicon (M1 o posterior), macOS 26 o posterior y
conexión a internet**. Esta descarga no funciona en Mac con Intel. No hace falta
tener Xcode, Homebrew ni Python instalado.

## Instalar o actualizar

1. Cierra Talking Tom si está abierto.
2. Descomprime la descarga y lee este archivo. Abre `setup.command` desde la
   carpeta `talking-tom-2.6.1`. No abras la aplicación incluida antes de terminar
   la instalación: necesita el entorno privado de Python que prepara el instalador.
3. El instalador descarga uv si es necesario, una copia privada de CPython 3.12
   y los paquetes con las versiones indicadas en `requirements.txt`. La aplicación
   se instala en `~/Applications/Talking Tom.app`. Hace falta conexión a internet.
4. Abre Talking Tom desde Aplicaciones. Selecciona la limpieza estándar y el
   idioma original para generar audio gratis. Añade tu propia clave de Anthropic
   en Ajustes solo si quieres limpieza con IA, traducción o narración de elementos
   visuales.

Las actualizaciones conservan `~/.talking_tom/config.json`, los borradores y las
grabaciones/transcripciones de `~/Talking Tom`. La aplicación y el entorno de
Python anteriores se guardan en `~/.talking_tom/backups`. Si falla la instalación,
se restauran ambos.

## Seguridad de macOS

La aplicación tiene una firma local para comprobar su integridad, **pero no una
firma de Developer ID ni la notarización de Apple**. El instalador desde el código
fuente no está firmado. Si macOS no puede verificar al desarrollador, sigue las
instrucciones de Apple para esa aplicación: https://support.apple.com/es-es/102445.
No desactives Gatekeeper ni elimines la cuarentena. Si macOS detecta malware o
indica que la aplicación dañará el Mac, detente y comunica el aviso exacto.

## Novedades

- Edge TTS 7.3.0 adapta la conexión al cambio de autenticación del servicio de
  voces de Microsoft de octubre de 2026. Los errores de DNS, certificados, tiempo
  de espera y rechazo del servicio tienen mensajes distintos en español e inglés.
- Las pestañas independientes, la generación simultánea y el reproductor compacto
  facilitan las lecturas largas. La velocidad conserva el tono; los saltos son de
  15 segundos.
- El orden de lectura de PDF reconoce artículos habituales de dos columnas.
  Las solicitudes de IA se reciben por streaming y solo se reintentan las secciones
  fallidas. La selección automática de modelo y la narración opcional de elementos
  visuales utilizan Claude Haiku 5.5 y Sonnet 5.

La narración envía el texto al servicio en línea de voces de Microsoft. Las
funciones de IA son opcionales, envían texto e imágenes seleccionadas del PDF
a Anthropic y generan cargos de API. La descarga no incluye claves ni datos
personales. Los ajustes, grabaciones, transcripciones y cachés se guardan en tu
Mac. Es un proyecto personal no oficial, sin afiliación con Outfit7, Microsoft
ni Anthropic.

## Código fuente y comprobaciones

El código Swift/Python y las pruebas están en `source/native`. Las dependencias
de PDF y sus licencias están en
`Talking Tom.app/Contents/Resources/pdf_vendor`; la compilación reutiliza esa
carpeta. `source/native/README.md` explica el desarrollo. `release.json` registra
la versión, la arquitectura y las huellas del código. Esta actualización reutiliza
el ejecutable Swift probado de la versión 2.6.0 e incluye los procesos Python nuevos.

Se comprobó la narración con una grabación corta que se reprodujo correctamente
y otra completa de 3.740 palabras y 21 minutos. Pasaron siete pruebas de voz sin
conexión, las comprobaciones de concurrencia y la del protocolo de errores. La
instalación completa por internet en un Mac limpio aún no se ha probado desde
este entorno de compilación restringido.

English: see `README.md`.
