# Talking Tom 2.6.1

A native macOS app for turning PDF, Word (.docx), and plain text into audio.
Requires **Apple Silicon (M1 or newer), macOS 26 or newer, and internet access**.
This download does not support Intel Macs. No Xcode, Homebrew, or existing Python
installation is needed to install the app.

## Install or update

1. Quit Talking Tom if it is running.
2. Unzip the download and read this file. Run `setup.command` from the
   `talking-tom-2.6.1` folder. Do not launch the bundled app before setup finishes:
   it needs the private Python runtime that setup installs.
3. Setup downloads uv (if needed), a private CPython 3.12 runtime, and the pinned
   packages in `requirements.txt`. It installs the app in
   `~/Applications/Talking Tom.app`. An internet connection is required.
4. Open Talking Tom from Applications. Choose Standard cleanup and Original
   language for free narration. Add your own Anthropic API key in Settings only
   if you want AI cleanup, translation, or visual narration.

Updates preserve `~/.talking_tom/config.json`, drafts, and `~/Talking Tom`
recordings/transcripts. The old app and Python environment are backed up under
`~/.talking_tom/backups`. A failed setup restores the prior app and runtime.

## macOS security

The app is locally signed for integrity, **not Developer ID signed or notarized
by Apple**. The source installer is unsigned. If macOS cannot verify the developer,
follow Apple's per-app instructions at https://support.apple.com/102445.
Do not disable Gatekeeper or remove quarantine protection. If macOS reports
malware or says the app will damage your Mac, stop and report the exact warning.

## What changed

- Edge TTS 7.3.0 fixes compatibility with Microsoft's October 2026 speech-service
  authentication change. DNS, certificate, timeout, and service rejection errors
  have distinct English and Spanish messages.
- Independent tabs, concurrent generation, and a compact native player support
  longer reading sessions. Playback speed preserves pitch; skipping is 15 seconds.
- PDF reading order handles common two-column papers. AI requests stream and
  retry failed sections. Auto model routing and opt-in visual narration use
  Claude Haiku 5.5 and Sonnet 5.

Speech sends the narration text to Microsoft's online voice service. AI features
are optional, send text and selected PDF images to Anthropic, and incur API
charges. Keys and personal data are not bundled. Settings, recordings, transcripts,
and caches stay on your Mac. This unofficial project is not affiliated with
Outfit7, Microsoft, or Anthropic.

## Source and verification

Swift/Python source and regression tests are in `source/native`. PDF dependencies
and their licenses are in `Talking Tom.app/Contents/Resources/pdf_vendor`; the
source build reuses that directory. See `source/native/README.md` for development.
`release.json` records version, architecture, and source hashes. This backend
update reuses the tested 2.6.0 Swift executable and includes updated Python workers.

Speech verification used a short playable recording and a complete 3,740-word,
21-minute recording. Seven offline speech regressions plus engine/worker
concurrency and worker error-protocol checks passed. Clean-machine online setup
has not been exercised from this restricted build environment.

Español: see `README.es.md`.
