"""Run the production chunk assembly/cleanup code with offline chunk synthesis."""
import ast, asyncio, shutil, tempfile
from pathlib import Path
source=Path(__file__).with_name('engine.py').read_text()
node=next(n for n in ast.parse(source).body if isinstance(n,ast.AsyncFunctionDef) and n.name=='_edge_generate')
class Cancelled(Exception):pass
async def main():
 with tempfile.TemporaryDirectory(prefix='tom-engine-test-') as folder:
  root=Path(folder)
  async def save(piece,voice,rate,path,stop):
   path.write_text(piece)
   await asyncio.sleep(0.03)
   if stop and stop():raise Cancelled()
  scope=dict(Path=Path,shutil=shutil,tempfile=tempfile,asyncio=asyncio,STORAGE_DIR=root,Cancelled=Cancelled,_save_piece=save,_split_into_chunks=lambda text,max_chars:text.split('|'),t=lambda *args,**kwargs:'progress')
  exec(compile(ast.Module(body=[node],type_ignores=[]),'engine.py','exec'),scope)
  generate=scope['_edge_generate']
  async def job(i):
   out=root/f'{i}.mp3'
   await generate(f'{i}a|{i}b|{i}c','voice','rate',str(out))
   assert out.read_text()==f'{i}a{i}b{i}c'
  stop=False
  async def cancel_job():
   nonlocal stop
   task=asyncio.create_task(generate('cancel-a|cancel-b','voice','rate',str(root/'cancel.mp3'),should_stop=lambda:stop))
   await asyncio.sleep(0.01);stop=True
   try:await task
   except Cancelled:pass
   else:raise AssertionError('Cancellation did not interrupt synthesis')
  await asyncio.gather(*(job(i) for i in range(8)),cancel_job())
  assert not list(root.glob('.talking-tom-parts-*'))
  assert not (root/'cancel.mp3').exists()
  print('PASS: actual engine assembles eight concurrent multi-chunk recordings; cancelling a ninth cannot delete another job’s chunks; all temporary directories cleaned')
asyncio.run(main())
