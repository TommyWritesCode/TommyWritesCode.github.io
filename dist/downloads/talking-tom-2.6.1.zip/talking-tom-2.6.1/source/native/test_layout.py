"""Render the actual SwiftUI workspace in an offscreen AppKit test window."""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parent
source=(root/'Main.swift').read_text().split('@main struct TalkingTomApp')[0]
source+='''
@main struct LayoutTests {
 @MainActor static func main() async {
  _ = NSApplication.shared
  let folder = URL(fileURLWithPath:CommandLine.arguments[1])
  let output = URL(fileURLWithPath:CommandLine.arguments[2])
  let session = AppSession(stateDirectory:folder,installMedia:false)
  session.active.loadingDraft = true
  session.active.title = "Reading workspace"
  session.active.text = String(repeating:"A responsive workspace keeps editing, playback and navigation independent. Each tab preserves its text and playback position.\\n\\n",count:100)
  let model = session.active
  session.newTab(); session.active.title = "Another article"; session.select(model.id)
  let window = NSWindow(contentRect:NSRect(x:0,y:0,width:1060,height:800),styleMask:[.titled,.resizable],backing:.buffered,defer:false)
  let host = NSHostingView(rootView:TabbedWorkspace(session:session))
  window.contentView = host
  window.appearance = NSAppearance(named:.darkAqua)
  for (name,width,height,zoom) in [("workspace",1060.0,800.0,1.0),("zoomed",1060.0,800.0,1.5),("narrow-tall",360.0,850.0,1.0)] {
   model.zoom = zoom
   window.setContentSize(NSSize(width:width,height:height))
   try! await Task.sleep(for:.milliseconds(150))
   host.layoutSubtreeIfNeeded()
   guard let bitmap = host.bitmapImageRepForCachingDisplay(in:host.bounds) else { fatalError("No bitmap") }
   host.cacheDisplay(in:host.bounds,to:bitmap)
   try! bitmap.representation(using:.png,properties:[:])!.write(to:output.appendingPathComponent(name+".png"))
  }
  precondition(model.nativeEditor != nil)
  precondition(!session.isMini)
  precondition(model.nativeEditor!.scrollView.visibleRect.height > 350, "Narrow tall window is wasting document space")
  let regularFrame = window.frame
  session.toggleMini()
  try! await Task.sleep(for:.milliseconds(200))
  host.layoutSubtreeIfNeeded()
  precondition(session.isMini)
  precondition(abs(window.contentLayoutRect.height - AppSession.miniContentHeight) < 2, "Mini player is not tightly fitted")
  guard let miniBitmap = host.bitmapImageRepForCachingDisplay(in:host.bounds) else { fatalError("No mini bitmap") }
  host.cacheDisplay(in:host.bounds,to:miniBitmap)
  try! miniBitmap.representation(using:.png,properties:[:])!.write(to:output.appendingPathComponent("compact.png"))
  session.newTab()
  precondition(session.isMini && session.active.mini, "Switching tabs left mini mode")
  session.select(model.id)
  session.toggleMini()
  try! await Task.sleep(for:.milliseconds(200))
  host.layoutSubtreeIfNeeded()
  precondition(!session.isMini && window.frame == regularFrame, "Restore lost the previous window size")
  let editor = model.nativeEditor!
  model.zoom = 1
  window.setContentSize(NSSize(width:1060,height:800))
  session.newTab(); session.active.loadingDraft = true; session.active.text = "Second document"
  try! await Task.sleep(for:.milliseconds(150))
  host.layoutSubtreeIfNeeded()
  session.select(model.id)
  try! await Task.sleep(for:.milliseconds(150))
  host.layoutSubtreeIfNeeded()
  precondition(model.nativeEditor === editor)
  session.tabs.forEach { $0.wordCountTask?.cancel(); $0.draftWork?.cancel() }
  session.sessionWork?.cancel()
  print("PASS: regular/zoom/narrow-tall/mini renders; narrow document uses vertical space; mini fits 110-point content height; tabs preserve mini mode; exact previous window frame restored; native editor reused")
 }
}
'''
with tempfile.TemporaryDirectory(prefix='tom-layout-') as folder:
 p=Path(folder);(p/'Layout.swift').write_text(source)
 subprocess.run(['swiftc','-O','-parse-as-library',str(p/'Layout.swift'),'-o',str(p/'Layout'),'-module-cache-path','/private/tmp/talking-tom-module-cache'],check=True)
 subprocess.run([str(p/'Layout'),folder,str(root/'verification')],check=True)
