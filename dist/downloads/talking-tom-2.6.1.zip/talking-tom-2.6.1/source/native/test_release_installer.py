"""Exercise the real installer with isolated files and offline command stand-ins."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


class InstallerTests(unittest.TestCase):
    def run_install(self, failure="", existing=True, architecture="arm64", macos="26.0"):
        temp = tempfile.TemporaryDirectory(prefix="talking-tom-setup-")
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        private = root / "profile"
        private.mkdir()
        release = root / "release"
        release.mkdir()
        commands = root / "commands"
        commands.mkdir()
        script = Path(__file__).with_name("release-installer") / "setup.command"
        # Redirect the installer's path reads; never override the process HOME.
        (release / "setup.command").write_text(script.read_text().replace("$HOME", "$TOM_TEST_ROOT"))
        (release / "requirements.txt").write_text("edge-tts==7.3.0\n")
        (release / "Talking Tom.app/Contents").mkdir(parents=True)
        (release / "Talking Tom.app/Contents/version").write_text("new")
        state = private / ".talking_tom"
        state.mkdir()
        (state / "config.json").write_text("private-test-settings")
        (state / "drafts").mkdir()
        (state / "drafts/keep").write_text("draft")
        (private / "Talking Tom").mkdir()
        (private / "Talking Tom/keep.mp3").write_bytes(b"saved-audio")
        app = private / "Applications/Talking Tom.app"
        if existing:
            (app / "Contents").mkdir(parents=True)
            (app / "Contents/version").write_text("old")
            (state / "venv").mkdir()
            (state / "venv/version").write_text("old-runtime")
        stubs = {
            "uname": '#!/bin/sh\nif [ "$1" = -m ]; then echo "$TOM_TEST_ARCH"; else echo Darwin; fi\n',
            "sw_vers": '#!/bin/sh\necho "$TOM_TEST_MACOS"\n',
            "pgrep": '#!/bin/sh\nexit 1\n',
            "open": '#!/bin/sh\nexit 0\n',
            "codesign": '''#!/bin/sh
for target in "$@"; do :; done
if [ "$TOM_TEST_FAIL" = app ] && [ "$target" = "$TOM_TEST_ROOT/Applications/Talking Tom.app" ]; then exit 45; fi
exit 0
''',
            "uv": '''#!/bin/bash
set -eu
if [ "$1" = python ]; then exit 0; fi
if [ "$1" = pip ]; then
  if [ "$TOM_TEST_FAIL" = pip ]; then exit 44; fi
  exit 0
fi
for target in "$@"; do :; done
mkdir -p "$target/bin"
echo new-runtime > "$target/version"
printf '#!/bin/sh\ncat >/dev/null\nexit 0\n' > "$target/bin/python"
chmod +x "$target/bin/python"
''',
            "ditto": f'#!{sys.executable}\nimport shutil,sys\nshutil.copytree(sys.argv[1],sys.argv[2],dirs_exist_ok=True)\n',
        }
        for name, content in stubs.items():
            p = commands / name
            p.write_text(content)
            p.chmod(0o755)
        env = dict(os.environ, PATH=str(commands) + ":" + os.environ["PATH"],
                   TOM_TEST_ROOT=str(private), TOM_TEST_FAIL=failure, TOM_TEST_ARCH=architecture,
                   TOM_TEST_MACOS=macos)
        result = subprocess.run(["/bin/bash", str(release / "setup.command")],
                                env=env, capture_output=True, text=True, timeout=15)
        self.assertEqual((state / "config.json").read_text(), "private-test-settings")
        self.assertEqual((state / "drafts/keep").read_text(), "draft")
        self.assertEqual((private / "Talking Tom/keep.mp3").read_bytes(), b"saved-audio")
        return result, private, app, state

    def test_upgrade_keeps_data_and_backs_up_old_app_and_runtime(self):
        result, private, app, state = self.run_install()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual((app / "Contents/version").read_text(), "new")
        self.assertEqual((state / "venv/version").read_text().strip(), "new-runtime")
        backup = next((state / "backups").iterdir())
        self.assertEqual((backup / "Talking Tom.app/Contents/version").read_text(), "old")
        self.assertEqual((backup / "venv/version").read_text(), "old-runtime")

    def test_dependency_failure_restores_old_runtime_and_leaves_app(self):
        result, private, app, state = self.run_install("pip")
        self.assertEqual(result.returncode, 44, result.stderr)
        self.assertEqual((app / "Contents/version").read_text(), "old")
        self.assertEqual((state / "venv/version").read_text(), "old-runtime")

    def test_app_failure_restores_both_app_and_runtime(self):
        result, private, app, state = self.run_install("app")
        self.assertEqual(result.returncode, 45, result.stderr)
        self.assertEqual((app / "Contents/version").read_text(), "old")
        self.assertEqual((state / "venv/version").read_text(), "old-runtime")

    def test_fresh_install_needs_no_prior_app_or_runtime(self):
        result, private, app, state = self.run_install(existing=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual((app / "Contents/version").read_text(), "new")

    def test_failed_fresh_install_removes_incomplete_app_and_runtime(self):
        result, private, app, state = self.run_install("app", existing=False)
        self.assertEqual(result.returncode, 45, result.stderr)
        self.assertFalse(app.exists())
        self.assertFalse((state / "venv").exists())

    def test_unsupported_architecture_does_not_change_existing_install(self):
        result, private, app, state = self.run_install(architecture="x86_64")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Apple Silicon", result.stderr)
        self.assertEqual((app / "Contents/version").read_text(), "old")
        self.assertEqual((state / "venv/version").read_text(), "old-runtime")

    def test_older_macos_does_not_change_existing_install(self):
        result, private, app, state = self.run_install(macos="14.7")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("macOS 26", result.stderr)
        self.assertEqual((app / "Contents/version").read_text(), "old")
        self.assertEqual((state / "venv/version").read_text(), "old-runtime")


if __name__ == "__main__":
    unittest.main()
