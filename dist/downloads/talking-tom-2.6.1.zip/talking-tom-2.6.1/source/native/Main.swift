import SwiftUI
import AppKit
import AVFoundation
import UniformTypeIdentifiers
import MediaPlayer
import Observation

// Semantic brand accents keep readable contrast in both system appearances.
enum TomPalette {
    static let blue = Color(nsColor: .systemBlue)
    static let yellow = Color(nsColor: .systemYellow)
    static let ink = Color(nsColor: NSColor(name: nil) { appearance in
        appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
            ? NSColor(calibratedRed: 0.75, green: 0.85, blue: 1, alpha: 1)
            : NSColor(calibratedRed: 0.10, green: 0.23, blue: 0.43, alpha: 1)
    })
}

let home = FileManager.default.homeDirectoryForCurrentUser
let configURL = home.appendingPathComponent(".talking_tom/config.json")
let libraryURL = home.appendingPathComponent("Talking Tom", isDirectory: true)
let voices = ["Jenny (US Female)", "Aria (US Female)", "Michelle (US Female)", "Guy (US Male)", "Christopher (US Male)", "Eric (US Male)", "Sonia (UK Female)", "Ryan (UK Male)", "Elvira (España, F)", "Álvaro (España, M)", "Dalia (México, F)", "Jorge (México, M)", "Elena (Argentina, F)", "Gonzalo (Colombia, M)"]
let generationRates = ["0.9x", "1.0x", "1.1x", "1.25x", "1.5x", "1.75x", "2.0x"]

struct Recording: Identifiable, Equatable, Sendable { let url: URL; let date: Date; var id: String { url.path }; var title: String { url.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "_", with: " ") } }

// Recurring persistence and directory enumeration must never block event handling.
enum FileWork {
    static let queue = DispatchQueue(label:"com.tommynicol.talking-tom.persistence",qos:.utility)
    static func writeJSON(_ value: Any, to url: URL) {
        do {
            try FileManager.default.createDirectory(at:url.deletingLastPathComponent(),withIntermediateDirectories:true)
            try JSONSerialization.data(withJSONObject:value).write(to:url,options:.atomic)
            try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:url.path)
        } catch { NSLog("Talking Tom could not save %@: %@",url.lastPathComponent,error.localizedDescription) }
    }
}

@MainActor enum AppAssets {
    static let icon = Bundle.main.resourceURL.flatMap { NSImage(contentsOf:$0.appendingPathComponent("icon.icns")) }
}

@MainActor @Observable final class RecordingLibrary {
    static let shared = RecordingLibrary()
    private(set) var recordings: [Recording] = []
    @ObservationIgnored private var scanning = false
    @ObservationIgnored private var rescanRequested = false
    init() { refresh() }
    func refresh() {
        guard !scanning else { rescanRequested = true; return }
        scanning = true
        DispatchQueue.global(qos:.utility).async { [weak self] in
            let files = (try? FileManager.default.contentsOfDirectory(at:libraryURL,includingPropertiesForKeys:[.contentModificationDateKey],options:.skipsHiddenFiles)) ?? []
            let recordings = files.filter { ["mp3","wav","m4a","aiff"].contains($0.pathExtension.lowercased()) }
                .map { Recording(url:$0,date:(try? $0.resourceValues(forKeys:[.contentModificationDateKey]).contentModificationDate) ?? .distantPast) }
                .sorted { $0.date > $1.date }
            DispatchQueue.main.async {
                guard let self else { return }
                if self.recordings != recordings { self.recordings = recordings }
                self.scanning = false
                if self.rescanRequested { self.rescanRequested = false; self.refresh() }
            }
        }
    }
}

// Preserve the current line layout during a live window drag. Reflow once when
// it ends, rather than re-typesetting a long paragraph for every pointer event.
@MainActor final class EditorScrollView: NSScrollView {
    override func viewWillStartLiveResize() {
        super.viewWillStartLiveResize()
        (documentView as? NSTextView)?.textContainer?.widthTracksTextView = false
    }
    override func viewDidEndLiveResize() {
        super.viewDidEndLiveResize()
        guard let textView = documentView as? NSTextView else { return }
        textView.textContainer?.widthTracksTextView = true
        textView.setFrameSize(NSSize(width:contentSize.width,height:textView.frame.height))
        textView.needsLayout = true; textView.needsDisplay = true
    }
}

// Keep native text storage, layout, selection, scroll position, and undo per tab.
// Only the visible editor is attached to the view hierarchy.
@MainActor final class NativeEditor: NSObject, NSTextViewDelegate {
    weak var model: Model?
    let scrollView = EditorScrollView()
    let textView = NSTextView(usingTextLayoutManager:true)
    var appliedRevision = -1
    init(model: Model) {
        self.model = model
        super.init()
        textView.isRichText = false; textView.allowsUndo = true
        textView.isAutomaticQuoteSubstitutionEnabled = false
        textView.isAutomaticDashSubstitutionEnabled = false
        textView.isAutomaticTextReplacementEnabled = false
        textView.font = .systemFont(ofSize:15)
        textView.textColor = .textColor; textView.backgroundColor = .textBackgroundColor
        textView.isVerticallyResizable = true; textView.isHorizontallyResizable = false
        textView.minSize = .zero
        textView.maxSize = NSSize(width:CGFloat.greatestFiniteMagnitude,height:CGFloat.greatestFiniteMagnitude)
        textView.autoresizingMask = [.width]
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width:0,height:CGFloat.greatestFiniteMagnitude)
        textView.textContainerInset = NSSize(width:4,height:0)
        let paragraph = NSMutableParagraphStyle(); paragraph.lineSpacing = 6
        textView.defaultParagraphStyle = paragraph
        textView.delegate = self
        scrollView.hasVerticalScroller = true; scrollView.autohidesScrollers = true
        scrollView.drawsBackground = false; scrollView.documentView = textView
        apply(model)
    }
    func apply(_ model: Model) {
        if appliedRevision != model.textRevision {
            let selection = textView.selectedRange()
            textView.string = model.text
            textView.setSelectedRange(NSRange(location:min(selection.location,textView.string.utf16.count),length:0))
            textView.undoManager?.removeAllActions()
            appliedRevision = model.textRevision
        }
        if textView.isEditable == model.busy { textView.isEditable = !model.busy }
        let label = model.tr("Document text","Texto del documento")
        if textView.accessibilityLabel() != label { textView.setAccessibilityLabel(label) }
    }
    func textDidChange(_ notification: Notification) {
        guard let model else { return }
        model.text = textView.string
        appliedRevision = model.textRevision
    }
}

struct DocumentEditor: View {
    @Bindable var m: Model
    var body: some View { EditorHost(model:m,revision:m.textRevision,busy:m.busy,language:m.language) }
}

struct EditorHost: NSViewRepresentable {
    let model: Model
    let revision: Int
    let busy: Bool
    let language: String
    func makeNSView(context: Context) -> NSView { NSView() }
    func updateNSView(_ container: NSView, context: Context) {
        let editor: NativeEditor
        if let cached = model.nativeEditor { editor = cached }
        else { editor = NativeEditor(model:model); model.nativeEditor = editor }
        if editor.scrollView.superview !== container {
            container.subviews.forEach { $0.removeFromSuperview() }
            editor.scrollView.removeFromSuperview()
            editor.scrollView.frame = container.bounds
            editor.scrollView.autoresizingMask = [.width,.height]
            container.addSubview(editor.scrollView)
        }
        editor.apply(model)
    }
}

@MainActor @Observable final class Model: NSObject, AVAudioPlayerDelegate {
    let id: UUID
    var zoom: Double = 1
    @ObservationIgnored weak var session: AppSession?
    var text = "" { didSet { textRevision &+= 1; isTextEmpty = text.isEmpty; updateWordCount(); saveDraft() } }
    private(set) var textRevision = 0
    private(set) var isTextEmpty = true
    private(set) var words = 0
    @ObservationIgnored var wordCountTask: Task<Void,Never>?
    @ObservationIgnored var nativeEditor: NativeEditor?
    var title = "" { didSet { saveDraft() } }
    var voice = voices[0]
    var generationRate = "1.0x"
    var cleaning = "builtin"
    var readin = "auto"
    var aiModel = "auto"
    var translateVisuals = false
    var sourcePDF = ""
    var visualsPrepared = false
    var language = "en"
    var apiKey = ""
    let library = RecordingLibrary.shared
    var recordings: [Recording] { library.recordings }
    var selected: String?
    var search = ""
    var busy = false
    var status = ""
    var error: String?
    var notice: String?
    var showAIConsent = false
    var pendingOperation = "generate"
    var playing = false
    var position: Double = 0
    var duration: Double = 0
    var playbackRate: Float = 1 { didSet { player?.rate = playbackRate; session?.updateNowPlaying(self) } }
    var audioURL: URL?
    private(set) var audioLoading = false
    @ObservationIgnored private var audioLoadGeneration = 0
    @ObservationIgnored private var pendingAudioURL: URL?
    var mini: Bool { session?.isMini == true }
    var inspector = true
    var showOptions = false
    @ObservationIgnored var atEnd = false
    @ObservationIgnored var scrubbing = false
    @ObservationIgnored var player: AVAudioPlayer?
    @ObservationIgnored var terminationRequested = false
    @ObservationIgnored var process: Process?
    @ObservationIgnored var timer: Timer?
    @ObservationIgnored var loadingDraft = true
    @ObservationIgnored var draftWork: DispatchWorkItem?
    let draftURL: URL
    var estimatedMinutes: Int { max(1,Int(ceil(Double(words) / (160 * (Double(generationRate.dropLast()) ?? 1)))) ) }
    var filtered: [Recording] { recordings.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) } }
    func tr(_ en: String, _ es: String) -> String { language == "es" ? es : en }
    init(id: UUID = UUID(), draftURL: URL = home.appendingPathComponent(".talking_tom/native-draft.json"), restore: Bool = true) {
        self.id = id; self.draftURL = draftURL
        super.init()
        if restore, let data = try? Data(contentsOf: configURL), let c = try? JSONSerialization.jsonObject(with: data) as? [String:Any] {
            language = c["lang"] as? String ?? "en"; apiKey = c["anthropic_api_key"] as? String ?? ""
            voice = c["voice"] as? String ?? voices[0]; if !voices.contains(voice) { voice = voices[0] }
            generationRate = c["rate"] as? String ?? "1.0x"; if !generationRates.contains(generationRate) { generationRate = "1.0x" }
            cleaning = c["clean_mode"] as? String ?? "builtin"; if !["builtin","ai","none"].contains(cleaning) { cleaning = "builtin" }
            readin = c["readin"] as? String ?? "auto"; aiModel = c["model_selection"] as? String ?? "auto"
            if ["claude-haiku-4-5", "claude-haiku-4-5-20251001"].contains(aiModel) { aiModel = "claude-haiku-5-5" }
            translateVisuals = c["translate_visuals"] as? Bool ?? false
        }
        if restore, let data = try? Data(contentsOf: draftURL), let d = try? JSONSerialization.jsonObject(with: data) as? [String:String] { text = d["text"] ?? ""; title = d["title"] ?? ""; sourcePDF = d["source_pdf"] ?? ""; visualsPrepared = d["visuals_prepared"] == "true" }
        loadingDraft = false
    }
    func updateWordCount() {
        wordCountTask?.cancel()
        let snapshot = text
        if snapshot.isEmpty { words = 0; return }
        wordCountTask = Task { [weak self] in
            do { try await Task.sleep(for:.milliseconds(150)) } catch { return }
            let count = await Task.detached(priority:.utility) {
                // Count boundaries without allocating an array of every word.
                var count = 0, inWord = false
                for character in snapshot {
                    if character.isWhitespace { inWord = false }
                    else if !inWord { count += 1; inWord = true }
                }
                return count
            }.value
            guard !Task.isCancelled else { return }
            self?.words = count
        }
    }
    func startPlaybackClock() {
        timer?.invalidate()
        let clock = Timer(timeInterval:0.1,repeats:true) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self, self.playing, !self.scrubbing, let player = self.player else { return }
                self.position = player.currentTime
            }
        }
        clock.tolerance = 0.02
        RunLoop.main.add(clock,forMode:.common)
        timer = clock
    }
    func stopPlaybackClock() { timer?.invalidate(); timer = nil }
    func flushDraft() {
        draftWork?.cancel()
        let snapshot = ["text":text,"title":title,"source_pdf":sourcePDF,"visuals_prepared":visualsPrepared ? "true" : "false"], url = draftURL
        FileWork.queue.sync { FileWork.writeJSON(snapshot,to:url) }
    }
    func changeZoom(_ delta: Double) { zoom = min(2, max(0.75, (zoom + delta).roundedToHundredth)) }
    func saveDraft() {
        guard !loadingDraft else { return }
        draftWork?.cancel()
        let snapshot = ["text":text,"title":title,"source_pdf":sourcePDF,"visuals_prepared":visualsPrepared ? "true" : "false"], url = draftURL
        let work = DispatchWorkItem { FileWork.writeJSON(snapshot,to:url) }
        draftWork = work
        FileWork.queue.asyncAfter(deadline:.now()+0.5,execute:work)
    }
    func persist(completion: (@MainActor () -> Void)? = nil) {
        let snapshot: [String:Any] = ["lang":language,"voice":voice,"rate":generationRate,"clean_mode":cleaning,"readin":readin,"model":aiModel == "auto" ? "claude-haiku-5-5" : aiModel,"model_selection":aiModel,"translate_visuals":translateVisuals,"anthropic_api_key":apiKey]
        FileWork.queue.async { [weak self] in
            var settings = (try? Data(contentsOf:configURL)).flatMap { try? JSONSerialization.jsonObject(with:$0) as? [String:Any] } ?? [:]
            settings.merge(snapshot) { _,new in new }
            do {
                try FileManager.default.createDirectory(at:configURL.deletingLastPathComponent(),withIntermediateDirectories:true)
                try JSONSerialization.data(withJSONObject:settings,options:.prettyPrinted).write(to:configURL,options:.atomic)
                try FileManager.default.setAttributes([.posixPermissions:0o600],ofItemAtPath:configURL.path)
                DispatchQueue.main.async { completion?() }
            } catch {
                let message = error.localizedDescription
                DispatchQueue.main.async { self?.error = message }
            }
        }
    }
    func refresh() { library.refresh() }
    func openDocument() {
        let p = NSOpenPanel(); p.allowedContentTypes = [.pdf,.plainText,.mp3,.wav,.mpeg4Audio,UTType(filenameExtension:"docx")!]; p.canChooseDirectories = false
        p.begin { [weak self] result in if result == .OK, let url = p.url { Task { @MainActor in self?.open(url) } } }
    }
    func open(_ url:URL) {
        if ["mp3","wav","m4a","aiff"].contains(url.pathExtension.lowercased()) { loadAudio(url); return }
        guard !busy else { return }
        if !text.isEmpty {
            let a = NSAlert(); a.messageText = tr("Replace the current text?","¿Reemplazar el texto actual?"); a.informativeText = tr("Your recordings will stay in the library.","Tus grabaciones se conservarán en la biblioteca."); a.addButton(withTitle:tr("Replace","Reemplazar")); a.addButton(withTitle:tr("Cancel","Cancelar"))
            guard a.runModal() == .alertFirstButtonReturn else { return }
        }
        title = url.deletingPathExtension().lastPathComponent
        run(["operation":"extract","path":url.path,"lang":language])
    }
    func newDocument() {
        if !text.isEmpty {
            let a = NSAlert(); a.messageText = tr("Start a new document?","¿Crear un documento nuevo?"); a.informativeText = tr("This clears the editor. Saved recordings are kept.","Se vacía el editor. Las grabaciones se conservan."); a.addButton(withTitle:tr("New Document","Nuevo documento")); a.addButton(withTitle:tr("Cancel","Cancelar"))
            guard a.runModal() == .alertFirstButtonReturn else { return }
        }
        sourcePDF = ""; visualsPrepared = false; title = ""; text = ""
    }
    func request(_ op:String) {
        guard !busy, !isTextEmpty else { return }
        pendingOperation = op
        if cleaning == "ai" || readin != "auto" || op == "translate" || translateVisuals { showAIConsent = true } else { perform(op) }
    }
    func perform(_ op:String) {
        let request: [String:Any] = ["operation":op,"text":text,"title":title,"voice":voice,"rate":generationRate,"clean":cleaning,"readin":readin,"model":aiModel,"lang":language,"translate_visuals":translateVisuals,"source_pdf":sourcePDF,"visuals_prepared":visualsPrepared]
        persist { [weak self] in self?.run(request) }
    }
    func run(_ request:[String:Any]) {
        guard !busy else { return }
        busy = true; status = tr("Preparing…","Preparando…")
        let p = Process(), input = Pipe(), output = Pipe(), errors = Pipe()
        p.executableURL = home.appendingPathComponent(".talking_tom/venv/bin/python")
        p.arguments = [Bundle.main.resourceURL!.appendingPathComponent("worker.py").path]
        p.standardInput = input; p.standardOutput = output; p.standardError = errors
        process = p
        let op = request["operation"] as? String ?? ""
        do {
            try p.run()
        } catch { busy = false; self.error = error.localizedDescription; process = nil; return }
        // The worker may take time to import dependencies before reading its pipe.
        // Large request serialization and pipe backpressure must not block the UI.
        DispatchQueue.global(qos:.userInitiated).async { [weak self] in
            defer { try? input.fileHandleForWriting.close() }
            do {
                let payload = try JSONSerialization.data(withJSONObject:request)
                try input.fileHandleForWriting.write(contentsOf:payload + Data([10]))
            } catch {
                let message = error.localizedDescription
                DispatchQueue.main.async { self?.error = message }
                if p.isRunning { p.terminate() }
            }
        }
        // Drain stderr concurrently; it can include library diagnostics, never expose credentials.
        DispatchQueue.global(qos:.utility).async { _ = errors.fileHandleForReading.readDataToEndOfFile() }
        DispatchQueue.global(qos:.userInitiated).async { [weak self] in
            var buffer = Data(), hadTerminal = false
            while true {
                let chunk = output.fileHandleForReading.availableData
                if chunk.isEmpty { break }; buffer.append(chunk)
                while let lineEnd = buffer.firstIndex(of:10) {
                    let line = buffer.subdata(in:0..<lineEnd); buffer.removeSubrange(0...lineEnd)
                    guard let message = try? JSONSerialization.jsonObject(with:line) as? [String:Any] else { continue }
                    if ["result","error","cancelled"].contains(message["type"] as? String ?? "") { hadTerminal = true }
                    DispatchQueue.main.async { self?.receive(message,operation:op) }
                }
            }
            p.waitUntilExit()
            let finished = hadTerminal
            DispatchQueue.main.async {
                guard let self else { return }
                self.busy = false; self.process = nil
                self.session?.workerFinished()
                if !finished { self.error = self.tr("The narration engine stopped unexpectedly. Please try again.","El motor se detuvo. Inténtalo de nuevo."); self.status = "" }
            }
        }
    }
    func receive(_ message:[String:Any],operation:String) {
        switch message["type"] as? String {
        case "progress": status = message["message"] as? String ?? ""
        case "error": error = message["message"] as? String ?? "Unknown error"; status = ""
        case "cancelled": status = tr("Cancelled","Cancelado")
        case "result":
            if let source = message["source_pdf"] as? String { sourcePDF = source }
            if let prepared = message["visuals_prepared"] as? Bool { visualsPrepared = prepared }
            if let t = message["text"] as? String { text = t }
            if let l = message["language"] as? String, ["en","es"].contains(l) { readin = l }
            if let path = message["path"] as? String { refresh(); loadAudio(URL(fileURLWithPath:path)); status = tr("Recording ready","Grabación lista") }
            else { status = operation == "extract" ? tr("Document imported","Documento importado") : tr("Text updated","Texto actualizado") }
            if let skipped = message["skipped"] as? Int, skipped > 0 { notice = tr("\(skipped) pages had no extractable text. Scanned PDFs need OCR before importing.","\(skipped) páginas no tienen texto extraíble. Los PDF escaneados necesitan OCR.") }
        default: break
        }
    }
    func cancel() { process?.terminate(); status = tr("Cancelling…","Cancelando…") }
    func loadAudio(_ url:URL) {
        guard !(audioLoading && pendingAudioURL == url) else { return }
        audioLoadGeneration &+= 1
        let generation = audioLoadGeneration
        pausePlayback()
        audioLoading = true; pendingAudioURL = url; selected = url.path
        // File opening and decoder preparation can stall on long recordings or external drives.
        DispatchQueue.global(qos:.userInitiated).async { [weak self] in
            do {
                let prepared = try AVAudioPlayer(contentsOf:url)
                prepared.enableRate = true; prepared.prepareToPlay()
                DispatchQueue.main.async {
                    guard let self, self.audioLoadGeneration == generation else { return }
                    self.audioLoading = false; self.pendingAudioURL = nil
                    self.player?.stop(); self.player = prepared
                    prepared.delegate = self; prepared.rate = self.playbackRate
                    self.audioURL = url; self.duration = prepared.duration; self.position = 0
                    self.playing = false; self.atEnd = false
                    self.session?.audioLoaded(self)
                }
            } catch {
                let message = error.localizedDescription
                DispatchQueue.main.async {
                    guard let self, self.audioLoadGeneration == generation else { return }
                    self.audioLoading = false; self.pendingAudioURL = nil
                    self.selected = self.audioURL?.path; self.error = message
                }
            }
        }
    }
    func cancelAudioLoad() { audioLoadGeneration &+= 1; audioLoading = false; pendingAudioURL = nil }
    func togglePlayback() {
        guard !audioLoading, let p = player else { return }
        if p.isPlaying { pausePlayback() }
        else {
            session?.claimPlayback(self)
            if atEnd || position >= duration - 0.05 { p.stop(); p.currentTime = 0; p.prepareToPlay(); position = 0; atEnd = false }
            p.enableRate = true; p.rate = playbackRate
            playing = p.play()
            if playing { startPlaybackClock() }
            session?.updateNowPlaying(self)
            if !playing { error = tr("This recording could not be played.","No se pudo reproducir esta grabación.") }
        }
    }
    func pausePlayback() {
        stopPlaybackClock()
        player?.pause(); position = player?.currentTime ?? position; playing = false
        session?.updateNowPlaying(self)
    }
    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Task { @MainActor in
            guard self.player === player else { return }
            self.stopPlaybackClock()
            self.playing = false; self.position = self.duration; self.atEnd = true
            self.session?.updateNowPlaying(self)
        }
    }
    func seek(_ value:Double) {
        let v = min(max(0,value),duration)
        if atEnd { player?.stop(); player?.prepareToPlay(); atEnd = false }
        player?.currentTime = v; position = v; session?.updateNowPlaying(self)
    }
    func skip(_ seconds:Double) { seek(position + seconds * Double(playbackRate)) }
    func export() {
        guard let url = audioURL else { return }; let p = NSSavePanel(); p.nameFieldStringValue = url.lastPathComponent; p.allowedContentTypes = [UTType(filenameExtension:url.pathExtension) ?? .audio]
        p.begin { [weak self] result in
            guard result == .OK, let destination = p.url, destination != url else { return }
            FileWork.queue.async {
                do {
                    if FileManager.default.fileExists(atPath:destination.path) { try FileManager.default.removeItem(at:destination) }
                    try FileManager.default.copyItem(at:url,to:destination)
                } catch {
                    let message = error.localizedDescription
                    DispatchQueue.main.async { self?.error = message }
                }
            }
        }
    }
    func toggleMini() { session?.toggleMini() }
    func transcript(_ recording:Recording) {
        let url = recording.url.deletingPathExtension().appendingPathExtension("txt")
        if FileManager.default.fileExists(atPath:url.path) { open(url) }
    }
}

struct PlaybackTimeline: View {
    @Bindable var m: Model
    func clock(_ seconds:Double) -> String { let n = max(0,Int(seconds)); return n >= 3600 ? String(format:"%d:%02d:%02d",n/3600,(n%3600)/60,n%60) : String(format:"%d:%02d",n/60,n%60) }
    var body: some View {
            HStack(spacing:10) {
                Text(clock(m.position / Double(m.playbackRate))).monospacedDigit().frame(minWidth:36,alignment:.trailing)
                Slider(value:Binding(get:{m.position},set:{ if m.scrubbing { m.position = $0 } else { m.seek($0) } }),in:0...max(1,m.duration),onEditingChanged: { editing in m.scrubbing = editing; if !editing { m.seek(m.position) } }).disabled(m.audioURL == nil || m.audioLoading).accessibilityLabel(m.tr("Playback position","Posición"))
                Text("−" + clock((m.duration - m.position) / Double(m.playbackRate))).monospacedDigit().frame(minWidth:40,alignment:.leading)
            }.font(.caption).foregroundStyle(.secondary)
    }
}

struct MiniPlaybackView: View {
    @Bindable var m: Model
    var body: some View {
        VStack(spacing:4) {
            HStack(spacing:14) {
                Menu {
                    ForEach([Float(0.5),0.75,1,1.25,1.5,1.75,2],id:\.self) { rate in
                        Button(String(format:"%gx",rate)) { m.playbackRate = rate }
                    }
                } label: { Text(String(format:"%gx",m.playbackRate)).font(.caption.weight(.semibold)).frame(width:34) }
                    .menuStyle(.borderlessButton).fixedSize().help("Playback speed")
                Spacer(minLength:0)
                Group {
                    Button { m.skip(-15) } label: { Image(systemName:"gobackward.15").font(.system(size:19)) }.help("Back 15 seconds")
                    Button { m.togglePlayback() } label: {
                        Image(systemName:m.playing ? "pause.fill" : "play.fill")
                            .font(.system(size:14,weight:.semibold)).foregroundStyle(.white)
                            .frame(width:30,height:30).background(TomPalette.blue,in:Circle())
                    }.help(m.playing ? "Pause" : "Play")
                    Button { m.skip(15) } label: { Image(systemName:"goforward.15").font(.system(size:19)) }.help("Forward 15 seconds")
                }.disabled(m.audioURL == nil || m.audioLoading)
                Spacer(minLength:0)
                Button { m.toggleMini() } label: { Image(systemName:"arrow.up.left.and.arrow.down.right").frame(width:24,height:24) }
                    .help(m.tr("Restore Workspace (⇧⌘M)","Restaurar ventana (⇧⌘M)"))
                    .accessibilityLabel("Restore Workspace")
            }.buttonStyle(.plain)
            PlaybackTimeline(m:m)
        }.padding(.horizontal,12).padding(.vertical,8)
            .frame(height:76).background(.bar)
    }
}

struct PlayerView: View {
    @Bindable var m:Model
    var compact = false
    func clock(_ seconds:Double) -> String { let n = max(0,Int(seconds)); return n >= 3600 ? String(format:"%d:%02d:%02d",n/3600,(n%3600)/60,n%60) : String(format:"%d:%02d",n/60,n%60) }
    var body: some View {
        VStack(spacing:compact ? 10 : 8) {
            HStack(spacing:10) {
                Image(systemName:"waveform").font(.system(size:16,weight:.semibold)).foregroundStyle(TomPalette.ink).frame(width:34,height:34).background(TomPalette.yellow.opacity(0.35),in:RoundedRectangle(cornerRadius:9))
                VStack(alignment:.leading,spacing:3) {
                    Text(m.audioURL?.deletingPathExtension().lastPathComponent.replacingOccurrences(of:"_",with:" ") ?? m.tr("Ready when you are","Listo cuando quieras")).font(.system(size:13,weight:.semibold)).lineLimit(1)
                    Text(m.audioLoading ? m.tr("Loading recording…","Cargando grabación…") : m.audioURL == nil ? m.tr("Create a recording or choose one from your library","Crea una grabación o elige una de tu biblioteca") : (m.playing ? m.tr("Playing","Reproduciendo") : m.tr("Paused","En pausa"))).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength:4)
                Button { m.toggleMini() } label: { Image(systemName:compact ? "arrow.up.left.and.arrow.down.right" : "arrow.down.right.and.arrow.up.left") }.buttonStyle(.borderless).help(compact ? m.tr("Full workspace","Ventana completa") : m.tr("Mini Player","Minirreproductor")).accessibilityLabel(compact ? "Full workspace" : "Mini Player")
            }
            PlaybackTimeline(m:m)
            HStack(spacing:22) {
                Menu {
                    ForEach([Float(0.5),0.75,1,1.25,1.5,1.75,2],id:\.self) { rate in
                        Button { m.playbackRate = rate } label: { if rate == m.playbackRate { Label(String(format:"%gx",rate),systemImage:"checkmark") } else { Text(String(format:"%gx",rate)) } }
                    }
                } label: { Text(String(format:"%gx",m.playbackRate)).font(.system(size:12,weight:.semibold)).monospacedDigit().frame(width:42) }.menuStyle(.borderlessButton).fixedSize().help(m.tr("Playback speed — changes immediately","Velocidad — cambia al instante")).accessibilityLabel(m.tr("Playback speed","Velocidad de reproducción"))
                Spacer(minLength:0)
                Button { m.skip(-15) } label: { Image(systemName:"gobackward.15").font(.system(size:20)) }.help(m.tr("Back 15 seconds","Retroceder 15 segundos"))
                Button { m.togglePlayback() } label: { Image(systemName:m.playing ? "pause.fill" : "play.fill").font(.system(size:18,weight:.semibold)).foregroundStyle(.white).frame(width:40,height:40).background(m.audioURL == nil ? Color.secondary.opacity(0.3) : TomPalette.blue,in:Circle()) }.help(m.playing ? m.tr("Pause","Pausar") : m.tr("Play","Reproducir")).accessibilityLabel(m.playing ? "Pause" : "Play")
                Button { m.skip(15) } label: { Image(systemName:"goforward.15").font(.system(size:20)) }.help(m.tr("Forward 15 seconds","Avanzar 15 segundos"))
                Spacer(minLength:0)
                Button { m.export() } label: { Image(systemName:"square.and.arrow.up").font(.system(size:16)).frame(width:36) }.help(m.tr("Export recording…","Exportar grabación…"))
            }.buttonStyle(.plain).disabled(m.audioURL == nil || m.audioLoading)
        }.padding(compact ? 16 : 18).background(TomPalette.blue.opacity(0.045)).background(.bar)
    }
}

struct Sidebar:View {
    @Bindable var m:Model
    var body:some View {
        VStack(spacing:0) {
            HStack(spacing:9) {
                if let image = AppAssets.icon { Image(nsImage:image).resizable().scaledToFit().frame(width:34,height:34) }
                VStack(alignment:.leading,spacing:2) { Text("Talking Tom").font(.headline).foregroundStyle(TomPalette.ink); Text(m.tr("Your listening library","Tu biblioteca de audio")).font(.caption).foregroundStyle(.secondary) }
                Spacer()
            }.padding(.horizontal,16).padding(.vertical,18).overlay(alignment:.bottomLeading) { Capsule().fill(TomPalette.yellow).frame(width:30,height:3).padding(.leading,16).padding(.bottom,7) }
            HStack { Image(systemName:"magnifyingglass").foregroundStyle(.secondary); TextField(m.tr("Search recordings","Buscar grabaciones"),text:$m.search).textFieldStyle(.plain) }.padding(7).background(.quaternary,in:RoundedRectangle(cornerRadius:7)).padding(.horizontal,12).padding(.bottom,12)
            List(selection:$m.selected) {
                Section(m.tr("Recordings","Grabaciones")) {
                    ForEach(m.filtered) { r in
                        HStack(alignment:.top,spacing:9) {
                            Image(systemName:m.selected == r.id && m.playing ? "waveform" : "waveform.circle").foregroundStyle(.secondary).padding(.top,2)
                            VStack(alignment:.leading,spacing:4) { Text(r.title).font(.system(size:13,weight:.medium)).lineLimit(2); Text(r.date,style:.date).font(.caption2).foregroundStyle(.secondary) }
                        }.padding(.vertical,4).tag(r.id)
                        .contextMenu { Button(m.tr("Load transcript","Abrir transcripción")) { m.transcript(r) }; Button(m.tr("Show in Finder","Mostrar en Finder")) { NSWorkspace.shared.activateFileViewerSelecting([r.url]) } }
                    }
                }
            }.listStyle(.sidebar).scrollContentBackground(.hidden).onChange(of:m.selected) { _,id in if let id, id != m.audioURL?.path { m.loadAudio(URL(fileURLWithPath:id)) } }
            HStack { Text(m.tr("\(m.recordings.count) recordings","\(m.recordings.count) grabaciones")).font(.caption).foregroundStyle(.secondary); Spacer(); Button { m.refresh() } label: { Image(systemName:"arrow.clockwise") }.buttonStyle(.borderless).help(m.tr("Refresh library","Actualizar biblioteca")) }.padding(14)
        }.frame(minWidth:190,idealWidth:225,maxWidth:260).background(TomPalette.blue.opacity(0.075)).background(.thinMaterial)
    }
}

struct NarrationOptions:View {
    @Bindable var m:Model
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:22) {
                HStack(spacing:8) { Image(systemName:"waveform").foregroundStyle(TomPalette.ink).padding(6).background(TomPalette.yellow.opacity(0.3),in:RoundedRectangle(cornerRadius:7)); Text(m.tr("Narration","Narración")).font(.headline).foregroundStyle(TomPalette.ink) }
                VStack(alignment:.leading,spacing:7) {
                    Text(m.tr("Voice","Voz")).font(.subheadline).fontWeight(.medium)
                    Picker("Voice",selection:$m.voice) { ForEach(voices,id:\.self) { Text($0).tag($0) } }.labelsHidden().frame(maxWidth:.infinity)
                }
                VStack(alignment:.leading,spacing:7) {
                    Text(m.tr("Generation speed","Velocidad al generar")).font(.subheadline).fontWeight(.medium)
                    Picker("Generation speed",selection:$m.generationRate) { ForEach(generationRates,id:\.self) { Text($0).tag($0) } }.labelsHidden()
                    Text(m.tr("You can change playback speed anytime after recording.","Puedes cambiar la velocidad de reproducción después de generar el audio.")).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal:false,vertical:true)
                }
                Divider()
                VStack(alignment:.leading,spacing:7) {
                    Text(m.tr("Text cleanup","Limpieza del texto")).font(.subheadline).fontWeight(.medium)
                    Picker("Text cleanup",selection:$m.cleaning) { Text(m.tr("Standard","Estándar")).tag("builtin"); Text(m.tr("AI cleanup","Limpieza con IA")).tag("ai"); Text(m.tr("None","Ninguna")).tag("none") }.labelsHidden()
                    Text(m.cleaning == "ai" ? m.tr("Uses Anthropic to prepare natural spoken text.","Usa Anthropic para preparar el texto.") : m.cleaning == "builtin" ? m.tr("Removes citations and common PDF clutter on your Mac.","Elimina citas y elementos de PDF en tu Mac.") : m.tr("Reads the text exactly as written.","Lee el texto tal como está escrito.")).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal:false,vertical:true)
                }
                VStack(alignment:.leading,spacing:7) {
                    Text(m.tr("Read in","Idioma de lectura")).font(.subheadline).fontWeight(.medium)
                    Picker("Read in",selection:$m.readin) { Text(m.tr("Original language","Idioma original")).tag("auto"); Text("English").tag("en"); Text("Español").tag("es") }.labelsHidden()
                    if m.readin != "auto" { Text(m.tr("Translation uses your Anthropic API key.","La traducción usa tu clave de Anthropic.")).font(.caption).foregroundStyle(.secondary) }
                    Toggle(m.tr("Translate visuals","Traducir gráficos y tablas"),isOn:$m.translateVisuals).toggleStyle(.checkbox)
                    if m.translateVisuals {
                        Text(m.sourcePDF.isEmpty ? m.tr("Reopen the original PDF to include visual explanations.","Vuelve a abrir el PDF original para explicar sus gráficos.") : m.tr("Explains figures and tables once, where they are discussed. Appendix visuals are included only when referenced.","Explica figuras y tablas una sola vez, donde se comentan. Incluye gráficos del apéndice solo cuando se citan.")).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal:false,vertical:true)
                    }
                    Text(m.tr("Model","Modelo")).font(.subheadline).fontWeight(.medium).padding(.top,5)
                    Picker("Model",selection:$m.aiModel) {
                        Text(m.tr("Auto · match document","Auto · según documento")).tag("auto")
                        Text("Claude Haiku 5.5").tag("claude-haiku-5-5")
                        Text("Claude Sonnet 5").tag("claude-sonnet-5")
                    }.labelsHidden()
                    Text(m.tr("Auto uses a small assessment and reserves Sonnet for harder work.","Auto hace una evaluación breve y reserva Sonnet para tareas difíciles.")).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal:false,vertical:true)
                }
                Divider()
                Label(m.tr("Audio saved on your Mac","Audio guardado en tu Mac"),systemImage:"internaldrive").font(.caption).foregroundStyle(.secondary)
                Text(m.tr("Speech generation sends your text to Microsoft’s online voices.","La generación de voz envía el texto a las voces en línea de Microsoft.")).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal:false,vertical:true)
            }.padding(20)
        }.frame(width:230).background(Color(nsColor:.controlBackgroundColor)).disabled(m.busy)
    }
}

struct Workspace:View {
    @Bindable var m:Model
    var wide:Bool
    var body:some View {
        HStack(spacing:0) {
            if wide { Sidebar(m:m); Divider() }
            VStack(spacing:0) {
                HStack(spacing:0) {
                    VStack(alignment:.leading,spacing:0) {
                        TextField(m.tr("Untitled document","Documento sin título"),text:$m.title).textFieldStyle(.plain).font(.system(size:25,weight:.bold)).foregroundStyle(TomPalette.ink).padding(.horizontal,28).padding(.top,28).disabled(m.busy)
                        HStack(spacing:7) { Text(m.tr("\(m.words.formatted()) words","\(m.words.formatted()) palabras")); Text("·"); Text(m.tr("About \(m.estimatedMinutes) min of listening","Unos \(m.estimatedMinutes) min de audio")) }.font(.caption).foregroundStyle(.secondary).padding(.horizontal,28).padding(.top,8).padding(.bottom,22)
                        ZStack(alignment:.topLeading) {
                            DocumentEditor(m:m).padding(.horizontal,23)
                            if m.isTextEmpty {
                                VStack(alignment:.leading,spacing:14) {
                                    Image(systemName:"text.book.closed").font(.system(size:24,weight:.medium)).foregroundStyle(TomPalette.ink).frame(width:52,height:52).background(TomPalette.yellow.opacity(0.28),in:RoundedRectangle(cornerRadius:14))
                                    Text(m.tr("A good read.\nAn easier listen.","Una buena lectura.\nMás fácil de escuchar.")).font(.system(size:28,weight:.semibold)).foregroundStyle(TomPalette.ink)
                                    Text(m.tr("Paste your text here, or open a PDF, Word document, or text file.","Pega texto aquí o abre un PDF, documento Word o archivo de texto.")).font(.system(size:14)).foregroundStyle(.tertiary).frame(maxWidth:300,alignment:.leading)
                                }.padding(.horizontal,28).padding(.top,6).allowsHitTesting(false)
                            }
                        }
                        HStack(spacing:12) {
                            if m.busy { ProgressView().controlSize(.small); Text(m.status).font(.caption).foregroundStyle(.secondary).lineLimit(2); Spacer(minLength:0); Button(m.tr("Cancel","Cancelar")) { m.cancel() } }
                            else {
                                Text(m.status.isEmpty ? m.tr("Drop a document here to get started","Arrastra un documento para empezar") : m.status).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                                Spacer(minLength:4)
                                Button { m.request("generate") } label: { Label(m.tr("Generate Audio","Generar audio"),systemImage:"waveform.badge.plus").padding(.vertical,3) }.buttonStyle(.borderedProminent).disabled(m.isTextEmpty).keyboardShortcut("r",modifiers:.command)
                            }
                        }.padding(20)
                    }.frame(maxWidth:.infinity,maxHeight:.infinity).background(Color(nsColor:.textBackgroundColor))
                    if m.inspector && wide { Divider(); NarrationOptions(m:m) }
                }
                Divider()
                PlayerView(m:m)
            }
        }
    }
}

struct ContentView:View {
    @Bindable var m:Model
    var body:some View {
        Group {
            if m.mini { MiniPlaybackView(m:m) }
            else {
                GeometryReader { g in
                    if m.zoom == 1 {
                        Workspace(m:m,wide:g.size.width >= 900)
                    } else {
                        let width = max(360, g.size.width / m.zoom)
                        let height = max(400, g.size.height / m.zoom)
                        ScrollView([.horizontal,.vertical]) {
                            Workspace(m:m,wide:width >= 900)
                                .frame(width:width,height:height)
                                .scaleEffect(m.zoom,anchor:.topLeading)
                                .frame(width:width * m.zoom,height:height * m.zoom,alignment:.topLeading)
                        }
                    }
                }
            }
        }.tint(TomPalette.blue)
        .toolbar {
            ToolbarItemGroup(placement:.primaryAction) {
              if !m.mini {
                Button { m.toggleMini() } label: { Label(m.tr("Mini Player","Minirreproductor"),systemImage:"arrow.down.right.and.arrow.up.left") }
                    .help(m.tr("Mini Player (⇧⌘M)","Minirreproductor (⇧⌘M)"))
                Button { m.openDocument() } label: { Label(m.tr("Open Document","Abrir documento"),systemImage:"doc.badge.plus") }.disabled(m.busy).help(m.tr("Open document or audio","Abrir documento o audio"))
                Menu {
                    Button(m.tr("Clean Text","Limpiar texto")) { m.request("clean") }.disabled(m.isTextEmpty || m.busy)
                    Button(m.tr("Translate Text","Traducir texto")) { m.request("translate") }.disabled(m.isTextEmpty || m.busy)
                    Divider()
                    Button(m.tr("New Document","Nuevo documento")) { m.newDocument() }.disabled(m.busy)
                    Button(m.tr("Show Recordings in Finder","Mostrar grabaciones en Finder")) { NSWorkspace.shared.open(libraryURL) }
                } label: { Label(m.tr("Text Actions","Acciones de texto"),systemImage:"ellipsis.circle") }
                Button { if (NSApp.mainWindow?.frame.width ?? 1060) < 900 { m.showOptions.toggle() } else { m.inspector.toggle() } } label: { Label(m.tr("Narration Options","Opciones de narración"),systemImage:"sidebar.right") }.popover(isPresented:$m.showOptions) { NarrationOptions(m:m) }
              }
            }
        }
        .onDrop(of:[.fileURL],isTargeted:nil) { providers in
            guard !m.busy, let provider = providers.first else { return false }
            _ = provider.loadObject(ofClass:URL.self) { url,_ in if let url { Task { @MainActor in m.open(url) } } }; return true
        }
        .onOpenURL { m.open($0) }
        .onChange(of:m.voice) { m.persist() }
        .onChange(of:m.generationRate) { m.persist() }
        .onChange(of:m.cleaning) { m.persist() }
        .onChange(of:m.readin) { m.persist() }
        .onChange(of:m.translateVisuals) { m.persist() }
        .onChange(of:m.aiModel) { m.persist() }
        .alert(m.tr("Something needs attention","Algo necesita atención"),isPresented:Binding(get:{m.error != nil},set:{if !$0 {m.error = nil}})) { Button("OK") { m.error = nil } } message: { Text(m.error ?? "") }
        .alert(m.tr("Document import","Importación"),isPresented:Binding(get:{m.notice != nil},set:{if !$0 {m.notice = nil}})) { Button("OK") { m.notice = nil } } message: { Text(m.notice ?? "") }
        .confirmationDialog(m.tr("Use Anthropic for this text?","¿Usar Anthropic con este texto?"),isPresented:$m.showAIConsent,titleVisibility:.visible) {
            Button(m.tr("Continue","Continuar")) { m.perform(m.pendingOperation) }
        } message: { Text(m.tr("Your document text will be sent to Anthropic. If Translate visuals is selected, relevant PDF pages are sent too. Auto may use Haiku and Sonnet. API usage incurs charges; saved analyses are reused.","El texto se enviará a Anthropic. Si activas gráficos, también se enviarán páginas del PDF. Auto puede usar Haiku y Sonnet. Hay cargos de API; se reutilizan análisis guardados.")) }
    }
}

struct SettingsView:View {
    @Bindable var m:Model
    var body:some View {
        Form {
            Section(m.tr("General","General")) {
                Picker(m.tr("App language","Idioma de la app"),selection:$m.language) { Text("English").tag("en"); Text("Español").tag("es") }
            }
            Section(m.tr("AI cleanup & translation","Limpieza y traducción con IA")) {
                SecureField(m.tr("Anthropic API key","Clave de Anthropic"),text:$m.apiKey).textContentType(.password)
                Picker(m.tr("Model","Modelo"),selection:$m.aiModel) { Text("Auto").tag("auto"); Text("Claude Haiku 5.5").tag("claude-haiku-5-5"); Text("Claude Sonnet 5").tag("claude-sonnet-5") }
                Text(m.tr("Optional. Standard cleanup and speech generation work without an API key. Your key stays in your private local settings and is never included in the app.","Opcional. La limpieza estándar y la voz no necesitan una clave. Tu clave permanece en los ajustes privados de tu Mac.")).font(.caption).foregroundStyle(.secondary)
            }
            Section(m.tr("Recordings","Grabaciones")) {
                LabeledContent(m.tr("Saved to","Carpeta"),value:"~/Talking Tom")
                Button(m.tr("Open Recordings Folder","Abrir carpeta de grabaciones")) { NSWorkspace.shared.open(libraryURL) }
            }
        }.formStyle(.grouped).frame(width:500,height:385).onDisappear { m.persist() }.onChange(of:m.language) { m.persist() }.onChange(of:m.apiKey) { m.persist() }.onChange(of:m.aiModel) { m.persist() }
    }
}

extension Double {
    var roundedToHundredth: Double { (self * 100).rounded() / 100 }
}

@MainActor @Observable final class AppSession {
    var tabs: [Model] = []
    var selectedID: UUID
    var isMini = false
    @ObservationIgnored weak var window: NSWindow?
    @ObservationIgnored var workspaceFrame: NSRect?
    static let miniContentHeight: CGFloat = 110
    func toggleMini() {
        guard let window = window ?? NSApp.mainWindow else { return }
        if !isMini { workspaceFrame = window.frame }
        isMini.toggle()
        let compact = isMini
        // Let SwiftUI remove the workspace minimum before fitting the small player.
        DispatchQueue.main.async { [weak self, weak window] in
            guard let self, let window, self.isMini == compact else { return }
            self.configureWindow(window)
            let target: NSRect
            if compact {
                let content = NSRect(x:0,y:0,width:360,height:Self.miniContentHeight)
                let size = window.frameRect(forContentRect:content).size
                target = NSRect(x:window.frame.minX,y:window.frame.maxY-size.height,width:size.width,height:size.height)
            } else {
                target = self.workspaceFrame ?? NSRect(x:window.frame.minX,y:window.frame.maxY-800,width:1060,height:800)
            }
            window.setFrame(target,display:true,animate:false)
        }
    }
    func configureWindow(_ window: NSWindow) {
        window.toolbar?.isVisible = !isMini
        window.titleVisibility = isMini ? .hidden : .visible
        window.contentMinSize = NSSize(width:isMini ? 320 : 360,height:isMini ? Self.miniContentHeight : 420)
        window.contentMaxSize = NSSize(width:CGFloat.greatestFiniteMagnitude,height:isMini ? Self.miniContentHeight : CGFloat.greatestFiniteMagnitude)
    }
    @ObservationIgnored weak var playbackOwner: Model?
    @ObservationIgnored var quitting = false
    @ObservationIgnored var keyMonitor: Any?
    @ObservationIgnored var remoteTargets: [(MPRemoteCommand, Any)] = []
    let stateDirectory: URL
    let mediaEnabled: Bool
    @ObservationIgnored var sessionWork: DispatchWorkItem?
    var manifestURL: URL { stateDirectory.appendingPathComponent("tabs.json") }
    var active: Model { tabs.first(where: { $0.id == selectedID }) ?? tabs[0] }
    var mediaTarget: Model? { playbackOwner ?? (active.audioURL == nil ? nil : active) }

    init(stateDirectory: URL = home.appendingPathComponent(".talking_tom"), installMedia: Bool = true) {
        self.stateDirectory = stateDirectory; self.mediaEnabled = installMedia
        let manifest = (try? Data(contentsOf:stateDirectory.appendingPathComponent("tabs.json")))
            .flatMap { try? JSONSerialization.jsonObject(with:$0) as? [String:Any] }
        let ids = (manifest?["tabs"] as? [String] ?? []).compactMap(UUID.init(uuidString:))
        selectedID = (manifest?["selected"] as? String).flatMap(UUID.init(uuidString:)) ?? ids.first ?? UUID()
        if ids.isEmpty {
            tabs = [Model(id:selectedID,draftURL:stateDirectory.appendingPathComponent("native-draft.json"))]
        } else {
            tabs = ids.map { id in
                let legacy = manifest?["legacy"] as? String == id.uuidString
                return Model(id:id,draftURL:legacy ? stateDirectory.appendingPathComponent("native-draft.json") : stateDirectory.appendingPathComponent("drafts/\(id.uuidString).json"))
            }
        }
        if !tabs.contains(where: { $0.id == selectedID }) { selectedID = tabs[0].id }
        tabs.forEach { $0.session = self }
        saveSession()
        if installMedia { installMediaControls() }
    }
    func saveSession(flush: Bool = false) {
        sessionWork?.cancel()
        let legacy = tabs.first(where: { $0.draftURL.lastPathComponent == "native-draft.json" })?.id.uuidString ?? ""
        let snapshot: [String:Any] = ["tabs":tabs.map { $0.id.uuidString },"selected":selectedID.uuidString,"legacy":legacy]
        let url = manifestURL
        if flush { FileWork.queue.sync { FileWork.writeJSON(snapshot,to:url) }; return }
        let work = DispatchWorkItem { FileWork.writeJSON(snapshot,to:url) }
        sessionWork = work; FileWork.queue.asyncAfter(deadline:.now()+0.5,execute:work)
    }
    func select(_ id: UUID) {
        guard id != selectedID, tabs.contains(where: { $0.id == id }) else { return }
        selectedID = id; saveSession()
    }
    func newTab() {
        let id = UUID(), previous = active
        let model = Model(id:id,draftURL:stateDirectory.appendingPathComponent("drafts/\(id.uuidString).json"),restore:false)
        model.voice = previous.voice; model.generationRate = previous.generationRate
        model.cleaning = previous.cleaning; model.readin = previous.readin
        model.language = previous.language; model.apiKey = previous.apiKey; model.aiModel = previous.aiModel; model.translateVisuals = previous.translateVisuals
        model.session = self; tabs.append(model); select(id)
    }
    func moveTab(_ offset: Int) {
        guard let index = tabs.firstIndex(where: { $0.id == selectedID }) else { return }
        select(tabs[(index + offset + tabs.count) % tabs.count].id)
    }
    func closeTab(_ model: Model) {
        if model.busy {
            model.error = model.tr("Cancel this tab’s task before closing it.","Cancela la tarea de esta pestaña antes de cerrarla.")
            select(model.id); return
        }
        if !model.text.isEmpty {
            let alert = NSAlert(); alert.messageText = model.tr("Close this tab?","¿Cerrar esta pestaña?")
            alert.informativeText = model.tr("The text in this tab will be discarded. Saved recordings will stay in your library.","Se descartará el texto de esta pestaña. Las grabaciones se conservarán.")
            alert.addButton(withTitle:model.tr("Cancel","Cancelar")); alert.addButton(withTitle:model.tr("Close Tab","Cerrar pestaña"))
            guard alert.runModal() == .alertSecondButtonReturn else { return }
        }
        model.cancelAudioLoad(); model.pausePlayback(); model.wordCountTask?.cancel(); model.draftWork?.cancel()
        if playbackOwner === model { playbackOwner = nil; clearNowPlaying() }
        let index = tabs.firstIndex(where: { $0 === model }) ?? 0
        if tabs.count == 1 { newTab() }
        tabs.removeAll { $0 === model }
        if selectedID == model.id { selectedID = tabs[min(index,tabs.count-1)].id }
        let closedDraft = model.draftURL
        FileWork.queue.async { try? FileManager.default.removeItem(at:closedDraft) }
        saveSession()
    }
    func claimPlayback(_ model: Model) {
        // Runs synchronously on the main actor: no second player starts before the first pauses.
        for tab in tabs where tab !== model { if tab.player?.isPlaying == true || tab.playing { tab.pausePlayback() } }
        playbackOwner = model
    }
    func audioLoaded(_ model: Model) {
        if playbackOwner == nil || playbackOwner === model { playbackOwner = model; updateNowPlaying(model) }
        // All tabs observe one shared library; loading audio needs no directory scan.
    }
    func clearNowPlaying() {
        guard mediaEnabled else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        MPNowPlayingInfoCenter.default().playbackState = .stopped
    }
    func updateNowPlaying(_ model: Model) {
        guard mediaEnabled, playbackOwner === model, let url = model.audioURL else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle:url.deletingPathExtension().lastPathComponent,
            MPMediaItemPropertyPlaybackDuration:model.duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime:model.position,
            MPNowPlayingInfoPropertyPlaybackRate:model.playing ? Double(model.playbackRate) : 0,
            MPNowPlayingInfoPropertyDefaultPlaybackRate:Double(model.playbackRate),
            MPNowPlayingInfoPropertyMediaType:MPNowPlayingInfoMediaType.audio.rawValue
        ]
        MPNowPlayingInfoCenter.default().playbackState = model.playing ? .playing : .paused
    }
    @discardableResult func mediaAction(_ action: String) -> Bool {
        guard let model = mediaTarget, model.audioURL != nil else { return false }
        switch action {
        case "toggle": model.togglePlayback()
        case "play": if !model.playing { model.togglePlayback() }
        case "pause": model.pausePlayback()
        case "back": model.skip(-15)
        case "forward": model.skip(15)
        default: return false
        }
        return true
    }
    func installMediaControls() {
        let center = MPRemoteCommandCenter.shared()
        center.skipBackwardCommand.preferredIntervals = [15]
        center.skipForwardCommand.preferredIntervals = [15]
        let commands: [(MPRemoteCommand,String)] = [
            (center.togglePlayPauseCommand,"toggle"),(center.playCommand,"play"),(center.pauseCommand,"pause"),
            (center.previousTrackCommand,"back"),(center.nextTrackCommand,"forward"),
            (center.skipBackwardCommand,"back"),(center.skipForwardCommand,"forward")
        ]
        for (command,action) in commands {
            command.isEnabled = true
            let target = command.addTarget { [weak self] _ in
                // Remote commands may arrive off the main thread; serialize with all UI playback.
                if Thread.isMainThread {
                    return MainActor.assumeIsolated { self?.mediaAction(action) == true ? .success : .noSuchContent }
                }
                return DispatchQueue.main.sync {
                    MainActor.assumeIsolated { self?.mediaAction(action) == true ? .success : .noSuchContent }
                }
            }
            remoteTargets.append((command,target))
        }
        // When the keyboard is configured to emit ordinary function keys.
        keyMonitor = NSEvent.addLocalMonitorForEvents(matching:.keyDown) { [weak self] event in
            let modifiers = event.modifierFlags.intersection([.command,.control,.option,.shift])
            if modifiers == .command || modifiers == [.command,.shift] {
                let character = event.charactersIgnoringModifiers ?? ""
                if ["=","+","-","0"].contains(character) {
                    MainActor.assumeIsolated {
                        guard let self else { return }
                        if character == "0" { self.active.zoom = 1 }
                        else { self.active.changeZoom(character == "-" ? -0.1 : 0.1) }
                    }
                    return nil
                }
            }
            guard modifiers.isEmpty else { return event }
            let action: String
            switch event.keyCode { case 98: action = "back"; case 100: action = "toggle"; case 101: action = "forward"; default: return event }
            if event.isARepeat { return nil }
            let handled = MainActor.assumeIsolated { self?.mediaAction(action) == true }
            return handled ? nil : event
        }
    }
    func syncPreferences(from model: Model) {
        for tab in tabs where tab !== model {
            tab.language = model.language; tab.apiKey = model.apiKey; tab.aiModel = model.aiModel
        }
    }
    func workerFinished() {
        if quitting && !tabs.contains(where: { $0.busy }) { NSApp.reply(toApplicationShouldTerminate:true) }
    }
}

struct WorkspaceTab: View {
    @Bindable var model: Model
    @Bindable var session: AppSession
    var body: some View {
        HStack(spacing:6) {
            Button { session.select(model.id) } label: {
                HStack(spacing:6) {
                    if model.busy { ProgressView().controlSize(.mini) }
                    else if model.playing { Image(systemName:"speaker.wave.2.fill") }
                    if session.isMini {
                        if !model.busy && !model.playing { Image(systemName:"doc.text") }
                        Text("\((session.tabs.firstIndex(where: { $0.id == model.id }) ?? 0) + 1)").font(.caption2)
                    } else {
                        Text(model.title.isEmpty ? model.tr("Untitled","Sin título") : model.title).lineLimit(1)
                    }
                }.frame(minWidth:session.isMini ? 24 : 60,maxWidth:session.isMini ? 40 : 180).padding(.vertical,session.isMini ? 4 : 7)
            }.buttonStyle(.plain).help(model.title.isEmpty ? "Untitled" : model.title)
                .accessibilityLabel(model.title.isEmpty ? "Untitled tab" : model.title)
            if !session.isMini { Button { session.closeTab(model) } label: { Image(systemName:"xmark").font(.caption) }
                .buttonStyle(.plain).help(model.tr("Close Tab","Cerrar pestaña"))
                .accessibilityLabel(model.tr("Close tab","Cerrar pestaña") + " " + model.title) }
        }.padding(.horizontal,session.isMini ? 6 : 10)
            .background(session.selectedID == model.id ? Color.accentColor.opacity(0.14) : Color.clear,in:RoundedRectangle(cornerRadius:6))
            .accessibilityAddTraits(session.selectedID == model.id ? .isSelected : [])
    }
}

struct TabbedWorkspace: View {
    @Bindable var session: AppSession
    var body: some View {
        VStack(spacing:0) {
            HStack(spacing:4) {
                ScrollView(.horizontal) {
                    ScrollViewReader { proxy in
                        HStack(spacing:2) { ForEach(session.tabs,id:\.id) { model in WorkspaceTab(model:model,session:session).id(model.id) } }
                            .onChange(of:session.selectedID) { _,id in proxy.scrollTo(id) }
                    }
                }.scrollIndicators(.hidden)
                Button { session.newTab() } label: { Image(systemName:"plus") }.buttonStyle(.borderless)
                    .help("New Tab (⌘T)").accessibilityLabel("New Tab").padding(.horizontal,10)
            }.padding(.horizontal,5).frame(height:33).background(.bar)
            Divider()
            ContentView(m:session.active)
        }.frame(minWidth:session.isMini ? 320 : 360,
                 minHeight:session.isMini ? AppSession.miniContentHeight : 420,
                 maxHeight:session.isMini ? AppSession.miniContentHeight : .infinity)
            .background(WindowAttachment(session:session).frame(width:0,height:0))
    }
}

struct WindowAttachment: NSViewRepresentable {
    let session: AppSession
    final class AttachmentView: NSView {
        weak var session: AppSession?
        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            guard let window, let session else { return }
            session.window = window
            DispatchQueue.main.async { [weak session, weak window] in
                if let session, let window { session.configureWindow(window) }
            }
        }
    }
    func makeNSView(context: Context) -> AttachmentView {
        let view = AttachmentView(); view.session = session; return view
    }
    func updateNSView(_ view: AttachmentView, context: Context) { view.session = session }
}

@MainActor final class AppDelegate:NSObject,NSApplicationDelegate {
    @ObservationIgnored weak var session: AppSession?
    func applicationShouldTerminate(_ sender:NSApplication) -> NSApplication.TerminateReply {
        guard let session else { return .terminateNow }
        session.tabs.forEach { $0.flushDraft() }; session.saveSession(flush:true)
        guard session.tabs.contains(where: { $0.busy }) else { return .terminateNow }
        let alert = NSAlert(); alert.messageText = "Cancel active tasks and quit?"
        alert.informativeText = "All tab drafts will be kept."
        alert.addButton(withTitle:"Keep Working"); alert.addButton(withTitle:"Cancel Tasks and Quit")
        if alert.runModal() == .alertSecondButtonReturn {
            session.quitting = true
            session.tabs.filter { $0.busy }.forEach { $0.cancel() }
            return .terminateLater
        }
        return .terminateCancel
    }
}

struct WorkspaceCommands: Commands {
    @Bindable var session: AppSession
    @Bindable var model: Model
    var body: some Commands {
        CommandGroup(replacing:.newItem) {
            Button("New Tab") { session.newTab() }.keyboardShortcut("t")
            Button("Close Tab") { session.closeTab(model) }.keyboardShortcut("w")
            Divider()
            Button(model.tr("New Document","Nuevo documento")) { model.newDocument() }.keyboardShortcut("n").disabled(model.busy)
            Button(model.tr("Open…","Abrir…")) { model.openDocument() }.keyboardShortcut("o").disabled(model.busy)
        }
        CommandGroup(after:.toolbar) {
            Divider()
            Button("Zoom In") { model.changeZoom(0.1) }.keyboardShortcut("+",modifiers:.command).disabled(model.zoom >= 2)
            Button("Zoom Out") { model.changeZoom(-0.1) }.keyboardShortcut("-",modifiers:.command).disabled(model.zoom <= 0.75)
            Button("Actual Size (\(Int((model.zoom * 100).rounded()))%)") { model.zoom = 1 }.keyboardShortcut("0")
            Divider()
            Button("Show Next Tab") { session.moveTab(1) }.keyboardShortcut("]",modifiers:[.command,.shift])
            Button("Show Previous Tab") { session.moveTab(-1) }.keyboardShortcut("[",modifiers:[.command,.shift])
        }
        CommandMenu(model.tr("Playback","Reproducción")) {
            Button(model.playing ? model.tr("Pause","Pausar") : model.tr("Play","Reproducir")) { model.togglePlayback() }.keyboardShortcut(.space,modifiers:.command).disabled(model.audioURL == nil || model.audioLoading)
            Button(model.tr("Back 15 Seconds","Retroceder 15 segundos")) { model.skip(-15) }.keyboardShortcut(.leftArrow,modifiers:.command).disabled(model.audioURL == nil || model.audioLoading)
            Button(model.tr("Forward 15 Seconds","Avanzar 15 segundos")) { model.skip(15) }.keyboardShortcut(.rightArrow,modifiers:.command).disabled(model.audioURL == nil || model.audioLoading)
            Divider()
            Button(model.tr("Mini Player / Full Workspace","Minirreproductor / Ventana completa")) { model.toggleMini() }.keyboardShortcut("m",modifiers:[.command,.shift])
            Button(model.tr("Export Recording…","Exportar grabación…")) { model.export() }.keyboardShortcut("s",modifiers:[.command,.shift]).disabled(model.audioURL == nil || model.audioLoading)
        }
    }
}

@main struct TalkingTomApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @State var session = AppSession()
    var body:some Scene {
        Window("Talking Tom",id:"main") { TabbedWorkspace(session:session).onAppear { delegate.session = session } }.defaultSize(width:1060,height:800).windowResizability(.contentSize)
            .commands { WorkspaceCommands(session:session,model:session.active) }
        Settings {
            SettingsView(m:session.active)
                .onChange(of:session.active.language) { session.syncPreferences(from:session.active) }
                .onChange(of:session.active.apiKey) { session.syncPreferences(from:session.active) }
                .onChange(of:session.active.aiModel) { session.syncPreferences(from:session.active) }
        }
    }
}
