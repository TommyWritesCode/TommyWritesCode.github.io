# Talking Tom 2.2 performance work

## Diagnosed causes

- The 2.1 workspace used one ObservableObject for every property. Ten playback ticks per second invalidated the editor, sidebar, menus, tab label, and geometry, even when only the time changed.
- The word-count getter split the full document into an array on every read, including repeated reads from view bodies. The sidebar loaded the icon from disk in its body.
- Tab selection enumerated the recording directory and synchronously serialized/wrote the session manifest. Draft JSON serialization ran on each edit; writing also ran on the main queue.
- Switching tabs destroyed the content view identity and recreated the text editor. All tabs had permanently running timers.
- At 100% zoom, every window resize still passed through a two-axis scroll view and scaled geometry. Long paragraphs were re-typeset for every width change.
- Audio decoder preparation, large worker-input writes, and exports ran on the UI thread. A full worker pipe can block until Python finishes importing its dependencies.
- The installed binary was compiled without release optimization.

## Changes

Use Apple's Observation model so views depend on individual properties. A separate PlaybackTimeline receives time updates; unrelated content does not. Cache the word count, compute it off the main actor after edits settle, discard stale results, and cache the icon. Keep one asynchronously refreshed library for all tabs.

Debounce draft/session writes on a serial background queue. Selecting an existing tab performs no directory scan or synchronous disk write. New tabs inherit preferences in memory. Explicit shutdown flushes preserve draft durability.

Each visited tab owns a reusable TextKit 2 editor, preserving native text storage, layout, selection, scrolling and undo. Only the visible editor is attached. Normal-size layout avoids the outer scroll/scale layer. During live window resizing, preserve line wrapping and reflow once at completion rather than typesetting a long paragraph for each mouse event.

Only the playing tab runs a playback timer. Stop it on pause, completion, replacement and close; use common run-loop modes during event tracking. Scrubbing previews the position and commits the seek on release. Load and prepare audio off the main thread with a generation token that rejects stale results. Serialize/send worker requests and copy exports in the background. Compile with `-O -whole-module-optimization`.

## Measurements and checks

Measured on this Mac with a synthetic 120,000-word document. These are targeted regression tests, not measurements of screen frame rate or a guarantee of zero latency.

| Test | Before | After |
| --- | ---: | ---: |
| 120 playback position updates plus dependent word-count reads | 7,334 ms (baseline also compiled with -O) | 0.20 ms |
| Unrelated workspace dependency notifications from those ticks | 120 broad model notifications | 0 |
| 120 native editor viewport resize/layout passes | 35,438 ms before live-resize preservation | 426 ms with preservation |
| 1,000 tab selections with persistence queue blocked | Not measured | 7.2 ms |
| 120 unchanged native editor updates | Not measured | 0.027 ms |

The resize stress case is one extremely long paragraph; reflow happens after resizing completes. It is an offscreen AppKit layout test, not an Instruments rendering trace.

Passed:
- Playback exclusivity, pause/resume positions, media-command routing, seek/replay, tab isolation/restoration, and zoom bounds.
- Rapid recording selection rejects stale asynchronous loads; paused tabs have no timer.
- Native editor storage, layout manager, selection and instance survive ordinary updates and tab switching.
- Word-count cancellation does not allow an old result to overwrite new text.
- Eight simultaneous generation workers with matching titles, and eight concurrent chunk-assembly jobs while a ninth is cancelled.
- Actual SwiftUI content rendered and visually inspected at normal size, 150% zoom, and compact size in offscreen test windows.

Reproduce with `python3 benchmark_baseline.py`, `python3 test_performance.py`, `python3 test_native.py`, `python3 test_layout.py`, `python3 test_worker_concurrency.py`, and `python3 test_engine_concurrency.py`. Native tests require AppKit/audio services and compiler-macro execution. The baseline source is retained under `verification/Main-2.1.swift`.

## Apple references

- [Understanding and improving SwiftUI performance](https://developer.apple.com/documentation/xcode/understanding-and-improving-swiftui-performance): minimize expensive body computations and unnecessary update frequency.
- [Migrating to Observation](https://developer.apple.com/documentation/swiftui/migrating-from-the-observable-object-protocol-to-the-observable-macro): property-level view dependencies instead of broad object notifications.
- [Improving app responsiveness](https://developer.apple.com/documentation/xcode/improving-app-responsiveness): keep continuous interaction work within the display interval and move non-UI work off the main thread.
- [Meet TextKit 2](https://developer.apple.com/videos/play/wwdc2021/10061/): native viewport-based text layout; avoid unnecessarily laying out the entire document.
- [Live-resize lifecycle](https://developer.apple.com/documentation/appkit/nsview/viewwillstartliveresize()): use AppKit's resize lifecycle to reduce repeated layout work and restore full rendering at completion.

The final worker-backpressure integration test also passed: submitting a 3.2 MB request returned in 2.06 ms, and a scheduled main-actor event ran at 52.3 ms while the test worker deliberately waited 500 ms before reading. The complete result was received. Reproduce with `python3 test_worker_responsiveness.py`; it invokes only a local offline test worker.
