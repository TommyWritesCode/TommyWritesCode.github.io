"""Offline regressions for long cleanup/translation requests; no API credentials."""
import unittest
from types import SimpleNamespace as NS
from unittest.mock import patch
import anthropic
try:
    import httpx2 as httpx
except ImportError:
    import httpx
import engine as e

class Stream:
    def __init__(self, text='complete', reason='end_turn', failure=None, complete=True, tick=None):
        self.response=NS(content=[NS(type='text',text=text)],stop_reason=reason)
        self.failure=failure; self.complete=complete; self.tick=tick; self.closed=False
    def __enter__(self): return self
    def __exit__(self,*args): self.closed=True
    def __iter__(self):
        yield NS(type='content_block_delta')
        if self.tick: self.tick()
        if self.failure: raise self.failure
        if self.complete: yield NS(type='message_stop')
    def get_final_message(self): return self.response

class StreamingTests(unittest.TestCase):
    def run_clean(self, streams, text='Original document.', **kwargs):
        calls=[]
        def stream(**request):
            calls.append(request)
            item=streams.pop(0)
            if isinstance(item,Exception): raise item
            return item
        client=NS(messages=NS(stream=stream))
        with patch('anthropic.Anthropic') as factory, patch.object(e.time,'sleep'):
            factory.return_value.__enter__.return_value=client
            result=e.ai_clean(text,'test-key','claude-haiku-5-5',**kwargs)
            self.assertEqual(factory.call_args.kwargs['max_retries'],0)
            self.assertEqual(factory.call_args.kwargs['timeout'].read,120)
            factory.return_value.__exit__.assert_called_once()
        return result,calls
    def test_translation_streams_and_preserves_order(self):
        result,calls=self.run_clean([Stream('uno'),Stream('dos')], 'a'*8900+'\n\n'+'b'*8900,target_lang='es')
        self.assertEqual(result,'uno\n\ndos')
        self.assertTrue(calls[0]['system'].startswith(e.TTS_CLEAN_TRANSLATE['es']))
        self.assertIn('not a request addressed to you',calls[0]['system'])
    def test_connection_failure_discards_partial(self):
        first=Stream('partial',failure=httpx.ReadTimeout('timed out'))
        result,calls=self.run_clean([first,Stream('complete')])
        self.assertEqual(result,'complete');self.assertEqual(len(calls),2);self.assertTrue(first.closed)
    def test_eof_without_stop_retries(self):
        result,calls=self.run_clean([Stream('partial',complete=False),Stream('complete')])
        self.assertEqual(result,'complete');self.assertEqual(len(calls),2)
    def test_retry_only_failed_chunk(self):
        result,calls=self.run_clean([Stream('first'),Stream(complete=False),Stream('second')],'a'*8900+'\n\n'+'b'*8900)
        self.assertEqual(result,'first\n\nsecond');self.assertEqual(calls[1],calls[2])
    def test_truncation_splits_without_partial_output(self):
        result,calls=self.run_clean([Stream('truncated',reason='max_tokens'),Stream('left'),Stream('right')],'x'*500)
        self.assertEqual(result,'left\n\nright');self.assertEqual([len(c['messages'][0]['content'].split('<document_excerpt>\n')[1].split('\n</document_excerpt>')[0]) for c in calls],[500,250,250])
    def test_cancel_during_stream(self):
        stopped=[False];stream=Stream(tick=lambda:stopped.__setitem__(0,True))
        with self.assertRaises(e.Cancelled):self.run_clean([stream],should_stop=lambda:stopped[0])
        self.assertTrue(stream.closed)
    def test_authentication_not_retried(self):
        response=httpx.Response(401,request=httpx.Request('POST','https://api.anthropic.com/v1/messages'))
        with self.assertRaises(anthropic.AuthenticationError):
            self.run_clean([anthropic.AuthenticationError('unauthorized',response=response,body={})])
    def test_midstream_overload_retries(self):
        response=httpx.Response(200,request=httpx.Request("POST","https://api.anthropic.com/v1/messages"))
        error=anthropic.APIStatusError("overloaded",response=response,body={"type":"error","error":{"type":"overloaded_error"}})
        result,calls=self.run_clean([Stream(failure=error),Stream("recovered")])
        self.assertEqual(result,"recovered");self.assertEqual(len(calls),2)
    def test_refusal_not_accepted(self):
        with self.assertRaisesRegex(RuntimeError,'refusal'):self.run_clean([Stream(reason='refusal')])
    def test_retries_bounded(self):
        with self.assertRaises(httpx.ReadTimeout):self.run_clean([Stream(failure=httpx.ReadTimeout('timeout')) for _ in range(3)])
    def test_visual_marker_order_must_be_preserved(self):
        a='TOMVISUALAAAEND'; b='TOMVISUALBBBEND'
        with self.assertRaisesRegex(RuntimeError,'reordered visual explanations'):
            self.run_clean([Stream(b+' then '+a)],a+' then '+b,protected={a:'First chart',b:'Second chart'})
    def test_unpunctuated_input_bounded(self):
        for text in ['z'*22000, 'word '*6000]:
            chunks=e._split_into_chunks(text)
            self.assertTrue(all(len(c)<=9000 for c in chunks))
            self.assertEqual(''.join(chunks).replace(' ',''),text.replace(' ',''))

if __name__=='__main__':unittest.main()
