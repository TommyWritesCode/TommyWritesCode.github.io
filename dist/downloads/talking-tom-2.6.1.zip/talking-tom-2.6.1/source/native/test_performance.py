"""Regression tests for UI dependency isolation, editor reuse, and blocked storage."""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parent
source=(root/'Main.swift').read_text().split('@main struct TalkingTomApp')[0]
source+='''
final class Counter: @unchecked Sendable { var value = 0 }
@main struct PerformanceTests {
 @MainActor static func main() async {
  setbuf(stdout,nil)
  print("Starting performance tests")
  _ = NSApplication.shared
  let root = URL(fileURLWithPath:CommandLine.arguments[1])
  let session = AppSession(stateDirectory:root,installMedia:false)
  let model = session.active
  model.loadingDraft = true
  model.text = String(repeating:"A long document for responsiveness testing. ",count:20_000)
  while model.words == 0 { try! await Task.sleep(for:.milliseconds(20)) }
  print("Word count:",model.words)
  precondition(model.words == 120_000)
  let unrelatedInvalidations = Counter()
  withObservationTracking {
   _ = model.words; _ = model.title; _ = model.zoom; _ = model.busy
   _ = model.isTextEmpty; _ = model.textRevision; _ = model.recordings
  } onChange: { unrelatedInvalidations.value += 1 }
  let timelineInvalidations = Counter()
  let start = CFAbsoluteTimeGetCurrent()
  var count = 0
  for tick in 1...120 {
   withObservationTracking { _ = model.position } onChange: { timelineInvalidations.value += 1 }
   model.position = Double(tick)/10; count += model.words
  }
  let elapsed = (CFAbsoluteTimeGetCurrent()-start)*1000
  print("Invalidations:",unrelatedInvalidations.value,timelineInvalidations.value)
  precondition(unrelatedInvalidations.value == 0 && timelineInvalidations.value == 120)
  precondition(count == 14_400_000)
  print("PASS: 120 playback ticks + cached word-count reads: \\(elapsed) ms; unrelated view invalidations: \\(unrelatedInvalidations.value); timeline invalidations: \\(timelineInvalidations.value)")
  precondition(model.timer == nil)
  session.newTab(); let second = session.active
  precondition(second.timer == nil)
  // A blocked filesystem must not block repeated tab selection.
  let gate = DispatchSemaphore(value:0)
  FileWork.queue.async { gate.wait() }
  let switchStart = CFAbsoluteTimeGetCurrent()
  for _ in 0..<500 { session.select(model.id); session.select(second.id) }
  let switchTime = (CFAbsoluteTimeGetCurrent()-switchStart)*1000
  gate.signal()
  precondition(switchTime < 100, "Tab selection blocked on persistence")
  print("PASS: 1,000 tab selections while storage queue is blocked: \\(switchTime) ms")
  let editor = NativeEditor(model:model); model.nativeEditor = editor
  editor.textView.setSelectedRange(NSRange(location:10,length:5))
  let storage = editor.textView.textStorage
  let layout = editor.textView.textLayoutManager
  let editorStart = CFAbsoluteTimeGetCurrent()
  for _ in 0..<120 { editor.apply(model) }
  let editorTime = (CFAbsoluteTimeGetCurrent()-editorStart)*1000
  precondition(editor.textView.selectedRange() == NSRange(location:10,length:5))
  precondition(editor.textView.textStorage === storage && editor.textView.textLayoutManager === layout)
  precondition(editor.textView.textLayoutManager != nil)
  print("PASS: 120 unchanged editor updates: \\(editorTime) ms; TextKit 2 storage/layout/selection retained")
  // Check native layout under changing viewport sizes without opening a user window.
  editor.scrollView.frame = NSRect(x:0,y:0,width:600,height:500)
  editor.scrollView.layoutSubtreeIfNeeded()
  editor.scrollView.viewWillStartLiveResize()
  let layoutStart = CFAbsoluteTimeGetCurrent()
  for index in 0..<120 {
   editor.scrollView.frame.size = NSSize(width:600 + index % 40,height:500 + index % 30)
   editor.scrollView.layoutSubtreeIfNeeded()
  }
  print("Native editor 120 viewport resize/layout passes: \\((CFAbsoluteTimeGetCurrent()-layoutStart)*1000) ms (offscreen layout, not display frame timing)")
  editor.scrollView.viewDidEndLiveResize()
  // Rapid edits must not let an older word-count job overwrite the latest result.
  model.text = "one two three"
  model.text = "final words"
  await model.wordCountTask?.value
  print("Latest edit word count:",model.words)
  precondition(model.words == 2)
  model.text = ""; precondition(model.words == 0 && model.isTextEmpty)
  session.tabs.forEach { $0.wordCountTask?.cancel(); $0.draftWork?.cancel() }
  session.sessionWork?.cancel()
  print("PASS: debounced word counts discard stale results; idle tabs have no playback timers")
 }
}
'''
with tempfile.TemporaryDirectory(prefix='tom-performance-') as folder:
 p=Path(folder);(p/'Performance.swift').write_text(source)
 subprocess.run(['swiftc','-O','-whole-module-optimization','-parse-as-library',str(p/'Performance.swift'),'-o',str(p/'Performance'),'-module-cache-path','/private/tmp/talking-tom-module-cache'],check=True)
 subprocess.run([str(p/'Performance'),folder],check=True)
