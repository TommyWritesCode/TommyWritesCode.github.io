"""Small deterministic regression suite for visual placement, routing and opt-in behavior."""
import io,json,runpy,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import engine as e
import claude_io
import pdf_narration as v
import model_routing as r
ROOT=Path(__file__).parent
SAMPLES=ROOT/'verification/visual-narration'

def answer(value,reason='end_turn'):
 return NS(stop_reason=reason,content=[NS(type='text',text=json.dumps(value))])

def visual(label,box,summary='Accuracy rises from sixty to eighty percent.'):
 return dict(label=label,kind='table' if label.startswith('Table') else 'figure',bbox=box,summary=summary,readable=True)

class NarrationTests(unittest.TestCase):
 def setUp(self):
  self.path=SAMPLES/'graph-and-appendix.pdf';self.pages=v.inspect_pages(self.path)
  self.analyses={1:{'visuals':[visual('Figure 1',[70,310,930,755])]},
    2:{'visuals':[visual('Table A1',[75,112,915,270],'Latency rises from forty to sixty-five milliseconds.'),visual('Table B1',[75,400,915,590],'EXCLUDED SUMMARY')]}}
 def test_first_reference_then_resume_and_appendix_filter(self):
  text,protected=v.place_summaries(self.pages,self.analyses)
  graph=next(m for m,s in protected.items() if s.startswith('Figure 1'))
  appendix=next(m for m,s in protected.items() if s.startswith('Table A1'))
  self.assertLess(text.index('compares their accuracy.'),text.index(graph))
  self.assertLess(text.index(graph),text.index('The next paragraph'))
  self.assertLess(text.index('latency tradeoff.'),text.index(appendix))
  self.assertEqual(len(protected),2)
  self.assertNotIn('EXCLUDED SUMMARY',' '.join(protected.values()))
  self.assertEqual(text.count('see Appendix A'),1)
  self.assertIn('generalization was not measured',text)
  self.assertNotIn('Accuracy (%)',text)
 def test_unreferenced_main_visual_still_gets_one_summary(self):
  pages=v.inspect_pages(SAMPLES/'table-and-diagram.pdf')
  data={1:{'visuals':[visual('Unlabeled visual',[90,445,905,565],'The pipeline has three stages.')]}}
  text,notes=v.place_summaries(pages,data,'es')
  self.assertEqual(len(notes),1)
  self.assertIn('página 1 del PDF',next(iter(notes.values())))
  data[1]['visuals'][0]['kind']='diagram'
  text,notes=v.place_summaries(pages,data,'es')
  marker=next(iter(notes))
  self.assertLess(text.index('describes the processing stages.'),text.index(marker))
  self.assertLess(text.index(marker),text.index('The pipeline preserves'))
 def test_edited_draft_fails_before_api(self):
  with tempfile.TemporaryDirectory() as d,patch.object(v,'analyze_page',side_effect=AssertionError('API called')):
   with self.assertRaisesRegex(ValueError,'edited'):
    v.prepare('Edited draft',self.path,'key',r.HAIKU,'en',Path(d))
 def test_bad_bounds_and_invented_labels_rejected(self):
  for item in [visual('Figure 1',[-1,0,1,2]),visual('Figure 999',[0,0,20,20])]:
   with self.assertRaises(ValueError):v.validate_analysis({'visuals':[item],'needs_more_reasoning':False},self.pages[0])
 def test_expensive_model_only_on_complex_visual(self):
  simple={'visuals':[visual('Figure 1',[70,310,930,755])],'needs_more_reasoning':True}
  strong=dict(simple,needs_more_reasoning=False)
  with tempfile.TemporaryDirectory() as d,patch.object(claude_io,'client'),patch.object(claude_io,'message',side_effect=[answer(simple),answer(simple),answer(strong)]) as call:
   v.analyze_page(self.path,self.pages[0],'key',r.HAIKU,'en',Path(d),True,lambda:None,None)
   self.assertEqual([c.kwargs['model'] for c in call.call_args_list],[r.HAIKU,r.HAIKU,r.SONNET])
   v.analyze_page(self.path,self.pages[0],'key',r.HAIKU,'en',Path(d),True,lambda:None,None)
   self.assertEqual(call.call_count,3,'cached visual must not cost another request')
 def test_manual_model_is_honored(self):
  with patch.object(claude_io,'message',side_effect=AssertionError('Router called')):
   self.assertEqual(r.choose_models('text','key',r.HAIKU)['visuals'],r.HAIKU)
 def test_auto_router_bounded_and_cached(self):
  with tempfile.TemporaryDirectory() as d,patch.object(claude_io,'client'),patch.object(claude_io,'message',return_value=answer({'prose':'simple','visuals':'complex','reason':'Dense statistics'})) as call:
   route=r.choose_models('test '*50000,'key','auto',visuals=True,cache_dir=Path(d))
   self.assertEqual(route['prose'],r.HAIKU);self.assertEqual(route['visuals'],r.HAIKU)
   self.assertLess(len(call.call_args.kwargs['content']),5200)
   r.choose_models('test '*50000,'key','auto',visuals=True,cache_dir=Path(d));self.assertEqual(call.call_count,1)
 def test_opt_out_never_calls_vision_and_repeat_clean_does_not_duplicate(self):
  for enabled,prepared in [(False,False),(True,True)]:
   request={'operation':'clean','text':'A short English research document.','model':r.HAIKU,'clean':'ai','translate_visuals':enabled,'visuals_prepared':prepared,'source_pdf':str(self.path)}
   with patch('sys.stdin',io.StringIO(json.dumps(request))),patch('sys.stdout',io.StringIO()) as output,patch.object(e,'get_api_key',return_value='test'),patch.object(e,'ai_clean',return_value='Cleaned document.') as clean,patch.object(v,'prepare',side_effect=AssertionError('Vision called')),patch('signal.signal'):
    runpy.run_path(str(ROOT/'worker.py'),run_name='__main__')
   result=json.loads(output.getvalue().splitlines()[-1]);self.assertEqual(result['type'],'result')
   self.assertEqual(clean.call_args.kwargs['preserve_visuals'],prepared)
 def test_pdf_snapshot_and_plain_import_provenance(self):
  with tempfile.TemporaryDirectory() as d:
   dest=v.attach_pdf(self.path,Path(d));self.assertEqual(Path(dest).read_bytes(),self.path.read_bytes())
   self.assertEqual(dest,v.attach_pdf(self.path,Path(d)))
 def test_cancel_before_visual_request(self):
  def stop():raise e.Cancelled()
  with tempfile.TemporaryDirectory() as d,patch.object(claude_io,'message',side_effect=AssertionError('API called')):
   with self.assertRaises(e.Cancelled):
    v.analyze_page(self.path,self.pages[0],'key',r.HAIKU,'en',Path(d),True,stop,None)

if __name__=='__main__':unittest.main()
