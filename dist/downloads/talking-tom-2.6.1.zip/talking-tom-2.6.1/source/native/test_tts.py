"""Offline speech-service regressions, using production functions without app state."""
import ast
import asyncio
from pathlib import Path
import re
import shutil
import socket
import ssl
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import aiohttp


SOURCE = ast.parse(Path(__file__).with_name("engine.py").read_text())
NAMES = {"STRINGS", "t", "_tts_error_message", "_save_piece", "_edge_generate",
         "check_and_install_deps", "_module_available"}
NODES = [n for n in SOURCE.body
         if (isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in NAMES)
         or (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "STRINGS"
                                               for t in n.targets))]


class Cancelled(Exception):
    pass


def load_scope(folder):
    scope = dict(Path=Path, asyncio=asyncio, socket=socket, ssl=ssl, re=re,
                 shutil=shutil, tempfile=tempfile, Cancelled=Cancelled,
                 STORAGE_DIR=Path(folder),
                 _split_into_chunks=lambda text, **kw: text.split("|"))
    exec(compile(ast.Module(body=NODES, type_ignores=[]), "engine.py", "exec"), scope)
    scope["T"] = scope["STRINGS"]["en"]
    return scope


class SpeechTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(prefix="talking-tom-tts-")
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)
        self.scope = load_scope(self.root)

    def test_real_connector_failures_are_classified_without_urls(self):
        connection = NS(host="speech.platform.bing.com", port=443, ssl=True)
        errors = [
            (aiohttp.ClientConnectorDNSError(connection, socket.gaierror(-2, "dns")), "DNS"),
            (aiohttp.ClientConnectorCertificateError(connection, ssl.SSLCertVerificationError("cert")), "secure"),
            (aiohttp.ServerTimeoutError("timeout"), "timed out"),
            (aiohttp.WSServerHandshakeError(
                NS(real_url="https://example.com/?token=secret"), (), status=403,
                message="rejected"), "rejected"),
            (RuntimeError("https://example.com/?token=secret"), "could not complete"),
        ]
        for error, expected in errors:
            with self.subTest(error=type(error).__name__):
                message = self.scope["_tts_error_message"](error)
                self.assertIn(expected, message)
                self.assertNotIn("secret", message)
                self.assertNotIn("https://", message)

    def test_spanish_error_is_localized(self):
        self.scope["T"] = self.scope["STRINGS"]["es"]
        message = self.scope["_tts_error_message"](socket.gaierror(-2, "dns"))
        self.assertIn("Falló la búsqueda DNS", message)
        self.assertNotIn("Check your", message)

    async def test_retry_only_failed_piece_and_discard_partial_audio(self):
        calls = []
        async def save(piece, voice, rate, path, stop):
            calls.append(piece)
            if calls == ["one", "two"]:
                path.write_bytes(b"incomplete")
                raise TimeoutError()
            path.write_bytes(piece.encode())
        self.scope["_save_piece"] = save
        out = self.root / "out.mp3"
        with patch.object(asyncio, "sleep", new=unittest.mock.AsyncMock()):
            await self.scope["_edge_generate"]("one|two", "voice", "+0%", str(out))
        self.assertEqual(calls, ["one", "two", "two"])
        self.assertEqual(out.read_bytes(), b"onetwo")
        self.assertEqual(sorted(p.name for p in self.root.iterdir()), ["out.mp3"])

    async def test_failure_is_bounded_and_cleans_partial_files(self):
        calls = []
        async def save(piece, voice, rate, path, stop):
            calls.append(piece)
            path.write_bytes(b"partial")
            raise socket.gaierror(-2, "dns")
        self.scope["_save_piece"] = save
        with patch.object(asyncio, "sleep", new=unittest.mock.AsyncMock()) as sleep:
            with self.assertRaisesRegex(RuntimeError, "DNS"):
                await self.scope["_edge_generate"]("one", "voice", "+0%", str(self.root / "out.mp3"))
        self.assertEqual(len(calls), 3)
        self.assertLessEqual(sum(c.args[0] for c in sleep.call_args_list), 4.6)
        self.assertEqual(list(self.root.iterdir()), [])

    async def test_cancel_during_backoff_does_not_retry(self):
        calls = []
        stopped = False
        async def save(*args):
            calls.append(1)
            raise TimeoutError()
        async def stop(*args):
            nonlocal stopped
            stopped = True
        self.scope["_save_piece"] = save
        with patch.object(asyncio, "sleep", new=stop):
            with self.assertRaises(Cancelled):
                await self.scope["_edge_generate"]("one", "voice", "+0%", str(self.root / "out.mp3"),
                                                   should_stop=lambda: stopped)
        self.assertEqual(len(calls), 1)
        self.assertEqual(list(self.root.iterdir()), [])

    async def test_stop_cancels_the_active_synthesis_task(self):
        started = asyncio.Event()
        cancelled = asyncio.Event()
        stopped = False
        async def save(path):
            started.set()
            try:
                await asyncio.Future()
            finally:
                cancelled.set()
        self.scope["edge_tts"] = NS(Communicate=lambda *args, **kwargs: NS(save=save))
        task = asyncio.create_task(self.scope["_save_piece"](
            "one", "voice", "+0%", self.root / "out.mp3", lambda: stopped))
        await started.wait()
        stopped = True
        with self.assertRaises(Cancelled):
            await asyncio.wait_for(task, 1)
        self.assertTrue(cancelled.is_set())

    def test_source_setup_upgrades_legacy_speech_client(self):
        import sys
        command = unittest.mock.Mock()
        self.scope.update(IS_FROZEN=False, sys=NS(executable="python", exit=lambda code: None),
                          subprocess=NS(check_call=command, CalledProcessError=RuntimeError),
                          _module_available=lambda name: True)
        with patch.dict(sys.modules, edge_tts=NS(__version__="7.2.8")):
            self.scope["check_and_install_deps"]()
        self.assertIn("edge-tts>=7.3.0", command.call_args.args[0])
        command.reset_mock()
        with patch.dict(sys.modules, edge_tts=NS(__version__="7.3.0")):
            self.scope["check_and_install_deps"]()
        command.assert_not_called()


if __name__ == "__main__":
    unittest.main()
