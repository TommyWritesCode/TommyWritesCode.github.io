# PDF reading order in Talking Tom 2.4.0

## Problem and change

The previous `engine.extract_text` accepted pypdf's default extraction whenever
it returned any text. That followed PDF content-stream order, which need not
match visual reading order. A row-interleaved two-column PDF could alternate
between unrelated passages.

`pdf_layout.py` uses pdfplumber's word bounding boxes with `use_text_flow=False`.
It clusters visual lines, finds a repeated interior gutter with stable right
column starts, and emits the left column before the right within each region.
Full-width lines divide regions; isolated running headers/footers are emitted
outside column flow. Detected ruled tables spanning the gutter retain row order.
Consecutive full-width lines remain together. Each word is emitted exactly once;
no AI rewriting, summarization, or deletion occurs in this extraction stage.

`engine.py` retains the `(text, pages_without_text, total_pages)` return contract.
The existing worker and Swift UI need no protocol changes. Unsupported/corrupt
PDF errors surface through the existing error UI. Missing layout dependencies
produce an error, rather than silently reverting to the old bad reading order.

## Files and packaging

- `pdf_layout.py`: portable Python layout logic and PDF adapter.
- `engine.py`: switches PDF imports to the new reader.
- `worker.py`: disables bytecode-cache writes so app resources remain valid after signing.
- `test_pdf_layout.py`: 15 offline regression tests, including generated real PDF
  drawing streams, ruled tables, and a real worker process.
- `test_app_pdf.py`: verifies column order, page counts and code signature before/after bundle use.
- `package_release.py`: packages the verified app and integration source ZIPs.
- `requirements-pdf.txt`: exact dependency versions for a fresh environment.
- `pdf_vendor/`: dependencies and their license files, bundled for this existing
  macOS Apple Silicon / Python 3.12 app. Other platforms must install dependencies
  from the requirements file rather than reuse these platform-specific binaries.
- `build.py`: includes the reader and bundled dependencies; app version 2.4.0.
- `install.py`: backup and local install with rollback; reports version 2.4.0.
- `verification/pdf-layout-results.json`: real-paper audit results.

Run `/Users/tom-e/.talking_tom/venv/bin/python native/test_pdf_layout.py` from the
Talking Tom workspace. Also run `native/test_engine_concurrency.py` and
`native/test_worker_concurrency.py` with that interpreter. Build with
`python3 native/build.py`; the Xcode compiler may require access outside a sandbox.

## Verification

15 PDF regressions passed, including two columns, reverse/interleaved drawing
order, uneven lengths, off-center gutters, full-width abstract/section separators,
short author sidebars, single-column prose, headers/footers, ruled tables, blank
pages, malformed PDFs, plain text, and the worker response contract.

A separate audit processed 57 pages from three local papers and preserved all
34,509 pdfplumber-extracted words. It detected 21 two-column pages in Designing
meaningful human oversight in AI, and did not falsely split the 36 single-column
pages of the other two papers. The oversight title page and page 2 were rendered
and visually reviewed. Page 2's left-column ending ("coexist: AI systems...") now
precedes the right-column continuation ("the work, while humans..."). Audit word
preservation checks validate ordering-stage completeness, not the PDF decoder's
ability to recover every visible glyph. Signed-bundle extraction of all 21 pages
also passed. The final bundle passes signature checks both before and after extraction, with no bytecode cache writes. Existing engine and worker concurrency tests passed.

## Limits

This is geometric inference for left-to-right single/two-column papers, not a
semantic document understanding model. Very sparse, three-column, right-to-left,
borderless-table, unusual sidebar, or overlapping layouts may still need manual
review. Footnotes and captions are preserved but not semantically relocated.
Scans still need OCR: pages without extracted words retain the existing warning.
Previously imported text and generated recordings are unchanged; reimport the
PDF and regenerate audio to apply the fix. No paid speech/AI calls were made.

The app still requires the pre-existing ~/.talking_tom/venv runtime; this update
is not a new standalone installer. It is locally signed, not notarized for public
distribution. Website integration should port the source or use its existing
release/signing pipeline.

References:
- https://github.com/jsvine/pdfplumber/blob/stable/README.md
- https://pypdf.readthedocs.io/en/6.18.1/user/extract-text.html
