"""Install the verified local update, preserving the old app for rollback."""
from pathlib import Path
import shutil, datetime, subprocess, plistlib
if subprocess.run(['pgrep','-x','TalkingTom'],capture_output=True).returncode == 0:
 raise SystemExit('Talking Tom is running. Quit it after active work finishes, then rerun install.py.')
source=Path('/private/tmp/talking-tom-native-build/Talking Tom.app')
destination=Path.home()/'Applications/Talking Tom.app'
subprocess.run(['codesign','--verify','--deep','--strict',str(source)],check=True)
backup=Path.home()/'.talking_tom/backups'/('before-performance-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
backup.mkdir(parents=True)
shutil.copytree(destination,backup/'Talking Tom.app')
try:
 shutil.rmtree(destination/'Contents')
 shutil.copytree(source/'Contents',destination/'Contents')
 subprocess.run(['codesign','--verify','--deep','--strict',str(destination)],check=True)
except BaseException:
 shutil.rmtree(destination/'Contents',ignore_errors=True)
 shutil.copytree(backup/'Talking Tom.app/Contents',destination/'Contents')
 raise
print('Installed Talking Tom '+plistlib.loads((destination/'Contents/Info.plist').read_bytes())['CFBundleShortVersionString'])
print('Backup:',backup)
