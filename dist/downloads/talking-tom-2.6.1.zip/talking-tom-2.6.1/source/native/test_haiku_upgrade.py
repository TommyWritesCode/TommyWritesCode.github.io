"""Offline contracts for Haiku 5.5, visual retries and omitted charts."""
import io,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import claude_io as c,model_routing as r,pdf_narration as v,engine as e
from PIL import Image
from test_ai_streaming import Stream
from test_visual_narration import answer,visual,SAMPLES

class UpgradeTests(unittest.TestCase):
 def setUp(self):
  self.path=SAMPLES/'graph-and-appendix.pdf';self.page=v.inspect_pages(self.path)[0]
  self.good={'visuals':[visual('Figure 1',[70,310,930,755])],'needs_more_reasoning':False}
 def test_request_and_thinking_blocks(self):
  stream=Stream('Answer');stream.response.content.insert(0,NS(type='thinking',thinking=''))
  with patch('anthropic.Anthropic') as factory:
   client=factory.return_value;client.messages.stream.return_value=stream
   result=c.message(client,model=r.HAIKU,system='system',content='data',max_tokens=400,effort='high')
   request=client.messages.stream.call_args.kwargs
   self.assertEqual(request['thinking'],{'type':'adaptive'})
   self.assertEqual(request['output_config'],{'effort':'high'})
   self.assertGreater(request['max_tokens'],2400)
   self.assertNotIn('temperature',request);self.assertEqual(c.text(result),'Answer')
 def test_sonnet_request_stays_compatible(self):
  with patch('anthropic.Anthropic') as factory:
   client=factory.return_value;client.messages.stream.return_value=Stream()
   c.message(client,model=r.SONNET,system='s',content='c',max_tokens=8000)
   self.assertNotIn('output_config',client.messages.stream.call_args.kwargs)
   self.assertEqual(client.messages.stream.call_args.kwargs['max_tokens'],8000)
 def test_saved_haiku_migrates(self):
  with patch.object(c,'message',side_effect=AssertionError('router called')):
   self.assertEqual(r.choose_models('text','key','claude-haiku-4-5')['prose'],r.HAIKU)
  self.assertEqual(e._migrate_model_id('claude-haiku-4-5'),r.HAIKU)
 def test_distinct_dotted_figure_labels(self):
  self.assertNotEqual(v.canonical('Figure 8.9.1.A'),v.canonical('Figure 8.9.1.B'))
 def test_empty_and_partial_caption_coverage(self):
  with self.assertRaisesRegex(ValueError,'Missing captioned'):
   v.validate_analysis({'visuals':[],'needs_more_reasoning':False},self.page)
  page=dict(self.page,text=self.page['text']+'\nTable 2: Other results.',labels=self.page['labels']+['table 2'])
  with self.assertRaisesRegex(ValueError,'table 2'):v.validate_analysis(self.good,page)
 def test_high_effort_crop_retry_before_sonnet(self):
  weak=dict(self.good,needs_more_reasoning=True)
  with tempfile.TemporaryDirectory() as d,patch.object(c,'client'),patch.object(c,'message',side_effect=[answer(weak),answer(self.good)]) as call:
   result=v.analyze_page(self.path,self.page,'key',r.HAIKU,'en',Path(d),True,lambda:None,None)
   self.assertEqual(result,self.good)
   self.assertEqual([x.kwargs['model'] for x in call.call_args_list],[r.HAIKU,r.HAIKU])
   self.assertEqual([x.kwargs['effort'] for x in call.call_args_list],['medium','high'])
   self.assertEqual(sum(x['type']=='image' for x in call.call_args.kwargs['content']),2)
 def test_manual_haiku_never_escalates_to_sonnet(self):
  weak=dict(self.good,needs_more_reasoning=True)
  with tempfile.TemporaryDirectory() as d,patch.object(c,'client'),patch.object(c,'message',return_value=answer(weak)) as call:
   with self.assertRaisesRegex(RuntimeError,'still needs review'):
    v.analyze_page(self.path,self.page,'key',r.HAIKU,'en',Path(d),False,lambda:None,None)
   self.assertEqual(call.call_count,2);self.assertFalse(list(Path(d).glob('*.json')))
 def test_refusal_is_not_retried_or_cached(self):
  with tempfile.TemporaryDirectory() as d,patch.object(c,'client'),patch.object(c,'message',return_value=answer({},'refusal')) as call:
   with self.assertRaisesRegex(RuntimeError,'refusal'):
    v.analyze_page(self.path,self.page,'key',r.HAIKU,'en',Path(d),True,lambda:None,None)
   self.assertEqual(call.call_count,1);self.assertFalse(list(Path(d).glob('*.json')))
 def test_truncated_output_retried_with_more_budget(self):
  with tempfile.TemporaryDirectory() as d,patch.object(c,'client'),patch.object(c,'message',side_effect=[answer({},'max_tokens'),answer(self.good)]) as call:
   v.analyze_page(self.path,self.page,'key',r.HAIKU,'en',Path(d),True,lambda:None,None)
   self.assertGreater(call.call_args.kwargs['max_tokens'],call.call_args_list[0].kwargs['max_tokens'])
 def test_full_page_and_crop_resolution(self):
  for box in (None,[70,310,930,755]):
   with Image.open(io.BytesIO(v.render_page(self.path,1,box))) as im:
    self.assertLessEqual(max(im.size),2577);self.assertLess(im.width*im.height,3_510_000)
    self.assertGreater(max(im.size),2000)

if __name__=='__main__':unittest.main()
