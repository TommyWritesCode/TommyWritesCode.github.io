"""Package current workers with a verified app; reuse Swift for Python-only updates."""
import argparse
import hashlib
import json
from pathlib import Path
import plistlib
import shutil
import struct
import subprocess

VERSION = "2.6.1"
BUILD_NUMBER = "261"
MINIMUM_MACOS = "26.0"
WORKERS = ("engine.py", "worker.py", "pdf_layout.py", "claude_io.py",
           "model_routing.py", "pdf_narration.py")


def verify_native_target(executable):
    data = executable.read_bytes()
    magic, cpu, _, _, commands = struct.unpack_from("<IiiII", data)
    if (magic, cpu) != (0xFEEDFACF, 0x0100000C):
        raise RuntimeError("This installer requires an arm64 Mach-O executable.")
    offset = 32
    for _ in range(commands):
        command, size = struct.unpack_from("<II", data, offset)
        if command == 0x32:
            platform, minimum = struct.unpack_from("<II", data, offset + 8)
            if platform != 1:
                raise RuntimeError("Expected a macOS native executable.")
            version = f"{minimum >> 16}.{(minimum >> 8) & 255}"
            if version != MINIMUM_MACOS:
                raise RuntimeError(f"Installer requires macOS {MINIMUM_MACOS}, binary targets {version}.")
            return
        offset += size
    raise RuntimeError("Native executable does not declare its minimum macOS version.")


def package(native_app, destination):
    root = Path(__file__).resolve().parent
    native_app = Path(native_app).resolve()
    subprocess.run(["codesign", "--verify", "--deep", "--strict", str(native_app)], check=True)
    info = plistlib.loads((native_app / "Contents/Info.plist").read_bytes())
    if info.get("CFBundleIdentifier") != "com.tommynicol.talking-tom":
        raise RuntimeError("Expected the verified Talking Tom native app.")
    executable = native_app / "Contents/MacOS/TalkingTom"
    verify_native_target(executable)
    if (root / "Main.swift").stat().st_mtime > executable.stat().st_mtime:
        raise RuntimeError("Swift source changed after the native build; compile before packaging.")
    destination = Path(destination).resolve()
    installer = destination / f"talking-tom-{VERSION}"
    if installer.exists():
        raise FileExistsError(f"Release staging already exists: {installer}")
    installer.mkdir(parents=True)
    app = installer / "Talking Tom.app"
    shutil.copytree(native_app, app, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"))
    for name in WORKERS:
        shutil.copy2(root / name, app / "Contents/Resources" / name)
    info.update(CFBundleShortVersionString=VERSION, CFBundleVersion=BUILD_NUMBER,
                LSMinimumSystemVersion=MINIMUM_MACOS)
    (app / "Contents/Info.plist").write_bytes(plistlib.dumps(info))
    subprocess.run(["codesign", "--force", "--deep", "--sign", "-", str(app)], check=True)
    subprocess.run(["codesign", "--verify", "--deep", "--strict", str(app)], check=True)
    for path in (root / "release-installer").iterdir():
        if path.is_file():
            shutil.copy2(path, installer / path.name)
    (installer / "setup.command").chmod(0o755)
    source = installer / "source/native"
    source.mkdir(parents=True)
    names = set(WORKERS) | {"Main.swift", "build.py", "install.py", "package_release.py",
                           "requirements-tts.txt", "requirements-pdf.txt", "README.md",
                           "PERFORMANCE.md", "PDF_LAYOUT.md"}
    names.update(p.name for p in root.glob("test_*.py"))
    for name in sorted(names):
        shutil.copy2(root / name, source / name)
    shutil.copytree(root / "release-installer", source / "release-installer")
    fixtures = source / "verification/visual-narration"
    fixtures.mkdir(parents=True)
    for name in ("graph-and-appendix.pdf", "table-and-diagram.pdf", "make_samples.py"):
        shutil.copy2(root / "verification/visual-narration" / name, fixtures / name)
    assets = source / "assets"
    assets.mkdir()
    for name in ("icon.icns", "header.png"):
        shutil.copy2(app / "Contents/Resources" / name, assets / name)
    manifest = {
        "version": VERSION, "architecture": "arm64", "minimum_macos": MINIMUM_MACOS,
        "base_native_binary_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
        "packaged_native_binary_sha256": hashlib.sha256((app / "Contents/MacOS/TalkingTom").read_bytes()).hexdigest(),
        "swift_source_sha256": hashlib.sha256((root / "Main.swift").read_bytes()).hexdigest(),
        "worker_sha256": {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                          for name in WORKERS},
    }
    (installer / "release.json").write_text(json.dumps(manifest, indent=2) + "\n")
    archive = destination / f"talking-tom-{VERSION}.zip"
    subprocess.run(["ditto", "-c", "-k", "--sequesterRsrc", "--keepParent",
                    str(installer), str(archive)], check=True)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (destination / "SHA256SUMS.txt").write_text(f"{digest}  {archive.name}\n")
    print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size,
                      "sha256": digest, "app": str(app)}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native-app", type=Path,
                        default=Path("/private/tmp/talking-tom-native-build/Talking Tom.app"))
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent.parent / "releases" / VERSION)
    args = parser.parse_args()
    package(args.native_app, args.output)
