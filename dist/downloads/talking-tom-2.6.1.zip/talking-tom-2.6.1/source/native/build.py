from pathlib import Path
import shutil, plistlib, subprocess
from package_release import VERSION, BUILD_NUMBER, MINIMUM_MACOS
root=Path(__file__).resolve().parent
subprocess.run(['swiftc','-target',f'arm64-apple-macosx{MINIMUM_MACOS}','-O','-whole-module-optimization','-parse-as-library',str(root/'Main.swift'),'-o',str(root/'TalkingTom'),'-framework','SwiftUI','-framework','AppKit','-framework','AVFoundation','-framework','MediaPlayer','-module-cache-path','/private/tmp/talking-tom-module-cache'],check=True)
app=Path('/private/tmp/talking-tom-native-build/Talking Tom.app')
contents=app/'Contents'
if contents.exists():shutil.rmtree(contents)
for p in ['MacOS','Resources']:(contents/p).mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'TalkingTom',contents/'MacOS/TalkingTom')
for f in ['engine.py','worker.py','pdf_layout.py','claude_io.py','model_routing.py','pdf_narration.py']:shutil.copy2(root/f,contents/'Resources'/f)
vendor=root/'pdf_vendor'
if not vendor.exists():vendor=root.parent.parent/'Talking Tom.app/Contents/Resources/pdf_vendor'
shutil.copytree(vendor,contents/'Resources/pdf_vendor',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','bin'))
assets=root/'assets'
if not assets.exists():assets=Path.home()/'.talking_tom/app'
for f in ['icon.icns','header.png']:shutil.copy2(assets/f,contents/'Resources'/f)
info={'CFBundleIdentifier':'com.tommynicol.talking-tom','CFBundleName':'Talking Tom','CFBundleDisplayName':'Talking Tom','CFBundleExecutable':'TalkingTom','CFBundleIconFile':'icon.icns','CFBundlePackageType':'APPL','CFBundleShortVersionString':VERSION,'CFBundleVersion':BUILD_NUMBER,'LSMinimumSystemVersion':MINIMUM_MACOS,'NSHighResolutionCapable':True,'NSHumanReadableCopyright':'Talking Tom • Tommy Nicol','CFBundleDocumentTypes':[{'CFBundleTypeName':'Documents and Audio','CFBundleTypeRole':'Viewer','LSHandlerRank':'Alternate','LSItemContentTypes':['com.adobe.pdf','public.plain-text','org.openxmlformats.wordprocessingml.document','public.mp3','com.microsoft.waveform-audio','public.mpeg-4-audio']}]}
(contents/'Info.plist').write_bytes(plistlib.dumps(info))
subprocess.run(['xattr','-dr','com.apple.FinderInfo',str(app)],capture_output=True)
subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True)
print(app)
