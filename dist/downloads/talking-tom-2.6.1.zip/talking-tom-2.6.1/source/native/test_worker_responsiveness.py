"""Verify that a slow worker reading a large pipe cannot block the UI actor."""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parent
source=(root/'Main.swift').read_text().split('@main struct TalkingTomApp')[0]
source+='''
@main struct WorkerResponsivenessTests {
 @MainActor static func main() async {
  let folder = URL(fileURLWithPath:CommandLine.arguments[1])
  let model = Model(draftURL:folder.appendingPathComponent("draft.json"),restore:false)
  model.loadingDraft = true
  let text = String(repeating:"Large document sent to a worker. ",count:100_000)
  let start = CFAbsoluteTimeGetCurrent()
  model.run(["operation":"clean","text":text])
  let returnTime = (CFAbsoluteTimeGetCurrent()-start)*1000
  precondition(returnTime < 100,"Worker startup blocked the UI")
  try! await Task.sleep(for:.milliseconds(50))
  let eventTime = (CFAbsoluteTimeGetCurrent()-start)*1000
  precondition(model.busy && eventTime < 250,"Worker pipe blocked the main actor")
  for _ in 0..<1_000 {
   if !model.busy { break }
   try! await Task.sleep(for:.milliseconds(10))
  }
  precondition(!model.busy && model.error == nil && model.text == text)
  model.wordCountTask?.cancel(); model.draftWork?.cancel()
  print("PASS: 3.2 MB worker request returned in \\(returnTime) ms; main-actor event ran at \\(eventTime) ms while worker delayed reading by 500 ms; complete result received")
 }
}
'''
with tempfile.TemporaryDirectory(prefix='tom-worker-response-') as folder:
 p=Path(folder);(p/'Tests.swift').write_text(source)
 (p/'worker.py').write_text('import time,sys,json\ntime.sleep(0.5)\nq=json.loads(sys.stdin.readline())\nprint(json.dumps({"type":"result","text":q["text"]}),flush=True)\n')
 subprocess.run(['swiftc','-O','-parse-as-library',str(p/'Tests.swift'),'-o',str(p/'Tests'),'-module-cache-path','/private/tmp/talking-tom-module-cache'],check=True)
 subprocess.run([str(p/'Tests'),folder],check=True)
