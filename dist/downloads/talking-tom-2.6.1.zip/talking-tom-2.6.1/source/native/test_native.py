from pathlib import Path
import subprocess, tempfile, wave
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='talking-tom-tests-') as folder:
 p=Path(folder)
 with wave.open(str(p/'fixture.wav'),'w') as audio:
  audio.setnchannels(1);audio.setsampwidth(2);audio.setframerate(8000);audio.writeframes(b'\0\0'*8000*60)
 source=(root/'Main.swift').read_text().split('@main struct TalkingTomApp')[0]
 source+='''
@main struct SessionTests {
 @MainActor static func main() async {
  let root = URL(fileURLWithPath:CommandLine.arguments[1])
  let session = AppSession(stateDirectory:root,installMedia:false)
  let first = session.active
  first.text = "First independent draft"; first.title = "First"
  first.sourcePDF = root.appendingPathComponent("fixture.pdf").path; first.visualsPrepared = true
  first.translateVisuals = true; first.aiModel = "auto"
  session.newTab(); let second = session.active
  precondition(first !== second && second.text.isEmpty)
  precondition(second.sourcePDF.isEmpty && !second.visualsPrepared && second.translateVisuals && second.aiModel == "auto")
  second.text = "Second independent draft"; second.title = "Second"
  first.busy = true
  session.newTab(); let third = session.active
  precondition(!third.busy && first.busy)
  first.busy = false
  session.closeTab(third)
  precondition(session.tabs.count == 2)
  let audio = root.appendingPathComponent("fixture.wav")
  first.loadAudio(root.appendingPathComponent("missing.wav"))
  first.loadAudio(audio); second.loadAudio(audio)
  while first.audioLoading || second.audioLoading { try! await Task.sleep(for:.milliseconds(10)) }
  precondition(first.error == nil && first.audioURL == audio, "Stale audio load replaced the latest selection")
  first.player?.volume = 0; second.player?.volume = 0
  first.togglePlayback(); first.seek(12)
  precondition(first.playing)
  second.togglePlayback()
  precondition(second.playing && !first.playing && first.player?.isPlaying == false)
  precondition(first.timer == nil && second.timer != nil)
  precondition(abs(first.position - 12) < 0.5)
  second.seek(25)
  first.togglePlayback()
  precondition(first.playing && !second.playing && second.player?.isPlaying == false)
  precondition(abs(second.position - 25) < 0.5)
  session.select(second.id)
  precondition(session.mediaTarget === first)
  session.mediaAction("toggle"); precondition(!first.playing)
  session.mediaAction("forward"); precondition(abs(first.position - 27) < 0.5)
  session.mediaAction("back"); precondition(abs(first.position - 12) < 0.5)
  session.mediaAction("play"); precondition(first.playing)
  session.mediaAction("play"); precondition(first.playing)
  session.mediaAction("pause"); precondition(!first.playing)
  second.seek(second.duration); second.atEnd = true; second.togglePlayback()
  precondition(second.playing && !second.atEnd && second.position < 0.5)
  second.pausePlayback()
  precondition(session.tabs.allSatisfy { $0.timer == nil })
  for _ in 0..<30 { first.changeZoom(0.1) }; precondition(first.zoom == 2 && second.zoom == 1)
  for _ in 0..<30 { first.changeZoom(-0.1) }; precondition(first.zoom == 0.75)
  first.flushDraft(); second.flushDraft(); session.saveSession(flush:true)
  let restored = AppSession(stateDirectory:root,installMedia:false)
  precondition(restored.tabs.count == 2)
  precondition(restored.tabs[0].text == first.text && restored.tabs[1].text == second.text)
  precondition(restored.selectedID == second.id)
  precondition(restored.tabs[0].sourcePDF == first.sourcePDF && restored.tabs[0].visualsPrepared)
  precondition(restored.tabs[1].sourcePDF.isEmpty && !restored.tabs[1].visualsPrepared)
  session.moveTab(1); precondition(session.active === first)
  session.moveTab(-1); precondition(session.active === second)
  for tab in session.tabs + restored.tabs { tab.timer?.invalidate(); tab.draftWork?.cancel() }
  print("PASS: independent tabs/tasks/drafts, restoration, tab navigation, exclusive playback, position preservation, media routing, seek/replay, bounded per-tab zoom")
 }
}
'''
 (p/'Tests.swift').write_text(source)
 subprocess.run(['swiftc','-O','-parse-as-library',str(p/'Tests.swift'),'-o',str(p/'Tests'),'-framework','SwiftUI','-framework','AppKit','-framework','AVFoundation','-framework','MediaPlayer','-module-cache-path','/private/tmp/talking-tom-module-cache'],check=True)
 subprocess.run([str(p/'Tests'),folder],check=True)
