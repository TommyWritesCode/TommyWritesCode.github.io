# Talking Tom 2.6.1

Native macOS app, updated from the September 18 Swift implementation. Source is now in this folder; the installed app is `~/Applications/Talking Tom.app`.

- Command-T creates an independent workspace tab. Command-W closes the selected tab, confirming before discarding text. A busy tab must be cancelled before closing. Command-Shift-[ / ] switches tabs. Drafts and open tabs restore at launch.
- Each tab owns its document, generation/cleanup process, voice options, recording, playback position and zoom. Shared language/API settings remain app-wide.
- Starting playback pauses all other tabs synchronously before playing. Changing tabs does not interrupt playback. Media keys control the last-played recording; each tab's playback buttons and Playback menu control that tab.
- Command-plus (including Command-equals), Command-minus and Command-0 zoom/reset the workspace. View-menu commands expose the same actions. Zoom ranges from 75% to 200%; the layout reflows and scrolls when needed. System window chrome stays its normal size.
- F7/F9 skip backward/forward using the existing 15-second controls; F8 toggles playback. Ordinary function-key events work when Talking Tom is focused. macOS media-key events use Media Player's remote-command and Now Playing APIs, including background playback controls.
- Simultaneous generation reserves unique output filenames atomically, including when titles match.

## Website release

The 2.6.1 installer supports Apple Silicon and macOS 26 or newer. It includes
its private runtime setup, current workers, source, and bilingual instructions.
The previous app/runtime are backed up and restored if installation fails.
The app is locally signed, not Developer ID signed or notarized.

For a Python-only update, run `python3 package_release.py --native-app` with the
path of the verified existing app. The packager refuses to reuse a native build
older than `Main.swift`. It writes `releases/2.6.1/talking-tom-2.6.1.zip` and
SHA-256 checksums. See `release-installer/README.md` and `README.es.md`.
The included source build reuses PDF dependencies from the adjacent app and
ships its own icon assets; rebuilding Swift requires the Apple toolchain.

## Build and install

`python3 build.py` compiles with the installed Apple Swift toolchain, assembles `/private/tmp/talking-tom-native-build/Talking Tom.app`, and signs it locally. It reuses the existing icon assets in `~/.talking_tom/app`. `python3 install.py` backs up the installed app under `~/.talking_tom/backups` and replaces its Contents with rollback on failure. Quit Talking Tom before installing, then reopen it.

The worker uses the existing `~/.talking_tom/venv` environment. Settings remain in `~/.talking_tom/config.json`, drafts in that directory and its `drafts` subdirectory, and recordings in `~/Talking Tom`. No credentials are bundled. This is a locally signed build, not a notarized distribution.

Speech requires **edge-tts 7.3.0 or newer**. Microsoft changed the service's
authentication in October 2026; older clients can receive HTTP 403 even with a
working internet connection. Install the compatible dependency in the worker's
environment with `~/.talking_tom/venv/bin/python -m pip install -r requirements-tts.txt`
from this directory. Source-mode dependency setup also upgrades older clients.
See the [upstream outage resolution](https://github.com/rany2/edge-tts/issues/490).

The speech engine now distinguishes DNS, certificate, timeout, service rejection
and other failures in English and Spanish, without displaying token-bearing
request URLs. Retries still apply only to the failed chunk, with no delay after
the final failure. `~/.talking_tom/venv/bin/python test_tts.py` runs seven offline
regressions for these errors, partial audio recovery, bounded retries,
cancellation and upgrading an incompatible client.

Live verification on October 21, 2026 used the installed app and its existing
edge-tts 7.3.0 environment: a five-second recording played successfully, and a
3,740-word document completed all four chunks and loaded as a 21:08 recording.
Its transcript retained the first and last sections, and temporary chunks were
removed. The original voice-service failure was not reproduced in the app.
Command-line DNS access is restricted in the agent environment; that failure
must not be treated as evidence that the installed app cannot reach Microsoft.
The seven speech regressions, engine/worker concurrency checks, and production
worker error-protocol check passed. The new source error messages are not yet
in the installed bundle: the native rebuild was blocked by the compiler macro
sandbox (`sandbox_apply: Operation not permitted`).

## Verification

`python3 test_native.py` uses temporary draft storage and silent generated audio to test independent tabs and task state, draft restoration, tab navigation, exclusive playback and position preservation, media-command routing, seek/replay, and per-tab zoom bounds. macOS audio-service access is required.

`python3 test_worker_concurrency.py` exercises eight real worker processes with an offline speech-engine stand-in, verifying separate audio/transcript output for identical titles. It does not call speech or paid AI services.

Design references: [Apple keyboard guidance](https://developer.apple.com/design/human-interface-guidelines/keyboards), [designing for macOS](https://developer.apple.com/design/human-interface-guidelines/designing-for-macos/), [MPRemoteCommandCenter](https://developer.apple.com/documentation/MediaPlayer/MPRemoteCommandCenter), and [Now Playing playback state](https://developer.apple.com/documentation/mediaplayer/mpnowplayinginfocenter/playbackstate).

`python3 test_engine_concurrency.py` runs the production chunk assembly and cleanup function with offline chunk synthesis: eight concurrent multi-chunk recordings plus a ninth cancelled job. It verifies intact outputs and isolated cleanup. Temporary chunks now live in a private per-job directory.

All three automated checks passed. Installed-bundle signature verification passed and the app launched. Direct visual verification and physical media-key testing remain unverified because the desktop-control tool could not select the running Talking Tom app.

## Performance update (2.2.0)

See [PERFORMANCE.md](PERFORMANCE.md) for measured bottlenecks, implementation changes, repeatable tests, and Apple documentation. The normal, zoomed, and compact layouts were rendered and inspected in native offscreen test windows. Release builds now enable compiler optimization.

## Window layout update (2.3.0)

Narrow and tall regular windows always retain the document above playback; window width never implicitly enables mini mode. Use the inward-arrow button in the player or toolbar (or Command-Shift-M) to collapse to a 360 × 110 point content area plus standard macOS window chrome. Mini mode keeps numbered tab icons, speed, skip, play/pause and timeline controls, and an outward-arrow restore button. Its height is constrained to avoid empty space. Restore returns to the previous regular window frame. Window mode is shared across tabs.

Native offscreen layout checks verify narrow-tall document space, the compact height, mode preservation across tab switches, and exact window-frame restoration.

## PDF reading order update (2.4.0)

PDF imports now use word coordinates to detect two-column layouts and read each
column top to bottom, left before right. Full-width passages divide regions;
isolated page headers and footers stay outside the column flow; ruled tables
retain row order. All extracted words are preserved. This runs locally without
AI services. Reopen the original PDF to replace previously imported text.

See [PDF_LAYOUT.md](PDF_LAYOUT.md) for architecture, dependencies, tests, and
known limits. `test_pdf_layout.py` covers 15 offline regressions including real
PDF files through the worker protocol. The signed app bundle was also tested
against the 21-page oversight paper. The three-paper, 57-page geometry audit is
recorded in `verification/pdf-layout-results.json`.


## Long cleanup and translation requests (2.4.1)

Claude cleanup and translation now use streaming for every section, following
[Anthropic’s long-request guidance](https://platform.claude.com/docs/en/api/errors#long-requests).
The former non-streaming calls had a 30-second timeout. Streaming now allows
120 seconds between network reads, with a 15-second connection timeout. Failed
connections, incomplete streams and transient server errors retry only the current
section, up to three total attempts. Partial responses are discarded. Cancellation
is checked between stream events and during retry waits; a stalled read remains
bounded by the read timeout.

An output-token limit triggers smaller sections instead of silently saving truncated
text. Long OCR passages without sentence breaks also obey the 9,000-character input
limit. Unexpected stop reasons fail visibly. Prompts and dialogues quoted within a
paper are explicitly treated as document content to translate, never instructions
to execute. Completed results are returned only after every section succeeds.

`~/.talking_tom/venv/bin/python test_ai_streaming.py` runs 11 offline regressions
covering streaming, Spanish instructions, interrupted responses, bounded retries,
authentication failures, mid-stream overload, cancellation, chunk ordering,
truncation recovery and unpunctuated input. Engine and worker concurrency tests
also pass. No new dependencies are required.


## Visual narration and Auto model selection (2.5.0)

The right-hand narration controls now include **Translate visuals** (off by default)
and **Model** (Auto, Haiku, or Sonnet). Visuals can be explained in the original
language as well as translated. When unchecked, no PDF pages are sent for analysis.

Auto performs one small, cached Haiku assessment using at most 4,800 excerpt
characters. It chooses prose and visual models independently, normally retaining
Haiku for simple work. Complex reasoning and quoted experimental prompts can use
Sonnet. An inconclusive assessment conservatively selects Sonnet. A visual Haiku
analysis can escalate once to Sonnet when it reports unresolved complexity,
unreadability, or invalid output. Explicit model choices bypass routing.

PDF imports retain a local source copy and store its attachment in the tab draft.
When visuals are requested, candidate pages are rendered locally and the actual
page images are analyzed, not merely extracted captions. Summaries describe what
is measured, key comparisons, readable values, uncertainty and limitations. They
identify the original figure/table and physical PDF page. Their length depends on
complexity. Unreadable details are identified rather than guessed. Analysis caches
are keyed by PDF contents, page, model, language and prompt version.

The app removes visual/table text using page geometry and inserts a protected
summary after the first referencing sentence, then resumes the prose. An
unnumbered diagram can anchor to its introductory sentence; otherwise an
unreferenced main-paper visual is explained at the end of its page's prose.
Appendix visuals are included only when their label or appendix is referenced in
the main paper. Navigation-only repeated parenthetical references are suppressed.
Duplicate figure labels are narrated once. Completed drafts record that visuals
have already been prepared so later cleanup/translation does not insert them again.
Missing or repeated protected markers cause an error rather than a partial recording.

**Existing drafts need the original PDF reopened** because previous versions did
not retain it. Edited drafts are never silently replaced with text from their PDF:
reopen the PDF in a new tab or turn off visuals. Image-only PDFs still require OCR
for the body prose, as before. Caption detection, bounding boxes and appendix
boundaries are heuristic/model-assisted; unusual layouts can still need review.
Sources and cached analyses live under `~/.talking_tom/pdf_sources`,
`visual_analysis`, and `model_assessments` respectively.

Verification: 10 new offline narration/routing/opt-in regressions, 11 streaming
regressions, 15 PDF extraction regressions, native state/playback restoration,
window layout, engine/worker concurrency and signed-bundle extraction checks.
Live checks used two synthetic PDFs totaling three pages (a bar graph, tables,
a workflow diagram, repeated references and appendix filtering), in English and
Spanish; a small complex-text sample confirmed Auto chooses Sonnet. Cached visual
analysis was reused in the end-to-end worker test. See
`verification/visual-narration/` for fixtures, outputs and verification notes.

## Haiku 5.5 and chart narration (2.6.0)

Auto and saved Haiku selections now use `claude-haiku-5-5`. The existing Sonnet 5
option remains available. Cleanup and routing use low effort; visual analysis
starts at medium effort with adaptive thinking. Output allowances include room
for reasoning and the new tokenizer. Text is read by content-block type; refusals
and incomplete responses are never accepted as finished chart analyses.

Auto now lets Haiku inspect actual images before escalating visuals. PDF pages
are rendered within the new 2,576-pixel / approximately 3.5-megapixel image budget.
An incomplete or uncertain Haiku result gets one high-effort retry with up to four
source-rendered close-ups (two page halves if no valid bounds were returned),
then Auto can fall back once to Sonnet. Manual Haiku never silently switches to
Sonnet. Unresolved reasoning fails visibly; explicitly unreadable visuals retain
a spoken qualification. Unambiguous caption lines must have matching summaries.
Old route/visual caches are bypassed by version changes.

Chart prompts check panels, legend mapping, scale, units, percent versus percentage
points, approximate values and uncertainty without inventing significance. Dotted
figure labels such as 8.9.1.A remain distinct. Cleanup preserves figure-introduction
sentences and rejects reordered narration markers. Visuals remain opt-in; reopen
an original PDF in a new tab to regenerate an already-prepared draft.

Sources: [Haiku 5.5 system card](https://www.anthropic.com/claude-haiku-5-5-system-card),
[API migration guide](https://platform.claude.com/docs/en/models/haiku-5-5/migration-guide),
and [release/pricing](https://www.anthropic.com/claude-haiku-5-5).
The card's chart benchmark includes tool-assisted conditions that this bounded
crop pipeline does not reproduce; benchmark scores are not app accuracy claims.
See `verification/haiku-5-5/verification.md` for tests and remaining limits.
