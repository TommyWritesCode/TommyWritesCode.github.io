from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
out=Path(__file__).parent

def lines(c,rows,y=740):
 c.setFont('Helvetica',11)
 for row in rows:c.drawString(50,y,row);y-=17

def table(c,top,label,rows):
 lines(c,[label],top+24)
 xs=[50,245,390,550];height=26
 for i,row in enumerate(rows):
  y=top-i*height
  for j,cell in enumerate(row):c.drawString(xs[j]+7,y-18,str(cell))
 for i in range(len(rows)+1):c.line(50,top-i*height,550,top-i*height)
 for x in xs:c.line(x,top,x,top-len(rows)*height)

c=canvas.Canvas(str(out/'graph-and-appendix.pdf'),pagesize=(612,792))
lines(c,['Small research example: accuracy and latency',
 'We evaluated two systems on the same synthetic benchmark.',
 'Figure 1 compares their accuracy.',
 'The next paragraph discusses deployment costs.',
 'Table A1 reports the latency tradeoff.',
 'Additional protocol details are available (see Appendix A).',
 'We repeated the protocol (see Appendix A).',
 'The same procedure was retained (see Appendix A).'])
c.setFont('Helvetica',10)
x0,y0=110,270
c.line(x0,y0,x0,530);c.line(x0,y0,510,y0)
for value in [0,20,40,60,80,100]:
 y=y0+value*2.5;c.drawString(76,y-3,str(value));c.line(x0-3,y,x0+3,y)
c.saveState();c.translate(58,345);c.rotate(90);c.drawString(0,0,'Accuracy (%)');c.restoreState()
for x,value,label,color in [(190,60,'Baseline','#8492a6'),(350,80,'New method','#2364aa')]:
 c.setFillColor(HexColor(color));c.rect(x,y0,70,value*2.5,fill=1,stroke=0);c.setFillColor(HexColor('#000000'));c.drawString(x+22,y0+value*2.5+10,str(value));c.drawString(x-2,250,label)
lines(c,['Figure 1. Accuracy on the synthetic benchmark. No error bars are shown.'],215)
lines(c,['Our findings concern this benchmark only; generalization was not measured.'],155)
c.showPage()
lines(c,['Appendix A. Latency measurements','These measurements use one device and one batch size.'])
table(c,665,'Table A1. Latency and memory.',[['System','Latency (ms)','Memory (GB)'],['Baseline','40','2'],['New method','65','3']])
lines(c,['Appendix B. Additional unreferenced measurements'],480)
table(c,425,'Table B1. Extra ablation, not discussed in the main paper.',[['Variant','Accuracy (%)','Runs'],['Extra X','71','2'],['Extra Y','72','2']])
c.save()
c=canvas.Canvas(str(out/'table-and-diagram.pdf'),pagesize=(612,792))
lines(c,['Small research example: efficiency',
 'Table 1 compares quality with processing time.',
 'This sentence must resume immediately after the table explanation.',
 'As a reminder, the numbers use the same hardware (see Table 1).',
 'The workflow diagram below describes the processing stages.'])
table(c,610,'Table 1. Quality and processing time; larger quality is better.',[['System','Quality (%)','Time (s)'],['Small','82','1.2'],['Large','86','3.6']])
lines(c,['Unnumbered workflow diagram'],430)
for x,label in [(60,'Input PDF'),(245,'Analyze'),(430,'Narrate')]:
 c.roundRect(x,355,120,44,5);c.drawString(x+18,373,label)
for x in [180,365]:
 c.line(x,377,x+62,377);c.line(x+62,377,x+55,382);c.line(x+62,377,x+55,372)
lines(c,['The pipeline preserves the original prose and adds visual explanations.'],290)
c.save()
print('Created two synthetic PDFs, three pages total.')
