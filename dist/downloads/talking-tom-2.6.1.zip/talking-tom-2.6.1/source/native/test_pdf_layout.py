"""Offline regression tests using real PDF drawing streams and known reading order."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from collections import Counter
from pypdf import PdfWriter
from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject
from pdf_layout import order_words, extract_pdf


def word(text, x, y, width=None):
    return dict(text=text, x0=x, x1=x+(width or len(text)*5), top=y, bottom=y+10)


def line(text, x, y):
    result=[]
    for token in text.split():
        w=word(token,x,y);result.append(w);x=w['x1']+4
    return result


def columns(start=100, count=10, right=320):
    words=[]
    for i in range(count):
        words+=line(f'Left{i} has some useful text',50,start+i*14)
        words+=line(f'Right{i} has more useful text',right,start+i*14)
    return words


def make_pdf(path, pages):
    writer=PdfWriter()
    font=writer._add_object(DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica')}))
    for entries in pages:
        page=writer.add_blank_page(width=612,height=792)
        page[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):font})})
        stream=DecodedStreamObject()
        stream.set_data('\n'.join(f'BT /F1 10 Tf 1 0 0 1 {x} {792-y} Tm ({text}) Tj ET' for text,x,y in entries).encode())
        page[NameObject('/Contents')]=writer._add_object(stream)
    writer.write(path)


class ReadingOrderTests(unittest.TestCase):
    def ordered(self,words,**kw):
        text,layout=order_words(words,792,**kw)
        self.assertEqual(Counter(text.split()),Counter(w['text'] for w in words))
        return text,layout

    def test_interleaved_columns(self):
        text,layout=self.ordered(columns())
        self.assertEqual(layout,'two-column')
        self.assertLess(text.index('Left9'),text.index('Right0'))

    def test_reverse_drawing_order(self):
        text,_=self.ordered(list(reversed(columns())))
        self.assertLess(text.index('Left0'),text.index('Left9'))
        self.assertLess(text.index('Left9'),text.index('Right0'))

    def test_unequal_columns(self):
        words=columns()+line('LeftFinal continues here',50,250)
        text,_=self.ordered(words)
        self.assertLess(text.index('LeftFinal'),text.index('Right0'))

    def test_off_center_gutter(self):
        text,layout=self.ordered(columns(right=260))
        self.assertEqual(layout,'two-column')
        self.assertLess(text.index('Left9'),text.index('Right0'))

    def test_full_width_separator(self):
        words=columns(count=6)+[word('FULLWIDTH',50,210,500)]+columns(start=250,count=6)
        text,_=self.ordered(words)
        self.assertLess(text.index('Right5'),text.index('FULLWIDTH'))
        self.assertLess(text.index('FULLWIDTH'),text.rindex('Left0'))
        self.assertLess(text.rindex('Left5'),text.rindex('Right0'))

    def test_full_width_abstract_then_columns(self):
        words=[word('TITLE',50,30,500)]+[word(f'Abstract{i}',50,60+i*14,500) for i in range(12)]+columns(start=250)
        text,layout=self.ordered(words)
        self.assertEqual(layout,'two-column')
        self.assertLess(text.index('Abstract11'),text.index('Left0'))
        self.assertLess(text.index('Left9'),text.index('Right0'))

    def test_headers_and_footers_outside_flow(self):
        words=columns()+line('HEADER journal',50,25)+line('Issue forty',400,25)+line('FOOTER number',50,760)
        text,_=self.ordered(words)
        self.assertLess(text.index('Issue'),text.index('Left0'))
        self.assertLess(text.index('Right9'),text.index('FOOTER'))

    def test_single_column(self):
        words=[]
        for i in range(15):words+=line(f'Paragraph{i} ordinary prose running all the way across this single column of text.',50,50+i*14)
        text,layout=self.ordered(words)
        self.assertEqual(layout,'single-column-or-undetermined')
        self.assertLess(text.index('Paragraph0'),text.index('Paragraph14'))

    def test_ruled_table_row_order(self):
        text,_=self.ordered(columns(),table_boxes=[(40,90,590,250)])
        self.assertLess(text.index('Right0'),text.index('Left1'))

    def test_empty_and_sparse(self):
        self.assertEqual(order_words([],792),('','empty'))
        self.assertEqual(self.ordered(line('A small note',50,100))[1],'single-column-or-undetermined')

    def test_real_pdf_and_worker(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'columns.pdf'
            entries=[]
            for i in range(10):
                # Intentionally paint right first, interleaved row by row.
                entries.extend([(f'Right{i} contains several words',320,100+i*14),(f'Left{i} contains several words',50,100+i*14)])
            make_pdf(p,[entries,[],[('Last page stays last',50,100)]])
            text,skipped,total,layouts=extract_pdf(p)
            self.assertEqual((skipped,total),(1,3))
            self.assertEqual(layouts,['two-column','empty','single-column-or-undetermined'])
            self.assertLess(text.index('Left9'),text.index('Right0'))
            self.assertLess(text.index('Right9'),text.index('Last page'))
            run=subprocess.run([sys.executable,str(Path(__file__).with_name('worker.py'))],env=dict(os.environ,TALKING_TOM_STATE_DIR=str(p.parent/'state')),input=json.dumps({'operation':'extract','path':str(p)})+'\n',capture_output=True,text=True,check=True)
            result=json.loads(run.stdout.strip().splitlines()[-1])
            self.assertEqual(result['type'],'result')
            self.assertEqual((result['text'],result['skipped'],result['total']),(text,skipped,total))

    def test_title_page_with_short_author_sidebar(self):
        words=[word(f'Abstract{i}',50,70+i*14,500) for i in range(12)]
        for i in range(12):
            words+=line(f'Author{i}',50,300+i*14)
            words+=line(f'Intro{i} with several useful words',320,300+i*14)
        text,layout=self.ordered(words)
        self.assertEqual(layout,'two-column')
        self.assertLess(text.index('Abstract11'),text.index('Author0'))
        self.assertLess(text.index('Author11'),text.index('Intro0'))

    def test_real_ruled_table(self):
        from pypdf import PdfReader
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'table.pdf'
            entries=[]
            for i in range(10):
                entries.extend([(f'Left{i} has several words',50,100+i*14),(f'Right{i} has several words',320,100+i*14)])
            make_pdf(p,[entries])
            reader=PdfReader(p);writer=PdfWriter();writer.add_page(reader.pages[0])
            page=writer.pages[0];content=page.get_contents().get_data()
            rules=['40 560 m 580 560 l S','40 702 m 580 702 l S']
            rules += [f'{x} 560 m {x} 702 l S' for x in [40,300,580]]
            rules += [f'40 {y} m 580 {y} l S' for y in range(574,702,14)]
            stream=DecodedStreamObject();stream.set_data(content+b'\n'+'\n'.join(rules).encode())
            page[NameObject('/Contents')]=writer._add_object(stream)
            q=Path(d)/'ruled.pdf';writer.write(q)
            text,_,_,_=extract_pdf(q)
            self.assertLess(text.index('Right0'),text.index('Left1'))

    def test_invalid_pdf_errors(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.pdf';p.write_text('Not a PDF')
            with self.assertRaises(Exception):extract_pdf(p)

    def test_text_input_unchanged(self):
        import engine
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'plain.txt';p.write_text('One paragraph.\nAnother line.')
            self.assertEqual(engine.extract_text(p),('One paragraph.\nAnother line.',0,0))


if __name__=='__main__':unittest.main(verbosity=2)
