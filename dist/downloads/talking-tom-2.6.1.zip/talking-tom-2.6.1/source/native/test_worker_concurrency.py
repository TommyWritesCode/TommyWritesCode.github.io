"""Exercise the real worker protocol concurrently using an offline speech-engine stand-in."""
from pathlib import Path
import tempfile, shutil, subprocess, json, sys
with tempfile.TemporaryDirectory(prefix='talking-tom-workers-') as folder:
 root=Path(folder)
 shutil.copy2(Path(__file__).with_name('worker.py'),root/'worker.py')
 (root/'engine.py').write_text('''from pathlib import Path
import asyncio
STORAGE_DIR=Path(__file__).parent/'recordings'
STRINGS={'en':{}}
DEFAULT_VOICE='Test'
ALL_VOICES={'Test':'Test'}
SPEECH_RATES={'1.0x':'+0%'}
class Cancelled(Exception):pass
def _guess_lang(text):return 'en'
def _slugify(title):return title
def get_api_key():return ''
async def _edge_generate(text,voice,rate,path,progress,stop):
 await asyncio.sleep(0.15)
 if stop():raise Cancelled()
 Path(path).write_bytes(text.encode())
''')
 jobs=[]
 for index in range(8):
  payload={'operation':'generate','text':f'Tab {index}', 'title':'Same title','clean':'none','voice':'Test','rate':'1.0x'}
  job=subprocess.Popen([sys.executable,str(root/'worker.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  job.stdin.write(json.dumps(payload)+'\n');job.stdin.close();jobs.append(job)
 paths=[]
 for index,job in enumerate(jobs):
  result=json.loads(job.stdout.read()); errors=job.stderr.read();job.wait()
  assert job.returncode==0 and result['type']=='result',(result,errors)
  path=Path(result['path']);paths.append(path)
  assert path.read_text()==f'Tab {index}'
  assert path.with_suffix('.txt').read_text()==f'Tab {index}'
 assert len(set(paths))==8
 print('PASS: eight simultaneous workers with identical titles produce separate audio/transcript pairs')
