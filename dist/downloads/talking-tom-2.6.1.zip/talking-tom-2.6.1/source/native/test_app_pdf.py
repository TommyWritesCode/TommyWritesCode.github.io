"""Check the built/installed bundle's worker and signature after real PDF use."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
from test_pdf_layout import make_pdf

app=Path(sys.argv[1] if len(sys.argv)>1 else '/private/tmp/talking-tom-native-build/Talking Tom.app')
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
with tempfile.TemporaryDirectory() as folder:
    path=Path(folder)/'interleaved.pdf'
    entries=[]
    for i in range(10):
        entries += [(f'Right{i} contains several words',320,100+i*14),(f'Left{i} contains several words',50,100+i*14)]
    make_pdf(path,[entries,[]])
    result=subprocess.run([sys.executable,str(app/'Contents/Resources/worker.py')],env=dict(os.environ,TALKING_TOM_STATE_DIR=str(path.parent/'state')),input=json.dumps({'operation':'extract','path':str(path)})+'\n',text=True,capture_output=True,check=True)
    data=json.loads(result.stdout)
    assert data['type']=='result',data
    assert (data['total'],data['skipped'])==(2,1)
    assert data['text'].index('Left9')<data['text'].index('Right0')
assert not list((app/'Contents/Resources').rglob('__pycache__'))
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
print('PASS: app worker reads columns correctly; missing-text page count intact; no cache writes; signature valid before and after PDF extraction')
