#!/bin/bash
# Talking Tom - launcher.
# Normally you'd just open "Talking Tom" from your Applications folder. This is
# a fallback (and lets you pass a file:  ./run.command mypaper.pdf).

xattr -dr com.apple.quarantine "$(cd "$(dirname "$0")" && pwd)" 2>/dev/null || true

PY="$HOME/.talking_tom/venv/bin/python"
APP="$HOME/.talking_tom/app/talking_tom.py"

if [ ! -x "$PY" ]; then
  echo "Talking Tom isn't set up yet."
  echo "Right-click  setup.command  ->  Open  first."
  echo "Press return to close."
  read -r _
  exit 1
fi

exec "$PY" "$APP" "$@"
