#!/usr/bin/env python3
"""
Generate icon.icns (+ header.png) for Talking Tom.

Usage:  make_icon.py <out_dir> [source_image]

If a source image is given, or <out_dir>/logo_src.png exists, that picture is used
(squared + squircle-masked). Otherwise a headphones glyph is drawn as a fallback.
Requires Pillow + iconutil (macOS).
"""
import math
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageOps

NAVY = (0, 34, 102, 255)
NAVY_HI = (26, 74, 158, 255)
GOLD = (255, 184, 28, 255)
S = 1024


def squircle_mask(size, radius_frac=0.225):
    m = Image.new("L", (size, size), 0)
    r = int(size * radius_frac)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size - 1, size - 1], radius=r, fill=255)
    return m


def from_source(path: Path) -> Image.Image:
    img = Image.open(path).convert("RGBA")
    img = ImageOps.fit(img, (S, S), method=Image.LANCZOS)   # center-crop to square
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.paste(img, (0, 0), squircle_mask(S))
    return out


def drawn_headphones() -> Image.Image:
    pad = int(S * 0.055)
    mask = squircle_mask(S)
    base = Image.new("RGBA", (S, S), NAVY)
    hi = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(hi).ellipse([-S * 0.3, -S * 0.75, S * 1.3, S * 0.55], fill=NAVY_HI)
    base.alpha_composite(hi.filter(ImageFilter.GaussianBlur(90)))
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    img.paste(base, (0, 0), mask)
    d = ImageDraw.Draw(img)
    cx, cy = S / 2, S * 0.505
    r = S * 0.315
    d.arc([cx - r, cy - r, cx + r, cy + r], start=180, end=360, fill=GOLD,
          width=int(S * 0.09))
    cup_w, cup_h = S * 0.185, S * 0.30
    for sign in (-1, 1):
        ex = cx + sign * (r - S * 0.09 * 0.05)
        top = cy - cup_h * 0.18
        d.rounded_rectangle([ex - cup_w / 2, top, ex + cup_w / 2, top + cup_h],
                            int(cup_w * 0.45), fill=GOLD)
    _ = pad
    return img


def main():
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    src = None
    if len(sys.argv) > 2 and Path(sys.argv[2]).is_file():
        src = Path(sys.argv[2])
    elif (out_dir / "logo_src.png").is_file():
        src = out_dir / "logo_src.png"

    icon = from_source(src) if src else drawn_headphones()

    # in-app header badge (rounded); larger source -> crisper integer downscale in Tk
    icon.resize((240, 240), Image.LANCZOS).save(out_dir / "header.png")

    iconset = out_dir / "TalkingTom.iconset"
    iconset.mkdir(exist_ok=True)
    for sz in (16, 32, 64, 128, 256, 512, 1024):
        icon.resize((sz, sz), Image.LANCZOS).save(iconset / f"icon_{sz}x{sz}.png")
        if sz <= 512:
            icon.resize((sz * 2, sz * 2), Image.LANCZOS).save(
                iconset / f"icon_{sz}x{sz}@2x.png")
    icns = out_dir / "icon.icns"
    try:
        subprocess.run(["iconutil", "-c", "icns", str(iconset), "-o", str(icns)],
                       check=True)
        print(f"wrote {icns}")
    except Exception as e:
        icon.resize((512, 512)).save(out_dir / "icon.png")
        print(f"iconutil failed ({e}); wrote icon.png")
    finally:
        for p in iconset.glob("*.png"):
            p.unlink()
        try:
            iconset.rmdir()
        except OSError:
            pass
    _ = math


if __name__ == "__main__":
    main()
