#!/bin/bash
# ============================================================================
#  Talking Tom  -  one-time setup
#
#  RIGHT-CLICK this file  ->  Open   (just this first time - macOS blocks a
#  plain double-click on anything downloaded from the web).
#
#  It installs its own copy of Python, downloads what the app needs, and puts
#  "Talking Tom" in your Applications folder. Takes about two minutes and needs
#  an internet connection. Nothing is installed system-wide; everything lives in
#  ~/.talking_tom and ~/Applications/Talking Tom.app.
# ============================================================================

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1

# Let macOS trust the files we just unzipped (clears the "unverified" flag).
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null || true

APPDIR="$HOME/.talking_tom"
VENV="$APPDIR/venv"
PYVER="3.12"
APP="$HOME/Applications/Talking Tom.app"

say()  { printf '\n\033[1m%s\033[0m\n' "$1"; }
fail() { printf '\n\033[1;31m%s\033[0m\n\n' "$1"; echo "Press return to close."; read -r _; exit 1; }

# Always use uv's own CPython build (it bundles Tcl/Tk) - never a random
# system Python that might be missing Tkinter.
export UV_PYTHON_PREFERENCE=only-managed

say "Talking Tom - setup"

# --- 1. uv : brings its own Python (with Tkinter), so you don't need one -------
UV="$(command -v uv || true)"
[ -z "$UV" ] && [ -x "$HOME/.local/bin/uv" ] && UV="$HOME/.local/bin/uv"
if [ -z "$UV" ]; then
  echo "Installing uv (sets up Python for the app)..."
  # INSTALLER_NO_MODIFY_PATH: don't touch the user's shell profile - we call uv
  # by its full path.
  if ! curl -LsSf https://astral.sh/uv/install.sh | env INSTALLER_NO_MODIFY_PATH=1 sh; then
    fail "Couldn't download uv. Check your internet connection and run this again."
  fi
  UV="$HOME/.local/bin/uv"
fi
[ -x "$UV" ] || fail "uv did not install correctly. Try again, or install it from https://astral.sh/uv"
echo "uv $("$UV" --version 2>/dev/null | awk '{print $2}')"

# --- 2. app files ------------------------------------------------------------
say "Copying the app into ~/.talking_tom ..."
mkdir -p "$APPDIR"
rm -rf "$APPDIR/app"
cp -R "$HERE/app" "$APPDIR/app" || fail "Couldn't copy the app files."

# --- 3. Python + dependencies ----------------------------------------------
say "Setting up Python $PYVER and dependencies (the slow part)..."
"$UV" python install "$PYVER" || fail "Couldn't download Python. Check your internet connection and run this again."
rm -rf "$VENV"
"$UV" venv --python "$PYVER" "$VENV" >/dev/null 2>&1 || fail "Couldn't create the Python environment."
"$UV" pip install --python "$VENV/bin/python" -r "$HERE/requirements.txt" \
  || fail "Couldn't install the dependencies (network issue?). Run this again."

"$VENV/bin/python" -c "import tkinter" 2>/dev/null \
  || fail "The installed Python is missing Tkinter. Please report this."

# --- 4. build the Talking Tom app ----------------------------------------
say "Building the Talking Tom app..."
mkdir -p "$HOME/Applications"
rm -rf "$APP"
SRC="$(mktemp -t talkingtom).applescript"
cat > "$SRC" <<'APPLESCRIPT'
on run
	launchTT("")
end run
on open theFiles
	launchTT(POSIX path of (item 1 of theFiles))
end open
on launchTT(filePath)
	set h to POSIX path of (path to home folder)
	set py to quoted form of (h & ".talking_tom/venv/bin/python")
	set scpt to quoted form of (h & ".talking_tom/app/talking_tom.py")
	set logf to quoted form of (h & ".talking_tom/last_run.log")
	set cmd to py & " " & scpt
	if filePath is not "" then set cmd to cmd & " " & quoted form of filePath
	do shell script cmd & " > " & logf & " 2>&1 &"
end launchTT
APPLESCRIPT
osacompile -o "$APP" "$SRC" || fail "Couldn't build the app."
rm -f "$SRC"

if [ -f "$APPDIR/app/icon.icns" ]; then
  ICNS="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIconFile' "$APP/Contents/Info.plist" 2>/dev/null || echo applet)"
  cp "$APPDIR/app/icon.icns" "$APP/Contents/Resources/$ICNS.icns" 2>/dev/null || true
  rm -f "$APP/Contents/Resources/Assets.car"
fi
codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true
touch "$APP"

# --- 5. Desktop alias -------------------------------------------------------
osascript >/dev/null 2>&1 <<OSA || true
tell application "Finder"
	try
		delete (alias file "Talking Tom" of desktop)
	end try
	make alias file to (POSIX file "$APP") at desktop
	set name of result to "Talking Tom"
end tell
OSA

# --- done -----------------------------------------------------------------
say "Done."
echo "  * Open \"Talking Tom\" from your Applications folder or the Desktop."
echo "  * You can drag this downloaded folder to the Trash now."
echo "  * For AI cleaning / translation: open Settings in the app and paste an"
echo "    Anthropic API key (console.anthropic.com). It's optional and free"
echo "    without one."
echo
open "$HOME/Applications" 2>/dev/null || true
open -a "$APP" 2>/dev/null || true
